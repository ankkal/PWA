CHECKOUT BY AMAZON INSTANT ORDER PROCESSING NOTIFICATION DEMO SERVLET
Copyright 2009 Amazon.com, Inc. or its affiliates. All Rights Reserved.
*-*-**-***-*****-********-*************
 
*-*-**-***-*****-********-*************
CONTENT SECTIONS (in order of appearance)
*-*-**-***-*****-********-*************
	INTRODUCTION
        INCLUDED FILES
	PREREQUISITES
	RELEASE NOTES
	SUPPORT & PROJECT HOME
	LINKS
*-*-**-***-*****-********-*************
INTRODUCTION
*-*-**-***-*****-********-*************

Please understand that by installing Checkout by Amazon IOPN
sample servlet code, you are agreeing to understand and abide by the
terms of the license, as written in LICENSE.txt.  Important links are
grouped together in a separate section for your convenience.  The most
current documentation on Checkout by Amazon can be found on its
website.

*-*-**-***-*****-********-*************
INCLUDED FILES
*-*-**-***-*****-********-*************

* MerchantEndPoint/             - Directory to copy to your tomcat server.
  * prop/                       - Property files for the IOPN server.
    * log4j.properties          - IOPN server logging settings.
    * merchant.properties.blank - Template for merchant.properties.
  * WEB-INF/lib/                - IOPN server jars; put third party packages here.
  * WEB-INF/classes/            - castor xml file, which needs to be there in tomcat classpath
* src/                          - Source for the IOPN server.
* lib/                          - Third party jars bundled along with sample
                                  code.
* prop/                         - Property files for the IOPN server.
* castor/                       - Castor mapping file for IOPN requests.
* INSTALLATION_GUIDE.txt        - Installation and Usage guide.
* LICENSE.txt                   - Apache License this code is licensed under.
* NOTICE.txt                    - Notice file.
* README.txt                    - This file.

*-*-**-***-*****-********-*************
PREREQUISITES
*-*-**-***-*****-********-*************
Please have the following software packages available on your systems
before running the demo.

1. Java 1.5 or greater
2. Jakarta Commons httpclient 3.x: http://hc.apache.org/httpclient-3.x/
3. Jakarta Commons codec 1.3: http://commons.apache.org/codec/
4. Jajarta Commons Logging 1.1: http://commons.apache.org/logging/
5. Apache log4j 1.2: http://logging.apache.org/log4j
6. Castor 1.2: http://www.castor.org/index.html
7. Xerces 2.9.1: http://xerces.apache.org/
8. Servlet jar

*-*-**-***-*****-********-*************
RELEASE NOTES 
*-*-**-***-*****-********-*************
(1) Carefully follow all instructions in INSTALLATION_GUIDE.txt 
(2) You must have set up an Amazon Seller account & have your merchantID
(3) You must have set up an AWS account, and have your AWS keys ready to use in
    the demo. To read more about an AWS account, please view Seller Central help: 
    https://sellercentral.amazon.com/gp/help/

*-*-**-***-*****-********-*************
SUPPORT & PROJECT HOME
*-*-**-***-*****-********-*************
	The latest documentation on Checkout by Amazon can be found at in the LINKS section below.
*-*-**-***-*****-********-*************
LINKS
*-*-**-***-*****-********-*************
	Checkout by Amazon Documentation & Seller Central
		https://sellercentral.amazon.com/gp/help/ 
