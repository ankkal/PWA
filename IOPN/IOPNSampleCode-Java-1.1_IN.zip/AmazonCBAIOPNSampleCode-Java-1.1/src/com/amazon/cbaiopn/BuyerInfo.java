/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn;

public class BuyerInfo
{

    protected String buyerName;

    protected String buyerEmailAddress;

    /**
     * Gets the value of the buyerName property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getBuyerName()
    {
        return buyerName;
    }

    /**
     * Sets the value of the buyerName property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setBuyerName(String value)
    {
        this.buyerName = value;
    }

    /**
     * Gets the value of the buyerEmailAddress property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getBuyerEmailAddress()
    {
        return buyerEmailAddress;
    }

    /**
     * Sets the value of the buyerEmailAddress property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setBuyerEmailAddress(String value)
    {
        this.buyerEmailAddress = value;
    }
}
