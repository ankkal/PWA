/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn;

public class ShippingAddress
{

    protected String name;

    protected String addressId;

    protected String addressFieldOne;

    protected String addressFieldTwo;

    protected String addressFieldThree;

    protected String city;

    protected String state;

    protected String postalCode;

    protected String countryCode;

    protected String phoneNumber;

    /**
     * Gets the value of the name property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getName()
    {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setName(String value)
    {
        this.name = value;
    }

    /**
     * Gets the value of the addressId property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getAddressId()
    {
        return addressId;
    }

    /**
     * Sets the value of the addressId property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAddressId(String value)
    {
        this.addressId = value;
    }

    /**
     * Gets the value of the addressFieldOne property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getAddressFieldOne()
    {
        return addressFieldOne;
    }

    /**
     * Sets the value of the addressFieldOne property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAddressFieldOne(String value)
    {
        this.addressFieldOne = value;
    }

    /**
     * Gets the value of the addressFieldTwo property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getAddressFieldTwo()
    {
        return addressFieldTwo;
    }

    /**
     * Sets the value of the addressFieldTwo property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAddressFieldTwo(String value)
    {
        this.addressFieldTwo = value;
    }

    /**
     * Gets the value of the addressFieldThree property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getAddressFieldThree()
    {
        return addressFieldThree;
    }

    /**
     * Sets the value of the addressFieldThree property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setAddressFieldThree(String value)
    {
        this.addressFieldThree = value;
    }

    /**
     * Gets the value of the city property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getCity()
    {
        return city;
    }

    /**
     * Sets the value of the city property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setCity(String value)
    {
        this.city = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getState()
    {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setState(String value)
    {
        this.state = value;
    }

    /**
     * Gets the value of the postalCode property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getPostalCode()
    {
        return postalCode;
    }

    /**
     * Sets the value of the postalCode property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setPostalCode(String value)
    {
        this.postalCode = value;
    }

    /**
     * Gets the value of the countryCode property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getCountryCode()
    {
        return countryCode;
    }

    /**
     * Sets the value of the countryCode property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setCountryCode(String value)
    {
        this.countryCode = value;
    }

    /**
     * Sets the value of the phoneNumber property.
     *
     * @param value
     * allowed object is {@link String }
     *
     */
    public void setPhoneNumber(String value)
    {
        this.phoneNumber = value;
    }

    /**
     * Gets the value of the countryCode property.
     *
     * @return possible object is {@link String }
     *
     */
    public String getPhoneNumber ()
    {
        return phoneNumber;
    }

}
