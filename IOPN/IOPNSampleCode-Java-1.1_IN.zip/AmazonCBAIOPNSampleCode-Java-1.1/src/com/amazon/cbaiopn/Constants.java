/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn;

/**
 * This class contains all the constants used in the sample code.
 */
public class Constants
{
    /* POST form keys sent from Checkout by Amazon. */
    public final static String REQUEST_UUID_KEY = "UUID";

    public final static String REQUEST_TIMESTAMP_KEY = "Timestamp";

    public final static String REQUEST_SIGNATURE_KEY = "Signature";

    public final static String REQUEST_NOTIFICATION_TYPE_KEY = "NotificationType";

    public final static String REQUEST_NOTIFICATION_DATA_KEY = "NotificationData";

    public final static String REQUEST_AWS_ACCESS_KEY_ID = "AWSAccessKeyId";

    /* merchant.properties file definitions */

    public final static String PROP_AWS_SECRET_KEY = "AWSSecretKey";
}
