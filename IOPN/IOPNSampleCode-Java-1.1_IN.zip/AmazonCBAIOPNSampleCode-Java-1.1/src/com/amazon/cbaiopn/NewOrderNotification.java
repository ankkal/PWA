/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn;

public class NewOrderNotification
{

    protected String notificationReferenceId;
   
    protected ProcessedOrder processedOrder;

    /**
     * Gets the value of the notificationReferenceId property.
     * 
     * @return possible object is {@link String }
     * 
     */
    public String getNotificationReferenceId()
    {
        return notificationReferenceId;
    }

    /**
     * Sets the value of the notificationReferenceId property.
     * 
     * @param value
     *            allowed object is {@link String }
     * 
     */
    public void setNotificationReferenceId(String value)
    {
        this.notificationReferenceId = value;
    }

    /**
     * Gets the value of the processedOrder property.
     * 
     * @return possible object is {@link ProcessedOrder }
     * 
     */
    public ProcessedOrder getProcessedOrder()
    {
        return processedOrder;
    }

    /**
     * Sets the value of the processedOrder property.
     * 
     * @param value
     *            allowed object is {@link ProcessedOrder }
     * 
     */
    public void setProcessedOrder(ProcessedOrder value)
    {
        this.processedOrder = value;
    }

}
