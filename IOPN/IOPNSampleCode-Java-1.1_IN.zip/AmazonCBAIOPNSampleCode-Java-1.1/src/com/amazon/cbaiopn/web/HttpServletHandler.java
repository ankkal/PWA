/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.amazon.cbaiopn.Constants;
import com.amazon.cbaiopn.NotificationType;
import com.amazon.cbaiopn.exceptions.CBAIOPNClientException;
import com.amazon.cbaiopn.exceptions.CBAIOPNException;
import com.amazon.cbaiopn.exceptions.CBAIOPNServerException;
import com.amazon.cbaiopn.processors.INotificationProcessor;
import com.amazon.cbaiopn.processors.NotificationProcessorFactory;
import com.amazon.cbaiopn.utils.SignatureCalculator;

@SuppressWarnings("serial")
public class HttpServletHandler extends javax.servlet.http.HttpServlet
{

    /*
     * This flag indicates whether merchant is opting for signed carts or not. If
     * this flag is set to false then no accessKeyId,SecretKey pairs will be
     * loaded and if the merchant endpoint receives any signed IOPNs, then they
     * will be not be processed.
     *
     * If the merchant is expecting signed IOPNs then this flag has to be set to
     * true and the accessKeyId,accessKey pairs should be mentioned in the
     * merchant.properties file
     *
     * THIS IS THE ONLY STATIC CONSTANT WHICH NEEDS ACTION BY MECHANT
     */
    private static final boolean SUPPORT_SIGNED_CARTS = true;
    
    private static Logger LOG = Logger.getLogger(HttpServletHandler.class);

    /*
     * This window represents the time duration, older than which, Notifications
     * are discarded by the server. It is 15 min, represented in milliseconds.
     */
    private static final long TIMESTAMP_WINDOW = 15 * 60 * 1000;

    private static final String TIMESTAMP_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'.'SSS'Z'";

    private static final String TIMEZONE = "GMT";

    private static SimpleDateFormat dateFormatter;

    private static Map<String, String> accessKeyMap = new HashMap<String, String>();

    private static final String ACCESS_KEY_DELIMITER = ",";

    static
    {
        dateFormatter = new SimpleDateFormat(TIMESTAMP_FORMAT);
        dateFormatter.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
    }

    @Override
    public void init(final ServletConfig config) throws ServletException
    {
        super.init(config);

        // Read the log4j configuration
        PropertyConfigurator.configure(getServletContext()
                .getRealPath("/prop/")
                + "/log4j.configuration");

        /*
         * Check whether the merchant has opted for signed carts
         * and load the awsSecretKeys only if it is true.
         *
         * Mechant can opt for the signed carts in settings present
         * in the SellerCentral
         * 
         */
        if (SUPPORT_SIGNED_CARTS)
        {
            try
            {
                loadAWSAccessKeys();
            }
            catch (CBAIOPNServerException e)
            {
                throw new ServletException(e);
            }
        }
    }

    @Override
    public void doGet(final HttpServletRequest request,
            final HttpServletResponse response) throws IOException
    {
        /*
         * HTTP Get is not supported. Return SC_METHOD_NOT_ALLOWED error as
         * response status
         */
        LOG.debug("In do Get Method");
        response
                .sendError(
                        HttpServletResponse.SC_METHOD_NOT_ALLOWED,
                        "This REST Web service accepts request only through the HTTP POST method. Your request was denied because it was sent through HTTP GET!");
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException
    {
        LOG.debug("Starting doPost.");

        try
        {
            // Authenticate the request using UUID, Timestamp and Signature
            authenticateRequest(request);
        }
        catch (CBAIOPNException ex)
        {
            // error occurred during authentication.
            // Send SC_FORBIDDEN as response status
            LOG.error(ex.getMessage(), ex);
            response.sendError(HttpServletResponse.SC_FORBIDDEN, ex
                    .getMessage());
            return;
        }

        try
        {
            // Once the authentication succeeds, process the request
            processRequest(request);

            // Send the SC_OK as response status, as the processing is
            // successful
            response.setStatus(HttpServletResponse.SC_OK);
        }
        catch (CBAIOPNException ex)
        {
            // error occurred during processing.
            // Send SC_INTERNAL_SERVER_ERROR as response status
            LOG.error(ex.getMessage(), ex);
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                    .getMessage());
        }
    }

    /**
     * This method helps in authenticating the request. It extracts the UUID and
     * Timestamp from the request, signs these two parameters using the
     * merchant's awsSecretKey and compares it with the signature passed in the
     * request.
     * 
     * @param request
     *            Request coming from the client
     * 
     * @throws CBAIOPNClientException
     *             In case the signature computation fails
     * 
     * @throws CBAIOPNClientException
     *             In case the authentication fails
     */
    private void authenticateRequest(HttpServletRequest request)
            throws CBAIOPNServerException, CBAIOPNClientException
    {
        LOG.debug("Authenticating the Request...");

        String awsAccessKeyId = request
                .getParameter(Constants.REQUEST_AWS_ACCESS_KEY_ID);
        String awsSecretKey = getAccessKey(awsAccessKeyId);

        // Extract signature from the request
        String signature = request
                .getParameter(Constants.REQUEST_SIGNATURE_KEY);

        // Extract UUID from the request
        String uuid = request.getParameter(Constants.REQUEST_UUID_KEY);

        // Extract timestamp from the request
        String timestamp = request
                .getParameter(Constants.REQUEST_TIMESTAMP_KEY);

        boolean isAccessKeyListConfigured = (accessKeyMap.size() != 0);
        /*
         * Merchant has not specified access key list in the properties file.
         * But CBA is sending the signature in the IOPN request.
         */
        if (!isAccessKeyListConfigured && signature != null)
        {
            LOG
                    .fatal("No Access key is specified in the merchant.properties file, "
                            + "where as, the Key is configured on the CBA side."
                            + "Please specify the access key in the merchant.properties file, so that IOPN request can be validated...");

            throw new CBAIOPNClientException(
                    "AccessKeyList is missing in the properties file...");

        }
        else if (!isAccessKeyListConfigured && signature == null)
        {
            /* Merchant has not configured access key at all */
            return;
        }
        else if (signature == null || uuid == null || timestamp == null
                || awsAccessKeyId == null)
        {
            /*
             * Merchant has specified the access key in the properties file. But
             * the IOPN doesn't contain enough information for performing
             * signature authentication
             */

            throw new CBAIOPNClientException(
                    "UUID/Timestamp/Signature/AWSAccessKeyId is missing in the Notification.");

        }
        else if (awsSecretKey == null)
        {
            /*
             * Merchant has configured the AwsAccessKeyList in the properties
             * file. But the accessKeyId passed in the request is not present in
             * that list.
             */
            throw new CBAIOPNClientException(
                    "AWSAccesskeyId : "
                            + awsAccessKeyId
                            + " is not present in the AWSSecretKeyList specified in the merchant.properties file.");
        }

        /*
         * Proceed with signature validation as we now have all the information
         * needed
         */

        validateTimeStamp(timestamp);

        LOG.debug("UUID :" + uuid + "\n" + "Timestamp : " + timestamp + "\n"
                + "Recieved Signature : " + signature + "\n"
                + "AWSAccessKeyId : " + awsAccessKeyId);

        // Calculate the signature using UUID, timestamp and the awsSecretKey
        String calcSig = SignatureCalculator.computeSignature(uuid, timestamp,
                awsSecretKey);

        LOG.debug("Calculated Signature: " + signature);

        // Compare the newly calculated signature with the signature present in
        // the request
        // for authentication
        if (!signature.equals(calcSig))
        {
            throw new CBAIOPNClientException(
                    ("Signature is incorrect. Recieved: " + signature
                            + " ; Calculated: " + calcSig));
        }
    }

    /**
     * This method processes the request based the NotificationType parameter
     * present in the request.
     * 
     * It initially processes the AmazonSignature present in the request. Then
     * it extracts the NotificationType from the request and instantiates the
     * appropriate Processor class for processing the NotificationData present
     * in the request
     * 
     * @param request
     *            Request from client
     * @throws CBAIOPNServerException
     *             In case of any server side failures/errors during processing
     * @throws CBAIOPNClientException
     *             In case of any client side failures/errors during processing
     * 
     */
    private void processRequest(final HttpServletRequest request)
            throws CBAIOPNServerException, CBAIOPNClientException
    {
        // Extract NotificationData from the request
        String requestMessage = request
                .getParameter(Constants.REQUEST_NOTIFICATION_DATA_KEY);

        // Extract NotificationType from the request
        String notificationType = request
                .getParameter(Constants.REQUEST_NOTIFICATION_TYPE_KEY);

        LOG.debug("NotificationType : " + notificationType);
        LOG.debug("NotificationData : \n" + requestMessage);
        
        NotificationType notificationTypeEnum;

        try
        {
            notificationTypeEnum = NotificationType.valueOf(notificationType);
        }
        catch (IllegalArgumentException e)
        {
            throw new CBAIOPNClientException("Unknown notification type : "
                    + notificationType, e);
        }

        INotificationProcessor notificationProcessor = NotificationProcessorFactory
                .getProcessor(notificationTypeEnum);

        // Process the NotificationData
        notificationProcessor.process(requestMessage);
    }

    /**
     * This method validates that the timestamp is not older than 15 min.
     * 
     * Incase the timestamp is null or if it is older than 15 min then it throws
     * CBAIOPNClientException
     * 
     * @param timestamp
     *            timestamp to validate
     * @throws CBAIOPNClientException
     *             in case of failure
     */
    private void validateTimeStamp(String timestamp)
            throws CBAIOPNClientException
    {
        if (timestamp == null)
        {
            throw new CBAIOPNClientException(
                    "Timestamp is absent in the notification.");
        }

        Date dateFromTimeStamp = null;
        try
        {
            dateFromTimeStamp = dateFormatter.parse(timestamp);
        }
        catch (ParseException e)
        {
            throw new CBAIOPNClientException(
                    "Not able to parse the time stamp present in the notification.");
        }

        Calendar calendarInstance = GregorianCalendar.getInstance();
        calendarInstance.setTime(dateFromTimeStamp);

        long epocRepresentation = calendarInstance.getTimeInMillis();

        // If the timestamp is older than timestamp window then discard the
        // request
        if (epocRepresentation < (System.currentTimeMillis() - TIMESTAMP_WINDOW))
        {
            throw new CBAIOPNClientException("Timestamp is older than "
                    + (TIMESTAMP_WINDOW / (1000 * 60)) + " minutes");
        }

    }

    /**
     * This method adds the given awsSecretKeyId-awsAccessKey pair to the cache.
     * This method is provided purely for the purpose of testing this class. One
     * should provide the awsSecretKey in merchant.properties and it will be
     * automatically be picked up by this class.
     * 
     * @param accessKeyid
     * @param accessKey
     */
    public void addAWSAccessKey(String accessKeyid, String accessKey)
    {
        accessKeyMap.put(accessKeyid, accessKey);
    }

    /**
     * This method removes the given awsSecretKeyId from the cache. This method
     * is provided purely for the purpose of testing this class.
     * 
     * @param accessKeyid
     */
    public void removeAWSAccessKey(String accessKeyid)
    {
        accessKeyMap.remove(accessKeyid);
    }

    /**
     * This method retrieves the accessKey for the given accessKeyId The source
     * for the key is the AWSAccessKeyList present in the properties file
     * 
     * @param id
     *            AWSAccessKeyId
     * @return corresponding AccessKey. Null is returned if the given Id is not
     *         present
     */
    private String getAccessKey(String id)
    {
        String accessKey = accessKeyMap.get(id);

        if (accessKey == null)
        {
            LOG.debug("No accessKey is found for the accessKeyId : " + id);
        }

        return accessKey;
    }

    /**
     * This method performs the task of loading all the accessKeyId, accessKey
     * pairs so that they can be used during signature authentication. Currently
     * the source for the pairs is the merchant.properties file. It parses the 
     * AWSSecretKeyList present in the following format :
     *
     * AWSSecretKeyList = (AWSAccessKeyId1,AWSSecretKey1), (AWSAccessKeyId2,AWSSecretKey2)
     * 
     * But merchant can change the source or the format or both of the AWSSecretKeyList
     * and correspondingly change the logic present in this method.
     * 
     * @throws CBAIOPNServerException
     *             In case of any errors while loading the pairs
     * 
     */
    private void loadAWSAccessKeys() throws CBAIOPNServerException
    {
        Properties props = new Properties();
        try
        {
            // Read the merchant.properties file
            props.load(new FileInputStream(getServletContext().getRealPath(
                    "/prop/")
                    + "/merchant.properties"));

            /*
             * Extract the AWSSecretKey present in the merchant.properties file
             * This is a demo code and hence the secretKey is stored in plain
             * text format. Usually the secret key should be stored in a secure
             * storage and should be accessed from there
             */
            String accessKeyList = props.getProperty("AWSSecretKeyList");

            // proceed only if any accessKey is configured
            if (accessKeyList != null && !accessKeyList.trim().equals(""))
            {
                // Get the accessKeyId,AccessKey pairs into an array
                // This is retrieved by spliting the list based on "),("
                String[] accessKeyPairArray = accessKeyList
                        .split("\\)[\\t\\s]*" + ACCESS_KEY_DELIMITER
                                + "[\\t\\s]*\\(");

                // Trim off leading and trailing whitespaces for each
                // accessKeyId to accessKeyPair
                for (int i = 0; i < accessKeyPairArray.length; ++i)
                    accessKeyPairArray[i] = accessKeyPairArray[i].trim();

                int lastIndex = accessKeyPairArray.length - 1;

                try
                {
                    // Remove the extra braces present in the first pair and the
                    // last pair
                    accessKeyPairArray[0] = accessKeyPairArray[0].substring(
                            accessKeyPairArray[0].indexOf("(") + 1).trim();
                    accessKeyPairArray[lastIndex] = accessKeyPairArray[lastIndex]
                            .substring(0,
                                    accessKeyPairArray[lastIndex].indexOf(")"))
                            .trim();
                }
                catch (StringIndexOutOfBoundsException e)
                {
                    LOG
                            .error("PARSE ERROR : AWSAccessKeyList is not well formed in the properties file. AccessKey(s) will not be loaded.");
                    throw e;
                }

                // Iterate through the each pair and load it into the hashmap
                // where awsAccessKeyId is the key for hashmap and awsSecretKey
                // is the value
                // for the corresponding key in the hashmap
                for (String pair : accessKeyPairArray)
                {
                    String[] keyValue = pair.split(ACCESS_KEY_DELIMITER);

                    // Make sure that we have 2 values after the split
                    // which will be accessKeyId and the secretKey
                    if (keyValue.length != 2 || "".equals(keyValue[0])
                            || "".equals(keyValue[1]))
                    {
                        LOG
                                .error("ERROR while parsing accessKeyId-Key entry : "
                                        + pair + " . Ignoring this entry.");
                    }
                    else
                    {
                        // Load the accessKeyId and the secretKey into the
                        // hash map
                        accessKeyMap
                                .put(keyValue[0].trim(), keyValue[1].trim());
                    }
                }
            }

        }
        catch (IOException e)
        {
            LOG.error("Unable to read merchant properties", e);
            throw new CBAIOPNServerException(
                    "Unable to read merchant properties", e);
        }
    }
}
