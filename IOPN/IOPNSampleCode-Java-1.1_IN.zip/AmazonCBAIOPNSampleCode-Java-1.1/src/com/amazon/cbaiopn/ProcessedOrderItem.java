/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn;

import java.math.BigInteger;

import org.exolab.castor.types.AnyNode;

public class ProcessedOrderItem
{
	protected String amazonOrderItemCode;
	
	protected String merchantId;
	
    protected String sku;

    protected String title;

    protected String description;
    
    protected String clientRequestId;

    protected String cartId;
    
    protected String integratorId;

    protected String integratorName;
    
    protected Price price;

    protected BigInteger quantity;

    protected Weight weight;

    protected String category;

    protected String condition;

    protected FulfillmentNetwork fulfillmentNetwork;

    protected Charges itemCharges;
    
    protected AnyNode cartCustomData;
    
    protected AnyNode itemCustomData;
    
    /**
     * Gets the value of the amazonOrderItemCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAmazonOrderItemCode() {
        return amazonOrderItemCode;
    }

    /**
     * Sets the value of the amazonOrderItemCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAmazonOrderItemCode(String value) {
        this.amazonOrderItemCode = value;
    }

    /**
     * Gets the value of the merchantId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMerchantId() {
        return merchantId;
    }

    /**
     * Sets the value of the merchantId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMerchantId(String value) {
        this.merchantId = value;
    }

    /**
     * Gets the value of the sku property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSKU() {
        return sku;
    }

    /**
     * Sets the value of the sku property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSKU(String value) {
        this.sku = value;
    }

    /**
     * Gets the value of the title property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the value of the title property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitle(String value) {
        this.title = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the clientRequestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClientRequestId() {
        return clientRequestId;
    }

    /**
     * Sets the value of the clientRequestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClientRequestId(String value) {
        this.clientRequestId = value;
    }

    /**
     * Gets the value of the cartId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCartId() {
        return cartId;
    }

    /**
     * Sets the value of the cartId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCartId(String value) {
        this.cartId = value;
    }

    /**
     * Gets the value of the integratorId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegratorId() {
        return integratorId;
    }

    /**
     * Sets the value of the integratorId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegratorId(String value) {
        this.integratorId = value;
    }

    /**
     * Gets the value of the integratorName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIntegratorName() {
        return integratorName;
    }

    /**
     * Sets the value of the integratorName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIntegratorName(String value) {
        this.integratorName = value;
    }

    /**
     * Gets the value of the price property.
     * 
     * @return
     *     possible object is
     *     {@link Price }
     *     
     */
    public Price getPrice() {
        return price;
    }

    /**
     * Sets the value of the price property.
     * 
     * @param value
     *     allowed object is
     *     {@link Price }
     *     
     */
    public void setPrice(Price value) {
        this.price = value;
    }

    /**
     * Gets the value of the quantity property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getQuantity() {
        return quantity;
    }

    /**
     * Sets the value of the quantity property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setQuantity(BigInteger value) {
        this.quantity = value;
    }

    /**
     * Gets the value of the weight property.
     * 
     * @return
     *     possible object is
     *     {@link Weight }
     *     
     */
    public Weight getWeight() {
        return weight;
    }

    /**
     * Sets the value of the weight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Weight }
     *     
     */
    public void setWeight(Weight value) {
        this.weight = value;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the condition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCondition() {
        return condition;
    }

    /**
     * Sets the value of the condition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCondition(String value) {
        this.condition = value;
    }

    /**
     * Gets the value of the fulfillmentNetwork property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentNetwork }
     *     
     */
    public FulfillmentNetwork getFulfillmentNetwork() {
        return fulfillmentNetwork;
    }

    /**
     * Sets the value of the fulfillmentNetwork property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentNetwork }
     *     
     */
    public void setFulfillmentNetwork(FulfillmentNetwork value) {
        this.fulfillmentNetwork = value;
    }

    /**
     * Gets the value of the itemCharges property.
     * 
     * @return
     *     possible object is
     *     {@link Charges }
     *     
     */
    public Charges getItemCharges() {
        return itemCharges;
    }

    /**
     * Sets the value of the itemCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link Charges }
     *     
     */
    public void setItemCharges(Charges value) {
        this.itemCharges = value;
    }
    
    /**
     * Retrieves the cart level custom data
     * @return cart custom data
     */
    public AnyNode getCartCustomData() {
    	return cartCustomData;
    }
    
    /**
     * set the cart level custom data.
     * @param cartCustomData
     */
    public void setCartCustomData(AnyNode cartCustomData) {
    	this.cartCustomData = cartCustomData;
    }
    
    /**
     * Retrieves the item level custom data
     * @return item custom data
     */
    public AnyNode getItemCustomData() {
    	return itemCustomData;
    }
    
    /**
     * set the item level custom data.
     * @param itemCustomData
     */
    public void setItemCustomData(AnyNode itemCustomData) {
    	this.itemCustomData = itemCustomData;
    }	
}
