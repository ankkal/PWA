/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn.exceptions;

/**
 * Exception class used for indicating errors while processing the notification
 */
@SuppressWarnings("serial")
public class CBAIOPNException extends Exception
{
    public CBAIOPNException()
    {
        super();
    }

    public CBAIOPNException(Exception e)
    {
        super(e);
    }

    public CBAIOPNException(String msg)
    {
        super(msg);
    }

    public CBAIOPNException(String msg, Exception e)
    {
        super(msg, e);
    }
}
