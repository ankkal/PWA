/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.amazon.cbaiopn.utils;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;

import org.exolab.castor.mapping.Mapping;
import org.exolab.castor.mapping.MappingException;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.InputSource;

/**
 * A simple class that demonstrates how to unmarshall the incoming request
 * message to Object type.
 */
public class CBAUtils
{

    private static String namespace = "xmlns=\"http://payments.amazon.com/checkout/2008-11-30/\"";

    private static String castorMappingFile = "iopn-request-mapping.xml";

    /**
     * Unmarshalls the incoming request message to Object.
     * 
     * @param eventXml
     * @return Event Notification Object
     * @throws FileNotFoundException
     * @throws MarshalException
     * @throws ValidationException
     */
    @SuppressWarnings("unchecked")
    public static <T extends Object> T unMarshallRequestToObject(String eventXml)
            throws FileNotFoundException, MappingException, MarshalException,
            ValidationException
    {
        String requestWithExtractedNamespace = null;
        InputStream strm = CBAUtils.class.getClassLoader().getResourceAsStream(
                castorMappingFile);
        Mapping mapping = new Mapping();
        mapping.loadMapping(new InputSource(new InputStreamReader(strm)));

        Unmarshaller unmar = new Unmarshaller(mapping);
        requestWithExtractedNamespace = extractNameSpaceFromRequestMessage(eventXml);

        T request = (T) unmar.unmarshal(new InputSource(new StringReader(
                requestWithExtractedNamespace)));

        return request;
    }

    /**
     * Extracts the namespace from the Request Message.
     * 
     * @param requestMessage
     * @return request message without the namespace
     */
    private static String extractNameSpaceFromRequestMessage(
            String requestMessage)
    {
        String requestwithoutNameSpace = requestMessage.replace(namespace, "");

        return requestwithoutNameSpace;
    }
}
