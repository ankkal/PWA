/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn;

import java.util.ArrayList;
import java.util.List;

public class ProcessedOrderItems
{

    protected List<ProcessedOrderItem> processedOrderItem;

    /**
     * Gets the value of the processedOrderItem property.
     * 
     * <p>
     * This accessor method returns a reference to the live list, not a
     * snapshot. Therefore any modification you make to the returned list will
     * be present inside the JAXB object. This is why there is not a
     * <CODE>set</CODE> method for the processedOrderItem property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * 
     * <pre>
     * getProcessedOrderItem().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProcessedOrderItem }
     * 
     * 
     */
    public List<ProcessedOrderItem> getProcessedOrderItem()
    {
        if (processedOrderItem == null)
        {
            processedOrderItem = new ArrayList<ProcessedOrderItem>();
        }
        return this.processedOrderItem;
    }

    public void setProcessedOrderItem(
            List<ProcessedOrderItem> processedOrderItem)
    {
        this.processedOrderItem = processedOrderItem;
    }

}
