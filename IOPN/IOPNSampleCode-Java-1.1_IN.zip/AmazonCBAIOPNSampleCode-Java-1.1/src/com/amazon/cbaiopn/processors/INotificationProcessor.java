/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn.processors;

import com.amazon.cbaiopn.exceptions.CBAIOPNClientException;
import com.amazon.cbaiopn.exceptions.CBAIOPNServerException;

/**
 * This interface should be extended by all the classes which process the
 * NotificationData present in the notification request.
 */
public interface INotificationProcessor
{

    /**
     * This method takes the NotifcicationData, which is in the XML format, as
     * the parameter. The logic for processing this data resides in this method.
     * 
     * @param msg
     *            notification data, retrieved from Notification request.
     * 
     * @throws CBAIOPNServerException
     *             In case of any server side errors while parsing the
     *             NotificationData
     * @throws CBAIOPNClientException
     *             In case of any client side errors while parsing the
     *             NotificationData
     * 
     */
    public void process(String msg) throws CBAIOPNServerException,
            CBAIOPNClientException;
}
