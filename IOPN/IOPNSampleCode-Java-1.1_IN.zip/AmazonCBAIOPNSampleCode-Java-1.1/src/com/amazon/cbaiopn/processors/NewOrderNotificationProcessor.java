/**
 * Copyright 2009 Amazon.com, Inc., or its affiliates. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *              http://aws.amazon.com/apache2.0/
 *
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.amazon.cbaiopn.processors;

import java.io.FileNotFoundException;

import org.apache.log4j.Logger;
import org.exolab.castor.mapping.MappingException;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;

import com.amazon.cbaiopn.NewOrderNotification;
import com.amazon.cbaiopn.exceptions.CBAIOPNClientException;
import com.amazon.cbaiopn.exceptions.CBAIOPNServerException;
import com.amazon.cbaiopn.utils.CBAUtils;

/**
 * This class helps in processing the New Order Notification. One should modify
 * the "process" method of this class to control the processing of
 * NewOrderNotification.
 */
public class NewOrderNotificationProcessor implements INotificationProcessor
{

    private static final Logger LOG = Logger
            .getLogger(NewOrderNotificationProcessor.class);

    /**
     * This method takes the NotifcicationData, which is in the XML format, as
     * the parameter. The logic for processing this data resides in this method.
     * 
     * @param msg
     *            notification data, retrieved from Notification request.
     * 
     * @throws CBAIOPNServerException
     *             In case of any server side errors while parsing the
     *             NotificationData
     * @throws CBAIOPNClientException
     *             In case of any client side errors while parsing the
     *             NotificationData
     * 
     */
    public void process(String msg) throws CBAIOPNServerException,
            CBAIOPNClientException
    {
        /*
         * Stub in the logic for custom processing new Order Notification here.
         * msg parameter contains the data related to NewOrderNotification in
         * the XML format.
         * 
         * CBAIOPNServerException should be thrown in case of any server side
         * failures/errors. CBAIOPNClientException should be thrown in case of
         * any server side failures/errors.
         * 
         */
        try
        {
            NewOrderNotification notifData = CBAUtils
                    .unMarshallRequestToObject(msg);

            /*
             * Log the required fields. To be extended by merchant. Merchant can
             * stub in all the business logic to process the notification here.
             */
            LOG.debug("Recieved New Order Notification Data for order id : "
                    + notifData.getProcessedOrder().getAmazonOrderID());
        }
        catch (ClassCastException e)
        {
            throw new CBAIOPNClientException(
                    "NotificationData is in-consistent with NotificationType");
        }
        catch (MarshalException e)
        {
            throw new CBAIOPNServerException(
                    "Error during unmarshalling: Unable to unmarshall the request message  "
                            + msg, e);
        }
        catch (ValidationException e)
        {
            throw new CBAIOPNServerException(
                    "Error during unmarshalling: Invalid XML", e);
        }
        catch (FileNotFoundException e)
        {
            throw new CBAIOPNServerException(
                    "Error during unmarshalling: Unable to locate the mapping file.",
                    e);
        }
        catch (MappingException e)
        {
            throw new CBAIOPNServerException(
                    "Error during unmarshalling: Error with Mapping file.", e);
        }
    }
}
