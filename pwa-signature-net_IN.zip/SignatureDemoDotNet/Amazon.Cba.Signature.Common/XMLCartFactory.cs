﻿using System;
using System.Collections.Generic;
using System.Text;

/**
 * Returns a simple static cart to generate a signature from,
 * and the final complete cart html.
 * 
 * Copyright 2007-2011 Amazon.com, Inc., or its affiliates. All Rights Reserved. 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 * 		http://aws.amazon.com/apache2.0/
 * 
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

namespace signature.common.cart
{
    public class XMLCartFactory : CartFactory
    {

        protected static String CART_FORM_ORDER_INPUT_FIELD = "type:merchant-signed-order/aws-accesskey/1;order:[ORDER];" +
									"signature:[SIGNATURE];aws-access-key-id:[AWS_ACCESS_KEY_ID]";
        protected static String CART_ORDER = "[ORDER]";
        protected static String CART_AWS_ACCESS_KEY_ID = "[AWS_ACCESS_KEY_ID]";

        public XMLCartFactory()
        {
        }
      
    /*
	 * Gets cart html fragment used to generate entire cart html
	 * Base 64 encode the cart.
     */
        override
        public String getCart(String merchantID, String awsAccessKeyID)
        {

            String cartXML = getCartXML(merchantID, awsAccessKeyID);
            String b64Cart = System.Convert.ToBase64String(ASCIIEncoding.UTF8.GetBytes(cartXML));

            return b64Cart;
        }

        /*
	     * Returns the concatenated cart used for signature generation.
         */
        override
        public String getSignatureInput(String merchantID, String awsAccessKeyID)
        {
            return getCartXML(merchantID, awsAccessKeyID);
        }

        /*
         * Returns a finalized full cart html including the base 64 encoded cart,
         * signature, and buy button image link.
         */
        override
        public String getCartHTML(String merchantID, String awsAccessKeyID, String signature)
        {
            String cart = "";
            cart += CART_JAVASCRIPT_START;
            cart += CBA_BUTTON_DIV;

            String encodedCart = getCart(merchantID, awsAccessKeyID);
            String cartValue = CART_FORM_ORDER_INPUT_FIELD.Replace("\\[SIGNATURE\\]", signature).
                        Replace("\\[AWS_ACCESS_KEY_ID\\]", awsAccessKeyID).Replace("\\[ORDER\\]", encodedCart);
            String widgetScript = STANDARD_CHECKOUT_WIDGET_SCRIPT.Replace("\\[CART_TYPE\\]", "XML");
            widgetScript = widgetScript.Replace("\\[CART_VALUE\\]", cartValue).Replace("\\[MERCHANT_ID\\]", merchantID);
            cart += widgetScript;

            return cart;
            
        }

        /*
         * Replace with your own cart here to try out
         * different promotions, tax, shipping, etc. 
         */
        private String getCartXML(String merchantID,
                String awsAccessKeyID)
        {
            return
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
            "<Order xmlns=\"http://payments.amazon.com/checkout/2009-05-15/\">" +
            "    <ClientRequestId>123457</ClientRequestId>" +
            "    <Cart>" +
            "    <Items>" +
            "      <Item>" +
            "         <SKU>CALVIN-HOBBES</SKU>" +
            "         <MerchantId>" + merchantID + "</MerchantId>" +
            "         <Title>The Complete Calvin and Hobbes</Title>" +
            "         <Description>By Bill Watterson</Description>" +
            "         <Price>" +
            "            <Amount>2.50</Amount>" +
            "            <CurrencyCode>INR</CurrencyCode>" +
            "         </Price>" +
            "         <Quantity>1</Quantity>" +
            "         <Weight>" +
            "            <Amount>8.5</Amount>" +
            "            <Unit>kg</Unit>" +
            "         </Weight>" +
            "         <Category>Books</Category>" +
            "      </Item>" +
            "    </Items>" +
            "    </Cart>" +
            "</Order>";
        }

    }
}


