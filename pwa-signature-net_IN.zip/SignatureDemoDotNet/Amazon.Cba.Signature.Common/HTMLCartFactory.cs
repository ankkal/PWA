﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Collections;
using System.Web;

/**
 * Abstract class that contains utility methods for converting a map of url
 * parameters to its string representation for use with signature generation.
 * 
 * Copyright 2007-2011 Amazon.com, Inc., or its affiliates. All Rights Reserved. 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 * 		http://aws.amazon.com/apache2.0/
 * 
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

namespace signature.common.cart
{
    public abstract class HTMLCartFactory : CartFactory 
    {
        override
        public String getCart(String merchantID, String awsAccessKeyID)
        {
            OrderedDictionary Map = getCartMap(merchantID, awsAccessKeyID);

            String cart = "";

            foreach (DictionaryEntry entry in Map)
            {
                cart += CART_FORM_INPUT_FIELD;
                cart = cart.Replace(CART_KEY, entry.Key.ToString());
                cart = cart.Replace(CART_VALUE, entry.Value.ToString());
            }

            return cart;

        }

        /**
         * Generates the finalized cart html, including javascript headers, cart contents,
         * signature and button.
         * 
         */
        override
        public String getCartHTML(String merchantID, String awsAccessKeyID, String signature)
        {
            
            String cart = "";
            cart += CART_JAVASCRIPT_START;
            cart += CBA_BUTTON_DIV;
            cart += CART_FORM_START.Replace(CART_MERCHANT_ID, merchantID);
            cart += getCart(merchantID, awsAccessKeyID);
            cart += CART_FORM_SIGNATURE_INPUT_FIELD.Replace(CART_SIGNATURE, signature); 
            cart += CART_FORM_END;
            String widgetScript = STANDARD_CHECKOUT_WIDGET_SCRIPT.Replace("\\[CART_VALUE\\]", "CBACartForm");
            widgetScript = widgetScript.Replace("\\[CART_TYPE\\]", "HTML").Replace("\\[MERCHANT_ID\\]", merchantID);
            cart += widgetScript;
            return cart;
        }

        /**
         * Generates the signature input - basically a contenation of all url parameters.
         * Doesn't handle full url specification, since it
         * doesn't handle parameter value of arrays - just assumes each parameter
         * value is a basic string.
         * 
         * Checkout by Amazon only supports this format as well, so that is
         * perfectly fine.
         * 
         */
        protected String getSignatureInput(OrderedDictionary parameterMap)
        {
            String queryValues = "";

            foreach (DictionaryEntry entry in parameterMap ) {
                queryValues += entry.Key.ToString() + "=";
                queryValues += HttpUtility.UrlEncode(entry.Value.ToString()).Replace("+","%20") + "&";
            }

            return queryValues;

        }

        protected abstract OrderedDictionary getCartMap(String merchantID, String awsAccessKey);

    }
}

