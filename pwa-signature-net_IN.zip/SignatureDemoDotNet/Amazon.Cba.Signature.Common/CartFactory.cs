﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 * Copyright 2007-2011 Amazon.com, Inc., or its affiliates. All Rights Reserved. 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 * 		http://aws.amazon.com/apache2.0/
 * 
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

namespace signature.common.cart
{
    public abstract class CartFactory
    {   

        protected static String HTML_START = "<html><body>\n";

        protected static String CART_JAVASCRIPT_START = " <script type=\"text/javascript\" src=\"https://static-eu.payments-amazon.com/cba/js/in/sandbox/PaymentWidgets.js\"></script>\n"
                                                        + "<!-- For Switching to Production, comment out the lines above and uncomment the lines below -->\n"
                                                        + "<!-- <script type=\"text/javascript\" src=\"https://static-eu.payments-amazon.com/cba/js/in/PaymentWidgets.js\"></script>-->\n";
	
	protected static String CART_FORM_START = "<form method=\"POST\" action=\"\" id=\"CBACartForm\">\n";

	protected static String CART_FORM_INPUT_FIELD = "<input type=\"hidden\" name=\"[KEY]\" value=\"[VALUE]\" />\n";
	
	protected static String CBA_BUTTON_DIV = "<div id=\"cbaButton\"></div>\n";

	protected static String CART_FORM_SIGNATURE_INPUT_FIELD = "<input type=\"hidden\" name=\"merchant_signature\" value=\"[SIGNATURE]\" />\n";

	protected static String STANDARD_CHECKOUT_WIDGET_SCRIPT ="<script type=\"text/javascript\">\n  "
                                                                + "new CBA.Widgets.StandardCheckoutWidget({ merchantId: '[MERCHANT_ID]', "
                                                                + "buttonSettings: { size: 'medium', color: 'orange', background: 'light' }, "
                                                                + "orderInput: { format: '[CART_TYPE]', value: '[CART_VALUE]' } }).render('cbaButton'); \n</script>";

	protected static String CART_FORM_END = "</form>\n";

        protected static String HTML_END = "</body></html>\n";

        protected static String CART_MERCHANT_ID = "[MERCHANT_ID]";
        protected static String CART_KEY = "[KEY]";
        protected static String CART_VALUE = "[VALUE]";
        protected static String CART_SIGNATURE = "[SIGNATURE]";
        /*
        Gets cart html fragment used to generate entire cart html.
*/
        public abstract String getCart(String merchantID, String awsAccessKeyID);

        /**
         * Returns the concatenated cart used for signature generation.

        */
        public abstract String getSignatureInput(String merchantID, String awsAccessKeyID);

        /**
         * Returns a finalized full cart html including the base 64 encoded cart, signatuer, and the buy button image link.
        */
        public abstract String getCartHTML(String merchantID, String awsAccessKeyID, String signature);

    }
}


