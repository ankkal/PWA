using System;
using System.Collections.Generic;
using System.Text;
using Amazon.Cba.Signature.Common.Cart;
using Amazon.Cba.Signature.Common;

/**
 * A simple demo class that demostrates how to generate a signature with the
 * user specified parameters: Merchant ID, AWS/MWS Access Key ID and AWS/MWS Secret Key ID.
 * 
 * NOTE: You may modify signature.common.cart.xml.XMLCartFactory.getCartXML(...) and
 * signature.merchant.cart.html.MerchantHTMLCartFactory.getCartMap(...)
 * to generate signatures for your own cart.
 * 
 * Copyright 2007-2011 Amazon.com, Inc., or its affiliates. All Rights Reserved. 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 * 		http://aws.amazon.com/apache2.0/
 * 
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

namespace Amazon.Cba.Signature.Demo
{
    class SignCartDemo
    {
	/**
	 * Demostrates how to generate a merchant signed cart (both HTML and XML)
	 * 
	*/
        static void Main(string[] args)
        {
            String merchantID;
            String secretKeyID;
            String accessKeyID;

            if (args.Length >= 1)
            {
                merchantID = args[0];
            }
            else {
                merchantID = "";
            }
            if (args.Length >= 2)
            {
                accessKeyID = args[1];
            }
            else {
                accessKeyID = "";
            }
            if (args.Length >= 3)
            {
                secretKeyID = args[2];
            }
            else
            {
                secretKeyID = "";
            }
   
            Console.WriteLine("--------------------- Initialization -------------------------");

            if ( merchantID == null || merchantID.Trim().Equals("") ||
                accessKeyID == null || accessKeyID.Trim().Equals("") ||
                secretKeyID == null || secretKeyID.Trim().Equals("")) {
                Console.WriteLine("Unable to initialize program with arguments:\n" +
                    "\tMerchant ID: " + merchantID + "\n" +
                    "\tAccess Key ID: " + accessKeyID + "\n" +
                    "\tSecret Key ID: " + secretKeyID + "\n");
                Environment.Exit(1);
            }    
                
            // Begin Demo.

            Console.WriteLine("Initialized Program with arguments: \n" +
                    "\tMerchant ID: " + merchantID + "\n" +
                    "\tAccess Key ID: " + accessKeyID + "\n" +
                    "\tSecret Key ID: " + secretKeyID + "\n");

            runHtmlDemo(merchantID, accessKeyID, secretKeyID);

            runXmlDemo(merchantID, accessKeyID, secretKeyID);

        }

        private static void runHtmlDemo(String merchantID, String accessKeyID, String secretKeyID) {
            Console.WriteLine("------------------- HTML Cart Example ------------------");
            CartFactory factory = new MerchantHTMLCartFactory();
            SignatureCalculator calculator = new SignatureCalculator();

            String cart = factory.getSignatureInput(merchantID, accessKeyID);
            String merchantSignature = calculator.calculateRFC2104HMAC(cart, secretKeyID);
            String cartHTML = factory.getCartHTML(merchantID, accessKeyID, merchantSignature);

            Console.WriteLine("* Merchant Signature Input: " + cart);
            Console.WriteLine("* Generated Signature: " + merchantSignature);
            Console.WriteLine("* Generated Cart HTML: \n" + cartHTML);
            
            
        }

        private static void runXmlDemo(String merchantID, String accessKeyID, String secretKeyID) {

            CartFactory factory = new XMLCartFactory();
            SignatureCalculator calculator = new SignatureCalculator();
            

            String cart = factory.getSignatureInput(merchantID, accessKeyID);
            String merchantSignature = calculator.calculateRFC2104HMAC(cart, secretKeyID);
            String cartHTML = factory.getCartHTML(merchantID, accessKeyID, merchantSignature);

            Console.WriteLine("------------------- XML Cart Example ------------------\n");
            Console.WriteLine("* Merchant Signature Input: " + cart);
            Console.WriteLine("* Generated Signature: " + merchantSignature);
            Console.WriteLine("* Generated Cart HTML: \n" + cartHTML);
            

        }
    }
}

