using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
using Amazon.Cba.Signature.Common.Cart;

/**
 * Returns a simple static cart to generate a signature from.
 * 
 * Copyright 2007-2011 Amazon.com, Inc., or its affiliates. All Rights Reserved. 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 * 		http://aws.amazon.com/apache2.0/
 * 
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

namespace Amazon.Cba.Signature.Demo
{
    class MerchantHTMLCartFactory : HTMLCartFactory
    {
	/**
	 * Replace with your own cart here to try out
	 * different promotions, tax, shipping, etc. 
	 */
        protected override SortedDictionary<String, String> getCartMap(String merchantID, String awsAccessKeyID)
        {

            SortedDictionary<string, string> parameterMap = new SortedDictionary<string, string>();

            parameterMap.Add("item_merchant_id_1", merchantID);
            parameterMap.Add("item_title_1", "Red Fish");
            parameterMap.Add("item_sku_1", "RedFish123");
            parameterMap.Add("item_description_1", "A red fish packed in spring water.");
            parameterMap.Add("item_price_1", "19.99");
            parameterMap.Add("item_quantity_1", "1");
            parameterMap.Add("currency_code", "INR");
            parameterMap.Add("item_custom_data", "my custom data");
            parameterMap.Add("cart_custom_data", "some cart info");
            parameterMap.Add("aws_access_key_id", awsAccessKeyID);
            

            return parameterMap;
       }

        /*
         * Construct a very basic cart with one item.
         */
        override
        public String getSignatureInput(String merchantID, String awsAccessKeyID)
        {
            return getSignatureInput(getCartMap(merchantID, awsAccessKeyID));
        }
    }
}

