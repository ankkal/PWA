using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.Web;

/**
 * A simple class that demostrates how to generate a signature with the
 * user specified paramters: Merchant ID, AWS/MWS Access Key ID and AWS/MWS Secret Key ID
 * 
 * Copyright 2007-2011 Amazon.com, Inc., or its affiliates. All Rights Reserved. 
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 * 
 * 		http://aws.amazon.com/apache2.0/
 * 
 * or in the "license" file accompanying this file.
 * This file is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language
 * governing permissions and limitations under the License.
 */

namespace Amazon.Cba.Signature.Common
{
    public class SignatureCalculator
    {
        public SignatureCalculator()
        {
        }

        public String calculateRFC2104HMAC(String data, String key)
        {
            String result = null;

            KeyedHashAlgorithm algorithm = new HMACSHA1();
           
            Encoding encoding = new UTF8Encoding();

            algorithm.Key = encoding.GetBytes(key);

            result =  Convert.ToBase64String(algorithm.ComputeHash(encoding.GetBytes(data.ToCharArray()))); 
            
            return result;
        }
    }
}
