<?php
class ModelPaymentPwa extends Model {
	
	public function install() {
		$this->db->query('	
		CREATE TABLE IF NOT EXISTS `'. DB_PREFIX .'pwa_orders` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `opencart_order_id` varchar(100) NOT NULL,
		  `amazon_order_id` varchar(100) NOT NULL,
		  `shipping_service` varchar(100) NOT NULL,
		  `easyship_status` varchar(100) NULL,
		  `easyship_TFM_status` varchar(100) NULL,
		  `payment_method` varchar(100) NULL,
		 `_non_received` varchar(10) NOT NULL DEFAULT "0",
		 `order_type` varchar(50) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;');
		
		$this->db->query('	
		CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'pwa_iopn_records` (
		  `id` bigint(20) NOT NULL AUTO_INCREMENT,
		  `uuid` varchar(100) NOT NULL,
		  `timestamp` datetime NOT NULL,
		  `notification_type` varchar(50) NOT NULL,
		  `notification_reference_id` varchar(100) NOT NULL,
		  `amazon_order_id` varchar(50) NOT NULL,
		  `status` varchar(20) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;');

		$this->db->query('	
		CREATE TABLE IF NOT EXISTS `' . DB_PREFIX . 'pwa_mws_report_cron` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `created_before` varchar(80) NOT NULL,
		  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;');

		$this->db->query('
		CREATE TABLE IF NOT EXISTS `'. DB_PREFIX .'pwa_mws_order_cron` (
		  `id` int(11) NOT NULL AUTO_INCREMENT,
		  `created_before` varchar(80) NOT NULL,
		  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;');
		
		if(class_exists('VQMod')) {
			$this->db->query('ALTER TABLE `'. DB_PREFIX .'product` ADD `pwa_easyship_length` INT NULL, ADD `pwa_easyship_width` INT NULL, ADD `pwa_easyship_height` INT NULL, ADD `pwa_easyship_category` VARCHAR(50) NULL, ADD `pwa_easyship_hazmat` VARCHAR(10) NULL, ADD `pwa_easyship_min_days` INT NULL, ADD `pwa_easyship_max_days` INT NULL, ADD `pwa_easyship_weight` INT NULL');	
		} else {
		
			$query = $this->db->query('SELECT * FROM `' . DB_PREFIX . 'attribute_group_description` WHERE name = "Easy Ship"');
			
			if(!$query->rows) {
				$language_id = (int)$this->config->get('config_language_id');
				$this->db->query("INSERT INTO " . DB_PREFIX . "attribute_group SET sort_order = '0'");
				$attribute_group_id = (int)$this->db->getLastId();
				
				$this->db->query("INSERT INTO " . DB_PREFIX . "attribute_group_description SET attribute_group_id = '" . $attribute_group_id . "', language_id = '" . $language_id . "', name = 'Easy Ship'");
				
				$attribute_name = array('Easy Ship Length(cm)', 'Easy Ship Width(cm)', 'Easy Ship Height(cm)','Easy Ship GI', 'Easy Ship Hazmat', 'Easy Ship Handling Time Minimum(in days)', 'Easy Ship Handling Time Maximum(in days)');

				foreach ($attribute_name as $name) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "attribute SET attribute_group_id = '" . $attribute_group_id . "', sort_order = '0'");
					$attribute_id = (int)$this->db->getLastId();
					$this->db->query("INSERT INTO " . DB_PREFIX . "attribute_description SET attribute_id = '" .$attribute_id . "', language_id = '" .$language_id . "', name = '" . $name . "'");
				}
			}
		}
	}
	
	
	public function uninstall() {
		//$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "pwa_orders`;");
		//$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "pwa_iopn_records`;");
		//$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "pwa_mws_report_cron`;");
		//$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "pwa_mws_order_cron`;");
		
		//if(class_exists('VQMod')) {
		//	$this->db->query('ALTER TABLE `'. DB_PREFIX .'product` DROP `pwa_easyship_length`, DROP `pwa_easyship_width`, DROP `pwa_easyship_height`, DROP `pwa_easyship_category`, DROP `pwa_easyship_hazmat`, DROP `pwa_easyship_min_days`, DROP `pwa_easyship_max_days`, DROP `pwa_easyship_weight`');
		//}
	}
	
	
	public function order_easyship_shipment($order_id) {
		 $order_query = $this->db->query('SELECT amazon_order_id,easyship_status,payment_method,easyship_TFM_status FROM `' . DB_PREFIX . 'pwa_orders` WHERE opencart_order_id = '.$order_id.'');
		 if ($order_query->num_rows) {
			  return $order_query->row;
		  }else{
			  return array('easyship_status'=>'','payment_method'=>'','easyship_TFM_status'=>'','amazon_order_id'=>'');
		  }
	}
	
	public function updateProductEasyship($product_id)
	{
		$this->db->query("UPDATE " . DB_PREFIX . "product SET pwa_easyship_length = '" . $this->session->data['product_data']['pwa_easyship_length'] . "', pwa_easyship_width = '" . $this->session->data['product_data']['pwa_easyship_width'] . "', pwa_easyship_height = '" . $this->session->data['product_data']['pwa_easyship_height'] . "',pwa_easyship_category= '" . $this->session->data['product_data']['pwa_easyship_category'] . "',pwa_easyship_hazmat= '" . $this->session->data['product_data']['pwa_easyship_hazmat'] . "',pwa_easyship_min_days = '" . $this->session->data['product_data']['pwa_easyship_min_days'] . "', pwa_easyship_max_days = '" . $this->session->data['product_data']['pwa_easyship_max_days']."',pwa_easyship_weight = '" . $this->session->data['product_data']['pwa_easyship_weight'] . "' where product_id = '" . (int)$product_id . "'");
	}
	
	public function product_easyshipdata($product_id)
	{
		$easyship_data = $this->db->query("SELECT pwa_easyship_length,pwa_easyship_width,pwa_easyship_height, pwa_easyship_category,pwa_easyship_hazmat,pwa_easyship_min_days,pwa_easyship_max_days,pwa_easyship_weight FROM ".DB_PREFIX."product where product_id='".(int)$product_id."'");
		if ($easyship_data->num_rows) {
			return $easyship_data->row;
		}
		else{
			return '';
		}

	}
	
}
