<?php
// Heading
$_['heading_title'] 			= 'Pay with Amazon - India';

// Text
$_['text_edit_settings']		= 'Amazon Settings';
$_['text_edit_order_settings']	= 'IOPN And MWS settings';
$_['text_edit_button_settings']	= 'PWA Button settings';
$_['text_easyship_settings']	= 'Easyship Settings';
$_['text_mail_easyship']	    = 'Shipment Email Settings';
$_['text_edit']					= 'Edit Pay with Amazon';
$_['text_payment']				= 'Payments';
$_['text_module']				= 'Modules';
$_['text_success']				= 'Success: Pay with Amazon module has been updated.';
$_['text_pwa']			        = '<img src="view/image/payment/pwa.png" alt="Pay with Amazon" title="Pay with Amazon" style="border: 1px solid #EEEEEE;" />';


// Error
$_['error_permissions']			= 'You do not have permissions to modify this module';
$_['error_secret_key']			= 'Secret Key is required';
$_['error_access_key']		    = 'Access Key is required';
$_['error_merchant_id']		    = 'Merchant ID is required';
$_['error_easyship_price']		= 'Please enter valid price.';
$_['error_easyship_handling_days']		    = 'Please enter valid days.';
$_['error_easyship_handling_max_days']		= 'Max days should be greater than min days.';

