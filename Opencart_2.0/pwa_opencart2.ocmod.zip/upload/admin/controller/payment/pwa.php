<?php
class ControllerPaymentPwa extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('payment/pwa');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('setting/setting');

		$this->load->model('payment/pwa');

		if (($this->request->server['REQUEST_METHOD'] == 'POST' && $this->validate())) {
			
			$this->model_setting_setting->editSetting('pwa', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->cache->delete('pwa');

			$this->response->redirect($this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_edit_settings'] = $this->language->get('text_edit_settings');
		$data['text_edit_order_settings'] = $this->language->get('text_edit_order_settings');
		$data['text_edit_button_settings'] = $this->language->get('text_edit_button_settings');
		$data['text_easyship_settings'] = $this->language->get('text_easyship_settings');
		$data['text_mail_easyship'] = $this->language->get('text_mail_easyship');
		
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_payment'] = $this->language->get('text_payment');
		$data['text_module'] = $this->language->get('text_module');
		
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['cancel'] = $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL');
		$data['form_action'] = $this->url->link('payment/pwa', 'token=' . $this->session->data['token'], 'SSL');


		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		
		if (isset($this->error['merchant_id'])) {
			$data['error_merchant_id'] = $this->error['merchant_id'];
		} else {
			$data['error_merchant_id'] = '';
		}		
		
		if (isset($this->error['access_key'])) {
			$data['error_access_key'] = $this->error['access_key'];
		} else {
			$data['error_access_key'] = '';
		}	
				
		if (isset($this->error['secret_key'])) {
			$data['error_secret_key'] = $this->error['secret_key'];
		} else {
			$data['error_secret_key'] = '';
		}
		
		if (isset($this->error['easyship_price'])) {
			$data['error_easyship_price'] = $this->error['easyship_price'];
		} else {
			$data['error_easyship_price'] = '';
		}
		
		if (isset($this->error['easyship_shipping_days_min'])) {
			$data['error_easyship_shipping_days_min'] = $this->error['easyship_shipping_days_min'];
		} else {
			$data['error_easyship_shipping_days_min'] = '';
		}
		
		if (isset($this->error['easyship_shipping_days_max'])) {
			$data['error_pwa_easyship_shipping_days_max'] = $this->error['easyship_shipping_days_max'];
		} else {
			$data['error_pwa_easyship_shipping_days_max'] = '';
		}


		/* Initial values for form. */
		if (isset($this->request->post['pwa_status'])) {
			$data['pwa_status'] = $this->request->post['pwa_status'];
		} else {
			$data['pwa_status'] = $this->config->get('pwa_status');
		}
		
		if (isset($this->request->post['pwa_merchant_id'])) {
			$data['pwa_merchant_id'] = $this->request->post['pwa_merchant_id'];
		} elseif ($this->config->get('pwa_merchant_id')) {
			$data['pwa_merchant_id'] = $this->config->get('pwa_merchant_id');
		} else {
			$data['pwa_merchant_id'] = '';
		}

		if (isset($this->request->post['pwa_access_key'])) {
			$data['pwa_access_key'] = $this->request->post['pwa_access_key'];
		} else {
			$data['pwa_access_key'] = $this->config->get('pwa_access_key');
		}

		if (isset($this->request->post['pwa_secret_key'])) {
			$data['pwa_secret_key'] = $this->request->post['pwa_secret_key'];
		} else {
			$data['pwa_secret_key'] = $this->config->get('pwa_secret_key');
		}
		
		if (isset($this->request->post['pwa_marketplace_id'])) {
			$data['pwa_marketplace_id'] = $this->request->post['pwa_marketplace_id'];
		} else {
			$data['pwa_marketplace_id'] = $this->config->get('pwa_marketplace_id');
		}	
		
		if (isset($this->request->post['pwa_environment'])) {
			$data['pwa_environment'] = $this->request->post['pwa_environment'];
		} else {
			$data['pwa_environment'] = $this->config->get('pwa_environment');
		}
		
		if (isset($this->request->post['pwa_btn_show'])) {
			$data['pwa_btn_show'] = $this->request->post['pwa_btn_show'];
		} else {
			$data['pwa_btn_show'] = $this->config->get('pwa_btn_show');
		}

		if (isset($this->request->post['pwa_order_update_api'])) {
			$data['pwa_order_update_api'] = $this->request->post['pwa_order_update_api'];
		} else {
			$data['pwa_order_update_api'] = $this->config->get('pwa_order_update_api');
		}
		
		if (isset($this->request->post['pwa_iopn_dump'])) {
			$data['pwa_iopn_dump'] = $this->request->post['pwa_iopn_dump'];
		} else {
			$data['pwa_iopn_dump'] = $this->config->get('pwa_iopn_dump');
		}
		
		if (isset($this->request->post['pwa_mws_order_dump'])) {
			$data['pwa_mws_order_dump'] = $this->request->post['pwa_mws_order_dump'];
		} else {
			$data['pwa_mws_order_dump'] = $this->config->get('pwa_mws_order_dump');
		}
		
		if (isset($this->request->post['pwa_mws_report_dump'])) {
			$data['pwa_mws_report_dump'] = $this->request->post['pwa_mws_report_dump'];
		} else {
			$data['pwa_mws_report_dump'] = $this->config->get('pwa_mws_report_dump');
		}
		
		if (isset($this->request->post['pwa_show_cart_button'])) {
			$data['pwa_show_cart_button'] = $this->request->post['pwa_show_cart_button'];
		} else {
			$data['pwa_show_cart_button'] = $this->config->get('pwa_show_cart_button');
		}
		
		if (isset($this->request->post['pwa_btn_color'])) {
			$data['pwa_btn_color'] = $this->request->post['pwa_btn_color'];
		} else {
			$data['pwa_btn_color'] = $this->config->get('pwa_btn_color');
		}
		
		if (isset($this->request->post['pwa_btn_size'])) {
			$data['pwa_btn_size'] = $this->request->post['pwa_btn_size'];
		} else {
			$data['pwa_btn_size'] = $this->config->get('pwa_btn_size');
		}
		
		if (isset($this->request->post['pwa_easyship_status'])) {
			$data['pwa_easyship_status'] = $this->request->post['pwa_easyship_status'];
		} else {
			$data['pwa_easyship_status'] = $this->config->get('pwa_easyship_status');
		}

		if (isset($this->request->post['pwa_easyship_shipping_override'])) {
			$data['pwa_easyship_shipping_override'] = $this->request->post['pwa_easyship_shipping_override'];
		} else {
			$data['pwa_easyship_shipping_override'] = $this->config->get('pwa_easyship_shipping_override');
		}

		if (isset($this->request->post['pwa_easyship_service_level'])) {
			$data['pwa_easyship_service_level'] = $this->request->post['pwa_easyship_service_level'];
		} else {
			$data['pwa_easyship_service_level'] = $this->config->get('pwa_easyship_service_level');
		}

		if (isset($this->request->post['pwa_easyship_shipping_rate'])) {
			$data['pwa_easyship_shipping_rate'] = $this->request->post['pwa_easyship_shipping_rate'];
		} else {
			$data['pwa_easyship_shipping_rate'] = $this->config->get('pwa_easyship_shipping_rate');
		}
		
		if (isset($this->request->post['pwa_easyship_price'])) {
			$data['pwa_easyship_price'] = $this->request->post['pwa_easyship_price'];
		} else {
			$data['pwa_easyship_price'] = $this->config->get('pwa_easyship_price');
		}
		
		if (isset($this->request->post['pwa_easyship_shipping_days_min'])) {
			$data['pwa_easyship_shipping_days_min'] = $this->request->post['pwa_easyship_shipping_days_min'];
		} else {
			$data['pwa_easyship_shipping_days_min'] = $this->config->get('pwa_easyship_shipping_days_min');
		}
		
		if (isset($this->request->post['pwa_easyship_shipping_days_max'])) {
			$data['pwa_easyship_shipping_days_max'] = $this->request->post['pwa_easyship_shipping_days_max'];
		} else {
			$data['pwa_easyship_shipping_days_max'] = $this->config->get('pwa_easyship_shipping_days_max');
		}
		
		if (isset($this->request->post['pwa_easyship_customer_mail'])) {
			$data['pwa_easyship_customer_mail'] = $this->request->post['pwa_easyship_customer_mail'];
		} else {
			$data['pwa_easyship_customer_mail'] = $this->config->get('pwa_easyship_customer_mail');
		}
		
		if (isset($this->request->post['pwa_easyship_mail_to'])) {
			$data['pwa_easyship_mail_to'] = $this->request->post['pwa_easyship_mail_to'];
		} else {
			$data['pwa_easyship_mail_to'] = $this->config->get('pwa_easyship_mail_to');
		}
		
		if (isset($this->request->post['pwa_easyship_category'])) {
			$data['pwa_easyship_category'] = $this->request->post['pwa_easyship_category'];
		} else {
			$data['pwa_easyship_category'] = $this->config->get('pwa_easyship_category');
		}
		
		if (isset($this->request->post['pwa_easyship_hazmat'])) {
			$data['pwa_easyship_hazmat'] = $this->request->post['pwa_easyship_hazmat'];
		} else {
			$data['pwa_easyship_hazmat'] = $this->config->get('pwa_easyship_hazmat');
		}
		
		if (isset($this->request->post['pwa_easyship_min_days'])) {
			$data['pwa_easyship_min_days'] = $this->request->post['pwa_easyship_min_days'];
		} else {
			$data['pwa_easyship_min_days'] = $this->config->get('pwa_easyship_min_days');
		}
		
		if (isset($this->request->post['pwa_easyship_max_days'])) {
			$data['pwa_easyship_max_days'] = $this->request->post['pwa_easyship_max_days'];
		} else {
			$data['pwa_easyship_max_days'] = $this->config->get('pwa_easyship_max_days');
		}
		
		$data['base_url'] = str_replace('admin/','',HTTP_SERVER); 
		$data['base_ssl_url'] = str_replace('http','https',$data['base_url']); 
		
		/* Breadcrumb. */
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);
		
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_payment'),
			'href' => $this->url->link('extension/payment', 'token=' . $this->session->data['token'], 'SSL')
		);
		
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('payment/pwa', 'token=' . $this->session->data['token'], 'SSL')
		);

		/* Render some output. */
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('payment/pwa.tpl', $data));
	}


	/* Check user input. */
	private function validate() {
		if (!$this->user->hasPermission('modify', 'payment/pwa')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['pwa_merchant_id']) {
			$this->error['merchant_id'] = $this->language->get('error_merchant_id');
		}

		if (!$this->request->post['pwa_access_key']) {
			$this->error['access_key'] = $this->language->get('error_access_key');
		}

		if (!$this->request->post['pwa_secret_key']) {
			$this->error['secret_key'] = $this->language->get('error_secret_key');
		}
		
		if ($this->request->post['pwa_easyship_shipping_override'] == 'yes' && (trim($this->request->post['pwa_easyship_price']) == '' || trim($this->request->post['pwa_easyship_price']) == '0') ) {
			$this->error['easyship_price'] = $this->language->get('error_easyship_price');
		}
		
		if ($this->request->post['pwa_easyship_shipping_override'] == 'yes' && (trim($this->request->post['pwa_easyship_shipping_days_min']) == '' || trim($this->request->post['pwa_easyship_shipping_days_min']) == '0') ) {
			$this->error['easyship_shipping_days_min'] = $this->language->get('error_easyship_handling_days');
		}
		
		if ($this->request->post['pwa_easyship_shipping_override'] == 'yes' && (trim($this->request->post['pwa_easyship_shipping_days_max']) == '' || trim($this->request->post['pwa_easyship_shipping_days_max']) == '0') ) {
			$this->error['easyship_shipping_days_max'] = $this->language->get('error_easyship_handling_days');
		}
		
		if ($this->request->post['pwa_easyship_shipping_override'] == 'yes' && ( trim($this->request->post['pwa_easyship_shipping_days_max']) < trim($this->request->post['pwa_easyship_shipping_days_min']) ) ) {
			$this->error['easyship_shipping_days_max'] = $this->language->get('error_easyship_handling_max_days');
		}

		return !$this->error;
	}
	
	
	public function install() {
		$this->load->model('payment/pwa');

		$this->load->model('setting/setting');

		$this->model_payment_pwa->install();
		
		if(VERSION == '2.0.0.0') {
			$this->load->model('tool/event');
			$this->model_tool_event->addEvent('pwa_cancel_order', 'post.order.history.add', 'payment/pwa/cancel_amazon_order');
			$this->model_tool_event->addEvent('pwa_easy_ship', 'pre.admin.add.product', 'payment/pwa/on_pre_add_product');
			$this->model_tool_event->addEvent('pwa_easy_ship', 'post.admin.add.product', 'payment/pwa/on_post_add_product');
			$this->model_tool_event->addEvent('pwa_easy_ship', 'pre.admin.edit.product', 'payment/pwa/on_pre_edit_product');
			$this->model_tool_event->addEvent('pwa_easy_ship', 'post.admin.edit.product', 'payment/pwa/on_post_edit_product');
		}
		else
		{
			$this->load->model('extension/event');
			$this->model_extension_event->addEvent('pwa_cancel_order', 'post.order.history.add', 'payment/pwa/cancel_amazon_order');
			$this->model_extension_event->addEvent('pwa_easy_ship', 'pre.admin.product.add', 'payment/pwa/on_pre_add_product');
			$this->model_extension_event->addEvent('pwa_easy_ship', 'post.admin.product.add', 'payment/pwa/on_post_add_product');
			$this->model_extension_event->addEvent('pwa_easy_ship', 'pre.admin.product.edit', 'payment/pwa/on_pre_edit_product');
			$this->model_extension_event->addEvent('pwa_easy_ship', 'post.admin.product.edit', 'payment/pwa/on_post_edit_product');
		}
	}
	
	
	public function uninstall() {
		$this->load->model('payment/pwa');

		$this->model_payment_pwa->uninstall();
		
		if(VERSION == '2.0.0.0') {
			$this->load->model('tool/event');
			$this->model_tool_event->deleteEvent('pwa_cancel_order');
			$this->model_tool_event->deleteEvent('pwa_easy_ship');
		}
		else
		{
			$this->load->model('extension/event');
			$this->model_extension_event->deleteEvent('pwa_cancel_order');
			$this->model_extension_event->deleteEvent('pwa_easy_ship');
		}
	}
	
	
	public function on_pre_add_product($data) {
			$this->session->data['product_data']= $data;
	}
	
	
	public function on_post_add_product($product_id) {
	        $this->updateProduct($product_id);
	}
	
	
	public function on_pre_edit_product($data) {
		    if(!array_key_exists('pwa_easyship_category' , $data))
		    {
				$data['pwa_easyship_category'] = '';
			}
			if(!array_key_exists('pwa_easyship_hazmat' , $data))
		    {
				$data['pwa_easyship_hazmat'] = '';
			}
			$this->session->data['product_data']= $data;
	}
	
	
	public function on_post_edit_product($product_id) {
		$this->updateProduct($product_id);
	}
	
	
	public function updateProduct($product_id) {
		$this->load->model('payment/pwa');
	    $this->model_payment_pwa->updateProductEasyship($product_id);
	    unset($this->session->data['product_data']);
	}
	
	
	public function easyshipdata() {
		$response = array();
		if(isset($this->request->get['product_id'])){
			$this->load->model('payment/pwa');
			$response = $this->model_payment_pwa->product_easyshipdata($this->request->get['product_id']);
		}
		$this->response->setOutput(json_encode($response));
	}
	
	
	public function easyship_shipment(){
		if(isset($this->request->get['order_id']) && $this->request->get['order_id'] > 0){
			$order_id = $this->request->get['order_id'];
			
			$this->load->model('payment/pwa');
			$response = $this->model_payment_pwa->order_easyship_shipment($order_id);
			echo json_encode($response);
		}
	}
	
	
}
