<?php
$_['text_title'] = 'Pay with Amazon';

$_['thankyou_heading_title'] = 'Thankyou Page';


?>
