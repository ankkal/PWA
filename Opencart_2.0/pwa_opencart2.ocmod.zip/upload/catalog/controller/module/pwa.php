<?php
class ControllerModulePwa extends Controller {
	
	public function index() {
		
		$this->language->load('module/pwa');
		
		$this->load->model('payment/pay_with_amazon');
		$this->load->model('checkout/coupon');
		$extensionModel = 'model_extension_extension';
        $this->load->model('extension/extension');
        
        if( ($this->config->get('pwa_btn_show') == 'notlogged' || ( $this->config->get('pwa_btn_show') == 'logged' && $this->customer->isLogged() ) ) && $this->config->get('pwa_show_cart_button') == '1')
        {
			$data['merchantID']   =  $this->config->get('pwa_merchant_id');
			$data['accessKeyID']  =  $this->config->get('pwa_access_key');
			$data['secretKeyID']  =  $this->config->get('pwa_secret_key');
			$data['btn_color']    =  $this->config->get('pwa_btn_color');
			$data['btn_size']     =  $this->config->get('pwa_btn_size');
			
			$total_data = array();
			$total = 0;
			$taxes = $this->cart->getTaxes();

			$sort_order = array();

			$results = $this->model_extension_extension->getExtensions('total');

			foreach ($results as $key => $value) {
				$sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
			}

			array_multisort($sort_order, SORT_ASC, $results);

			foreach ($results as $result) {
				if ($this->config->get($result['code'] . '_status')) {
						$this->load->model('total/' . $result['code']);

						$this->{'model_total_' . $result['code']}->getTotal($total_data, $total, $taxes);
				}
			}
			
			$data['total_data'] = array();
			$data['total_data'] = $total_data;
			
			$data['cart'] = $this->model_payment_pay_with_amazon->getSignatureInput($data['merchantID'], $data['accessKeyID']);
			$data['signature'] = $this->model_payment_pay_with_amazon->calculateRFC2104HMAC($data['cart'],$data['secretKeyID']);
			$data['cartHtml'] = $this->model_payment_pay_with_amazon->getCartHTML($data['merchantID'], $data['accessKeyID'],$data['signature']);
			$data['cartvalue'] = $this->model_payment_pay_with_amazon->getCartValue($data['merchantID'], $data['accessKeyID'],$data['signature']);
			
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/pwa.tpl')) {
				return $this->load->view($this->config->get('config_template') . '/template/payment/pwa.tpl', $data);
			} else {
				return $this->load->view('default/template/payment/pwa.tpl', $data);
			}
		}
	}
	
}
