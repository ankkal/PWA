<?php

require_once('config.inc.php');

class ControllerPaymentMwsReportGetReportRequestList extends Controller {
	
	public $serviceUrl = MWS_ENDPOINT_URL;

	/**
	 * Include required core files and classes.
	 */
	public function includes() {
		require_once('MarketplaceWebService/Client.php');
		require_once('MarketplaceWebService/Exception.php');
		require_once('MarketplaceWebService/Model/GetReportRequestListRequest.php');	
	}
	
	
	function init(){
		
		$this->includes();
		
		$config = array (
		  'ServiceURL' => $this->serviceUrl,
		  'ProxyHost' => null,
		  'ProxyPort' => -1,
		  'MaxErrorRetry' => 3,
		);
		
	    $service = new MarketplaceWebService_Client(
		 AWS_ACCESS_KEY_ID, 
		 AWS_SECRET_ACCESS_KEY, 
		 $config,
		 APPLICATION_NAME,
		 APPLICATION_VERSION);
	 
		$request = new MarketplaceWebService_Model_GetReportRequestListRequest();
		$request->setMerchant(MERCHANT_ID);
		$request->setReportTypeList(array('0'=>'_GET_ORDERS_DATA_'));
		$request->setReportProcessingStatusList(array('0'=>'_DONE_'));
		$request->setMaxCount(20);
		
		$this->load->model('payment/pwa');
		$last_request_date = $this->model_payment_pwa->get_last_request();
		
		
		if($last_request_date) {
			$time = $last_request_date;
		}
		else{
			$dateTime = new DateTime('-3 day', new DateTimeZone('UTC'));
			$time = $dateTime->format(DATE_ISO8601);  
		}
		$request->setRequestedFromDate($time);
		
		$this->invokeGetReportRequestList($service, $request);
		
	}
	                                                          

    function invokeGetReportRequestList(MarketplaceWebService_Interface $service, $request) {
	  try {
              $response = $service->getReportRequestList($request);
              
              if ($response->isSetGetReportRequestListResult()) { 
				 
                    $getReportRequestListResult = $response->getGetReportRequestListResult();
                    $reportRequestInfoList = $getReportRequestListResult->getReportRequestInfoList();
                    
                    
                    foreach ($reportRequestInfoList as $reportRequestInfo) {
						
						  if( ($reportRequestInfo->isSetReportType() && $reportRequestInfo->getReportType() == '_GET_ORDERS_DATA_') && ($reportRequestInfo->isSetReportProcessingStatus() && $reportRequestInfo->getReportProcessingStatus() == '_DONE_') )
						  {
							  if ($reportRequestInfo->isSetReportRequestId()) 
							  {
								  $ReportRequestId = $reportRequestInfo->getReportRequestId();
							  }
							  
							  if ($reportRequestInfo->isSetGeneratedReportId()) 
							  {
								 $GeneratedReportId = $reportRequestInfo->getGeneratedReportId();
								
								 if($GeneratedReportId == '' && $ReportRequestId != '') {
									 $GeneratedReportId = $data = $this->load->controller( 'payment/mws_report/GetReportList/init', $ReportRequestId );
									 $data = $this->load->controller( 'payment/mws_report/GetReport/init', $GeneratedReportId );
								 }else{ 
									 $data = $this->load->controller( 'payment/mws_report/GetReport/init', $GeneratedReportId );
								 }
								 
								 
								 $xml = simplexml_load_string($data);
								 
								$mws_report_dump = $this->config->get('pwa_mws_report_dump');
								if( $mws_report_dump == '1' && $this->config->get('pwa_mws_report_dump_url') != ''){

									$dir = $this->config->get('pwa_mws_report_dump_url');
									if (!file_exists($dir) && !is_dir($dir)) {
										mkdir($dir, 0777);
									} 

									$filename = $dir.$GeneratedReportId.'_mws_report';
									$myfile = fopen($filename, "w");
									fwrite($myfile, $data);
									fclose($myfile);
								 }
								 
								 
								 foreach($xml->Message as $orderdetail) {
										$AmazonOrderID = (string)$orderdetail->OrderReport->AmazonOrderID;
										
										$order_id = $this->model_payment_pwa->order_exist($AmazonOrderID);
										if(!$order_id) 
										{
											$ClientRequestId = 0;
											foreach($orderdetail->OrderReport->Item as $item) {
												foreach($item->CustomizationInfo as $info) {
												
													$info_type = (string)$info->Type;	
													if($info_type == 'url') {
														$info_array = explode(',',$info->Data);
														$customerId_array = explode('=',$info_array[0]);
														$ClientRequestId = $customerId_array[1];
														break;
													}
												}
											}
										
											if(substr($ClientRequestId,0,1) == 'c')
											{
												$already_exist = 0;
											}
											else
											{
												if(substr($ClientRequestId,0,1) == 'o')
												{
													$order_id = str_replace('o','',$ClientRequestId);
													$already_exist = 1;
												}
												else
												{
													$already_exist = 0;
												}
											}
											
											if($already_exist == 0)
											{
												$array['AmazonOrderID'] =  $AmazonOrderID;
												$array['store_id'] = $this->config->get('config_store_id');
												$array['store_name'] = $this->config->get('config_name');
												$array['store_url'] = $this->config->get('config_url');
												$array['language_id'] = (int)$this->config->get('config_language_id');
												$array['currency_id'] = $this->currency->getId();
												$array['currency_code'] = $this->currency->getCode();
												$array['currency_value'] = $this->currency->getValue($this->currency->getCode());
												$array['ip'] = $this->request->server['REMOTE_ADDR'];
												
												if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
													$array['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
												} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
													$array['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
												} else {
													$array['forwarded_ip'] = '';
												}

												if (isset($this->request->server['HTTP_USER_AGENT'])) {
													$array['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
												} else {
													$array['user_agent'] = '';
												}

												if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
													$array['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
												} else {
													$array['accept_language'] = '';
												}	
												
												$order_id = $this->model_payment_pwa->create_order($array,false);
												
												$this->update_order_detail($order_id , $orderdetail);
											}
											else
											{
												$param['AmazonOrderID'] = $AmazonOrderID;
												$param['OrderId'] = $order_id;
												$order_id = $this->model_payment_pwa->create_order($param,true);
												
												$this->update_order_detail($order_id , $orderdetail);
											}
										}
										else 
										{
											$this->update_order_detail($order_id , $orderdetail);
										}
								 }
								
							  }
						  }
                    }
                    
                     $dateTime = new DateTime('now', new DateTimeZone('UTC'));
					 $time = $dateTime->format(DATE_ISO8601); 
					 
					 $this->model_payment_pwa->update_last_request($time);
					 
                } 
               
     } catch (MarketplaceWebService_Exception $ex) {
        $message  =  'MWS Report API : Caught Exception : '.$ex->getMessage(). "\n";
		$message .= "Response Status Code: " . $ex->getStatusCode() . "\n";
		$message .= "Error Code: " . $ex->getErrorCode() . "\n";
		$message .= "Error Type: " . $ex->getErrorType() . "\n";

		$param['message'] = $message;
		$this->load->controller( 'payment/pwa/generate_log', $param );
     }
 }
 
 
	public function update_order_detail($order_id , $orderdetail) {
		$this->load->model('payment/pwa');
			
		$non_received = $this->model_payment_pwa->check_iopn_received($order_id);
		if($non_received == 0)
		{
			$this->update_cart_by_xml($order_id , $orderdetail);
			
			$this->model_payment_pwa->iopn_received($order_id);	
		}	
	}
	
	
	public function update_cart_by_xml($order_id,$orderdetail){
		
		foreach($orderdetail->OrderReport->Item as $item) {
				foreach($item->CustomizationInfo as $info) {
				
				$info_type = (string)$info->Type;	
				if($info_type == 'url') {
					$info_array = explode(',',$info->Data);
					$customerId_array = explode('=',$info_array[0]);
					$ClientRequestId = $customerId_array[1];
					break;
				}
			}
		}

		if(strlen($ClientRequestId) < 9)
	    {
			$this->update_cart_by_site_xml($order_id,$orderdetail);
		}
		else
		{
			$this->update_cart_by_junglee_xml($order_id,$orderdetail);
		}

	}


	public function update_cart_by_site_xml($order_id,$orderdetail){
		$total_amount = 0;
      	$total_principal = 0;
      	$shipping_amount = 0;
      	$total_promo = 0;
      	$ClientRequestId = 0;
        
        $AmazonOrderID = (string)$orderdetail->OrderReport->AmazonOrderID;
			
		foreach($orderdetail->OrderReport->Item as $item) {
			$Principal_Promotions = 0;
      		$Shipping_Promotions  = 0;
      		
    		foreach($item->ItemPrice->Component as $amount_type) {
				$item_charge_type = (string)$amount_type->Type;	
				if($item_charge_type == 'Principal') {
					$Principal = abs((float)$amount_type->Amount);
				}
				if($item_charge_type == 'Shipping') {
					$Shipping = abs((float)$amount_type->Amount);
				}
				if($item_charge_type == 'Tax') {
					$Tax = abs((float)$amount_type->Amount);
				}
				if($item_charge_type == 'ShippingTax') {
					$ShippingTax = abs((float)$amount_type->Amount);
				}
			}
			
			if( !empty($item->Promotion) ) {
				foreach($item->Promotion as $promotions){
					foreach($promotions->Component as $promotion_amount_type) {
						$promotion_type = (string)$promotion_amount_type->Type;
						
						if($promotion_type == 'Shipping') {
							$Shipping_Promotions += abs((float)$promotion_amount_type->Amount);
						}
						
						if($promotion_type == 'Principal') {
							$Principal_Promotions += abs((float)$promotion_amount_type->Amount);
						}
					}
				}
			}
			
			$total_principal += $Principal;
			
			$total_amount += ($Principal - $Principal_Promotions) + ($Shipping - $Shipping_Promotions) ;
        	
			$shipping_amount += $Shipping + $Shipping_Promotions;
			
			$total_promo += $Principal_Promotions + $Shipping_Promotions;

			foreach($item->CustomizationInfo as $info) {
				
				$info_type = (string)$info->Type;	
				if($info_type == 'url') {
					$info_array = explode(',',$info->Data);
					$customerId_array = explode('=',$info_array[0]);
					$ClientRequestId = $customerId_array[1];
				}
			}
		}
		
		$ShippingServiceLevel = (string)$orderdetail->OrderReport->FulfillmentData->FulfillmentServiceLevel;
      	$this->model_payment_pwa->update_shipping($ShippingServiceLevel,$order_id);

	  	
		$email = (string)$orderdetail->OrderReport->BillingData->BuyerEmailAddress;
		$customer = array();
		 
		$cust_name = (string)$orderdetail->OrderReport->BillingData->BuyerName;
		$name_arr = explode(' ',$cust_name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $cust_name;
			$lastname = '.';
		}
			
		$password = $this->generate_password();
		$customer['firstname']   = $firstname;
		$customer['lastname']    = $lastname;
		$customer['email']       = $email;
		$customer['telephone']   = (string)$orderdetail->OrderReport->FulfillmentData->Address->PhoneNumber;
		$customer['password']    = $password;
		$customer['newsletter']  = 1;
	
		$country = $this->model_payment_pwa->get_country((string)$orderdetail->OrderReport->FulfillmentData->Address->CountryCode);
		if(empty($country))
		{
			$id_country = 99;
		}
		else
		{
			$id_country = $country['country_id'];
		}
		
		$name = (string)$orderdetail->OrderReport->FulfillmentData->Address->Name;
		$name_arr = explode(' ',$name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<=count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $name;
			$lastname = '.';
		}
		
		$zone_id = $this->model_payment_pwa->get_zone((string)$orderdetail->OrderReport->FulfillmentData->Address->StateOrRegion);
		$customer['address']['firstname']  =  $firstname;
		$customer['address']['lastname']   =  $lastname;
		$customer['address']['address_1']  =  (string)$orderdetail->OrderReport->FulfillmentData->Address->AddressFieldOne;
		$customer['address']['address_2']  =  (string)$orderdetail->OrderReport->FulfillmentData->Address->AddressFieldTwo;
		$customer['address']['city']       =  (string)$orderdetail->OrderReport->FulfillmentData->Address->City;
		$customer['address']['postcode']   =  (string)$orderdetail->OrderReport->FulfillmentData->Address->PostalCode;
		$customer['address']['country_id'] =  $id_country;
		$customer['address']['zone_id']    =  $zone_id;
		
		
		$ClientCustomerId = 0;
		if(substr($ClientRequestId,0,1) == 'c')
		{
			$ClientCustomerId = str_replace('c','',$ClientRequestId);
			$ClientRequestId = 0;
		}
		else
		{
			if(substr($ClientRequestId,0,1) == 'o')
			{
				$ClientRequestId = str_replace('o','',$ClientRequestId);
			}
			else
			{
				$ClientRequestId = $ClientRequestId;
			}
		}
			
			
		$customer_id = 0;
		if($order_id == $ClientRequestId)
		{
			  $customer_id = $this->model_payment_pwa->order_customer($order_id);
		}
		else
		{
			 if($ClientCustomerId == 0)
			 {
				  if ($this->config->get('config_checkout_guest')) {
			 	 
				  } else {
					  $customer_id =  $this->model_payment_pwa->customer_exist($email);
					  if(!$customer_id)
					  {
						$customer_id = $this->model_payment_pwa->add_customer($customer);
					  }
				  }
			  }
			  else
			  {
				  $customer_id = $ClientCustomerId;
			  }
		}
		
		$order = array();
		$order['customer_id'] = $customer_id;
		$order['order_id']   = $order_id;
		$order['customer_group_id'] = $this->config->get('config_customer_group_id');
		$order['firstname']  = $customer['firstname'];
		$order['lastname']   = $customer['lastname'];
		$order['email']      = $customer['email'];
		$order['telephone']  = $customer['telephone'];
		$order['payment_firstname']   = $customer['firstname'];
		$order['payment_lastname']    = $customer['lastname'];
		$order['payment_address_1']   = $customer['address']['address_1'];
		$order['payment_address_2']   = $customer['address']['address_2'];
		$order['payment_city']        = $customer['address']['city'];
		$order['payment_postcode']    = $customer['address']['postcode'];
		$order['payment_country']     = $country['name'];
		$order['payment_country_id']  = $customer['address']['country_id'];
		$order['payment_zone']  	  = (string)$orderdetail->OrderReport->FulfillmentData->Address->StateOrRegion;
		$order['payment_zone_id']  	  = $customer['address']['zone_id'];
		$order['shipping_firstname']  = $customer['address']['firstname'];
		$order['shipping_lastname']   = $customer['address']['lastname'];
		$order['shipping_address_1']  = $customer['address']['address_1'];
		$order['shipping_address_2']  = $customer['address']['address_2'];
		$order['shipping_city']       = $customer['address']['city'];
		$order['shipping_postcode']   = $customer['address']['postcode'];
		$order['shipping_country']    = $country['name'];
		$order['shipping_country_id'] = $customer['address']['country_id'];
		$order['shipping_zone']		  = (string)$orderdetail->OrderReport->FulfillmentData->Address->StateOrRegion;
		$order['shipping_zone_id']    = $customer['address']['zone_id'];
		$order['shipping_method']     = $ShippingServiceLevel;
		$order['shipping_code']       = $ShippingServiceLevel;
		$order['total']               = $total_amount;


		$acknowledge_arr = array();
		$i = 0;
		foreach($orderdetail->OrderReport->Item as $item) {
			$SKU = (string)$item->SKU;  
			if($SKU == 'low_order_fee' || $SKU == 'handling_fee')
			{
				//Nothing
			}
			else
			{
				$AmazonOrderItemCode = (string)$item->AmazonOrderItemCode;
				$Title = (string)$item->Title;
				$Quantity = (int)$item->Quantity;
				foreach($item->ItemPrice->Component as $amount_type) {
					$item_charge_type = (string)$amount_type->Type;	
					if($item_charge_type == 'Principal') {
						$Amount = (float)$amount_type->Amount;
					}
				}
				$Amount = $Amount/$Quantity;
				$Amount = round($Amount,3);
				$Product_id = (int)$item->SKU;
				$Model = '';
				$Reward = '';
				
				
				$acknowledge_arr['items'][$i]['AmazonOrderItemCode'] = $AmazonOrderItemCode;
				$acknowledge_arr['items'][$i]['product_id'] = $Product_id;
				
				if($order_id != $ClientRequestId)
				{
					$order['products'][$i]['order_id']  = $order_id;
					$order['products'][$i]['product_id']  = $Product_id;
					$order['products'][$i]['name']  = $Title;
					$order['products'][$i]['model']  = $Model;
					$order['products'][$i]['quantity']  = $Quantity;
					$order['products'][$i]['price']  = $Amount;
					$order['products'][$i]['total']  = $Amount*$Quantity;
					$order['products'][$i]['tax']  = 0;
					$order['products'][$i]['reward']  = 0;
					
					/*foreach($item->CartCustomData->Item_Options as $item_options) {
						$order['products'][$i]['option'][$i]['product_option_id']  = $item->ItemCustomData->Item_Options->Product_option_id;
						$order['products'][$i]['option'][$i]['product_option_value_id']  = $item->ItemCustomData->Item_Options->Product_option_value_id;
						$order['products'][$i]['option'][$i]['name']  = $item->ItemCustomData->Item_Options->Name;
						$order['products'][$i]['option'][$i]['value']  = $item->ItemCustomData->Item_Options->Value;
						$order['products'][$i]['option'][$i]['type']  = $item->ItemCustomData->Item_Options->Type;
					}*/
				 }
			}
			$i++;
		}
		
		$order['totals'][0]['order_id']  =  $order_id;
		$order['totals'][0]['code']      =  'sub_total';
		$order['totals'][0]['title']     =  'Sub-Total';
		$order['totals'][0]['value']     =  $total_principal;
		$order['totals'][0]['sort_order']  = $this->config->get('sub_total_sort_order');
		
		
		$order['totals'][1]['order_id']  =  $order_id;
		$order['totals'][1]['code']      =  'shipping';
		$order['totals'][1]['title']     =  $ShippingServiceLevel.' Shipping Rate';
		$order['totals'][1]['value']     =  $shipping_amount;
		$order['totals'][1]['sort_order']  =  $this->config->get('shipping_sort_order');
		
		if($total_promo > 0)
		{
			$order['totals'][2]['order_id']  =  $order_id;
			$order['totals'][2]['code']      =  'coupon';
			$order['totals'][2]['title']     =  'Coupon';
			$order['totals'][2]['value']     =  $total_promo;
			$order['totals'][2]['sort_order']  =  $this->config->get('coupon_sort_order');
		}
		
		$order['totals'][3]['order_id']  =  $order_id;
		$order['totals'][3]['code']      =  'total';
		$order['totals'][3]['title']     =  'Total';
		$order['totals'][3]['value']     =  $total_amount;
		$order['totals'][3]['sort_order']  =  $this->config->get('total_sort_order');
			
		
		if($order_id == $ClientRequestId){
			$this->model_payment_pwa->update_order_details($order,true);
		}else{
			$this->model_payment_pwa->update_order_details($order,false);
		}
		
		$param = array();
		$param['order_id']     = $order_id;
		$param['phone_mobile'] = $order['telephone'];
		
		$this->model_payment_pwa->update_telephone($param);
		
		$this->load->model('checkout/order');
		$comment = '<b>Pay with Amazon</b><br /><b>Status</b> : Payment Received<br /><b>Amazon Order Id</b> : <a target="_blank" href="https://sellercentral.amazon.in/gp/orders-v2/details/ref=cb_orddet_cont_myo?ie=UTF8&orderID='.$AmazonOrderID.'">'.$AmazonOrderID.'</a>';
		$this->model_checkout_order->addOrderHistory($order_id, 2, $comment ,true);
		
		$this->define_constants();
		$param['AmazonOrderID'] = $AmazonOrderID;
        $param['MerchantOrderID'] = $order_id;
        $param['StatusCode'] = 'Success';
		$this->load->controller( 'payment/mws_report/SubmitFeed/acknowledge_feed' , $param );
	}
	
	
	public function update_cart_by_junglee_xml($order_id,$orderdetail){
		$total_amount = 0;
      	$total_principal = 0;
      	$shipping_amount = 0;
      	$total_promo = 0;
      	$ClientRequestId = 0;
        
        $AmazonOrderID = (string)$orderdetail->OrderReport->AmazonOrderID;
			
		foreach($orderdetail->OrderReport->Item as $item) {
			$Principal_Promotions = 0;
      		$Shipping_Promotions  = 0;
      		
    		foreach($item->ItemPrice->Component as $amount_type) {
				$item_charge_type = (string)$amount_type->Type;	
				if($item_charge_type == 'Principal') {
					$Principal = abs((float)$amount_type->Amount);
				}
				if($item_charge_type == 'Shipping') {
					$Shipping = abs((float)$amount_type->Amount);
				}
				if($item_charge_type == 'Tax') {
					$Tax = abs((float)$amount_type->Amount);
				}
				if($item_charge_type == 'ShippingTax') {
					$ShippingTax = abs((float)$amount_type->Amount);
				}
			}
			
			if( !empty($item->Promotion) ) {
				foreach($item->Promotion as $promotions){
					foreach($promotions->Component as $promotion_amount_type) {
						$promotion_type = (string)$promotion_amount_type->Type;
						
						if($promotion_type == 'Shipping') {
							$Shipping_Promotions += abs((float)$promotion_amount_type->Amount);
						}
						
						if($promotion_type == 'Principal') {
							$Principal_Promotions += abs((float)$promotion_amount_type->Amount);
						}
					}
				}
			}
			
			$total_principal += $Principal;
			
			$total_amount += ($Principal - $Principal_Promotions) + ($Shipping - $Shipping_Promotions) ;
        	
			$shipping_amount += $Shipping + $Shipping_Promotions;
			
			$total_promo += $Principal_Promotions + $Shipping_Promotions;

			foreach($item->CustomizationInfo as $info) {
				
				$info_type = (string)$info->Type;	
				if($info_type == 'url') {
					$info_array = explode(',',$info->Data);
					$customerId_array = explode('=',$info_array[0]);
					$ClientRequestId = $customerId_array[1];
				}
			}
		}
		
		$ShippingServiceLevel = (string)$orderdetail->OrderReport->FulfillmentData->FulfillmentServiceLevel;
      	$this->model_payment_pwa->update_shipping($ShippingServiceLevel,$order_id);

	  	
		$email = (string)$orderdetail->OrderReport->BillingData->BuyerEmailAddress;
		$customer = array();
		 
		$cust_name = (string)$orderdetail->OrderReport->BillingData->BuyerName;
		$name_arr = explode(' ',$cust_name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $cust_name;
			$lastname = '.';
		}
			
		$password = $this->generate_password();
		$customer['firstname']   = $firstname;
		$customer['lastname']    = $lastname;
		$customer['email']       = $email;
		$customer['telephone']   = (string)$orderdetail->OrderReport->FulfillmentData->Address->PhoneNumber;
		$customer['password']    = $password;
		$customer['newsletter']  = 1;
	
		$country = $this->model_payment_pwa->get_country((string)$orderdetail->OrderReport->FulfillmentData->Address->CountryCode);
		if(empty($country))
		{
			$id_country = 99;
		}
		else
		{
			$id_country = $country['country_id'];
		}
		
		$name = (string)$orderdetail->OrderReport->FulfillmentData->Address->Name;
		$name_arr = explode(' ',$name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<=count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $name;
			$lastname = '.';
		}
		
		$zone_id = $this->model_payment_pwa->get_zone((string)$orderdetail->OrderReport->FulfillmentData->Address->StateOrRegion);
		$customer['address']['firstname']  =  $firstname;
		$customer['address']['lastname']   =  $lastname;
		$customer['address']['address_1']  =  (string)$orderdetail->OrderReport->FulfillmentData->Address->AddressFieldOne;
		$customer['address']['address_2']  =  (string)$orderdetail->OrderReport->FulfillmentData->Address->AddressFieldTwo;
		$customer['address']['city']       =  (string)$orderdetail->OrderReport->FulfillmentData->Address->City;
		$customer['address']['postcode']   =  (string)$orderdetail->OrderReport->FulfillmentData->Address->PostalCode;
		$customer['address']['country_id'] =  $id_country;
		$customer['address']['zone_id']    =  $zone_id;
		
		
		  if ($this->config->get('config_checkout_guest')) {
		 
		  } else {
			  $customer_id =  $this->model_payment_pwa->customer_exist($email);
			  if(!$customer_id)
			  {
				$customer_id = $this->model_payment_pwa->add_customer($customer);
			  }
		  }
			  
		
		$order = array();
		$order['customer_id'] = $customer_id;
		$order['order_id']   = $order_id;
		$order['customer_group_id'] = $this->config->get('config_customer_group_id');
		$order['firstname']  = $customer['firstname'];
		$order['lastname']   = $customer['lastname'];
		$order['email']      = $customer['email'];
		$order['telephone']  = $customer['telephone'];
		$order['payment_firstname']   = $customer['firstname'];
		$order['payment_lastname']    = $customer['lastname'];
		$order['payment_address_1']   = $customer['address']['address_1'];
		$order['payment_address_2']   = $customer['address']['address_2'];
		$order['payment_city']        = $customer['address']['city'];
		$order['payment_postcode']    = $customer['address']['postcode'];
		$order['payment_country']     = $country['name'];
		$order['payment_country_id']  = $customer['address']['country_id'];
		$order['payment_zone']  	  = (string)$orderdetail->OrderReport->FulfillmentData->Address->StateOrRegion;
		$order['payment_zone_id']  	  = $customer['address']['zone_id'];
		$order['shipping_firstname']  = $customer['address']['firstname'];
		$order['shipping_lastname']   = $customer['address']['lastname'];
		$order['shipping_address_1']  = $customer['address']['address_1'];
		$order['shipping_address_2']  = $customer['address']['address_2'];
		$order['shipping_city']       = $customer['address']['city'];
		$order['shipping_postcode']   = $customer['address']['postcode'];
		$order['shipping_country']    = $country['name'];
		$order['shipping_country_id'] = $customer['address']['country_id'];
		$order['shipping_zone']		  = (string)$orderdetail->OrderReport->FulfillmentData->Address->StateOrRegion;
		$order['shipping_zone_id']    = $customer['address']['zone_id'];
		$order['shipping_method']     = $ShippingServiceLevel;
		$order['shipping_code']       = $ShippingServiceLevel;
		$order['total']               = $total_amount;


		$acknowledge_arr = array();
		$i = 0;
		foreach($orderdetail->OrderReport->Item as $item) {
			$SKU = (string)$item->SKU;  
			
			$AmazonOrderItemCode = (string)$item->AmazonOrderItemCode;
			$Title = (string)$item->Title;
			$Quantity = (int)$item->Quantity;
			foreach($item->ItemPrice->Component as $amount_type) {
				$item_charge_type = (string)$amount_type->Type;	
				if($item_charge_type == 'Principal') {
					$Amount = (float)$amount_type->Amount;
				}
			}
			$Amount = $Amount/$Quantity;
			$Amount = round($Amount,3);
			$Product_id = (int)$item->SKU;
			$Model = '';
			$Reward = '';
			
			
			$acknowledge_arr['items'][$i]['AmazonOrderItemCode'] = $AmazonOrderItemCode;
			$acknowledge_arr['items'][$i]['product_id'] = $Product_id;
			
			if($order_id != $ClientRequestId)
			{
				$order['products'][$i]['order_id']  = $order_id;
				$order['products'][$i]['product_id']  = $Product_id;
				$order['products'][$i]['name']  = $Title;
				$order['products'][$i]['model']  = $Model;
				$order['products'][$i]['quantity']  = $Quantity;
				$order['products'][$i]['price']  = $Amount;
				$order['products'][$i]['total']  = $Amount*$Quantity;
				$order['products'][$i]['tax']  = 0;
				$order['products'][$i]['reward']  = 0;
				
				/*foreach($item->CartCustomData->Item_Options as $item_options) {
					$order['products'][$i]['option'][$i]['product_option_id']  = $item->ItemCustomData->Item_Options->Product_option_id;
					$order['products'][$i]['option'][$i]['product_option_value_id']  = $item->ItemCustomData->Item_Options->Product_option_value_id;
					$order['products'][$i]['option'][$i]['name']  = $item->ItemCustomData->Item_Options->Name;
					$order['products'][$i]['option'][$i]['value']  = $item->ItemCustomData->Item_Options->Value;
					$order['products'][$i]['option'][$i]['type']  = $item->ItemCustomData->Item_Options->Type;
				}*/
			 }
			
			$i++;
		}
		
		$order['totals'][0]['order_id']  =  $order_id;
		$order['totals'][0]['code']      =  'sub_total';
		$order['totals'][0]['title']     =  'Sub-Total';
		$order['totals'][0]['value']     =  $total_principal;
		$order['totals'][0]['sort_order']  = $this->config->get('sub_total_sort_order');
		
		
		$order['totals'][1]['order_id']  =  $order_id;
		$order['totals'][1]['code']      =  'shipping';
		$order['totals'][1]['title']     =  $ShippingServiceLevel.' Shipping Rate';
		$order['totals'][1]['value']     =  $shipping_amount;
		$order['totals'][1]['sort_order']  =  $this->config->get('shipping_sort_order');
		
		if($total_promo > 0)
		{
			$order['totals'][2]['order_id']  =  $order_id;
			$order['totals'][2]['code']      =  'coupon';
			$order['totals'][2]['title']     =  'Coupon';
			$order['totals'][2]['value']     =  $total_promo;
			$order['totals'][2]['sort_order']  =  $this->config->get('coupon_sort_order');
		}
		
		$order['totals'][3]['order_id']  =  $order_id;
		$order['totals'][3]['code']      =  'total';
		$order['totals'][3]['title']     =  'Total';
		$order['totals'][3]['value']     =  $total_amount;
		$order['totals'][3]['sort_order']  =  $this->config->get('total_sort_order');
			
		
		if($order_id == $ClientRequestId){
			$this->model_payment_pwa->update_order_details($order,true);
		}else{
			$this->model_payment_pwa->update_order_details($order,false);
		}
		
		$param = array();
		$param['order_id']     = $order_id;
		$param['phone_mobile'] = $order['telephone'];
		
		$this->model_payment_pwa->update_telephone($param);
		
		$this->load->model('checkout/order');
		$comment = '<b>Pay with Amazon</b><br /><b>Status</b> : Payment Received<br /><b>Amazon Order Id</b> : <a target="_blank" href="https://sellercentral.amazon.in/gp/orders-v2/details/ref=cb_orddet_cont_myo?ie=UTF8&orderID='.$AmazonOrderID.'">'.$AmazonOrderID.'</a>';
		$this->model_checkout_order->addOrderHistory($order_id, 2, $comment ,true);
		
		$this->define_constants();
		$param['AmazonOrderID'] = $AmazonOrderID;
        $param['MerchantOrderID'] = $order_id;
        $param['StatusCode'] = 'Success';
		$this->load->controller( 'payment/mws_report/SubmitFeed/acknowledge_feed' , $param );
	}
	
	
	public function generate_password(){
			return uniqid();
	}
    
    
    public function define_constants(){

		 if ( ! defined( 'AWS_ACCESS_KEY_ID' ) ) 
		 define('AWS_ACCESS_KEY_ID', $this->config->get('pwa_access_key'));
		 
		 if ( ! defined( 'AWS_SECRET_ACCESS_KEY' ) ) 
		 define('AWS_SECRET_ACCESS_KEY', $this->config->get('pwa_secret_key'));
		 
		 if ( ! defined( 'APPLICATION_NAME' ) ) 
		 define('APPLICATION_NAME', 'pwa_mws');
		 
		 if ( ! defined( 'APPLICATION_VERSION' ) ) 
		 define('APPLICATION_VERSION', '1.0.0');
		 
		 if ( ! defined( 'MERCHANT_ID' ) ) 
		 define('MERCHANT_ID', $this->config->get('pwa_merchant_id'));
		 
		 if ( ! defined( 'MARKETPLACE_ID' ) ) 
		 define('MARKETPLACE_ID', $this->config->get('pwa_marketplace_id'));
		 
		 if ( ! defined( 'MWS_ENDPOINT_URL' ) ) 
		 define('MWS_ENDPOINT_URL','https://mws.amazonservices.in/');
		 
		 if ( ! defined( 'PLUGIN_PATH' ) ) 
		 define('PLUGIN_PATH',dirname(__FILE__).'/mws_report/');
	}
 
 	
		
}
 ?>
