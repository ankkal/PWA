<?php
class ControllerPaymentPwaIOPN extends Controller {
	public function index($param) {
		$this->load->model('setting/setting');
		$this->load->model('payment/pwa');
		
		try {
			
			if(isset($param['UUID']) && $param['UUID'] != '')
			$uuid 			   = urldecode($param['UUID']);
			else
			$uuid			   = '';
			
			if(isset($param['Timestamp']) && $param['Timestamp'] != '')
			$timestamp  	   = urldecode($param['Timestamp']);
			else
			$timestamp		   = '';
			
			if(isset($param['Signature']) && $param['Signature'] != '')
			$Signature  	   = str_replace(' ','+',urldecode($param['Signature']));
			else
			$Signature		   = '';
			
			if(isset($param['AWSAccessKeyId']) && $param['AWSAccessKeyId'] != '')
			$AWSAccessKeyId    = urldecode($param['AWSAccessKeyId']);
			else
			$AWSAccessKeyId    = '';
			
			
			$NotificationType  = urldecode($param['NotificationType']);
			$NotificationData  = stripslashes(urldecode($param['NotificationData']));
			
			if($uuid != '')
			{
				$data['uuid'] = $uuid;
				$data['timestamp'] = $timestamp;
				$data['notification_type'] = $NotificationType;
				
				$iopn_record_id = $this->model_payment_pwa->add_iopn_record($data);
		    }
		    
			// Verify that the notification request is valid by verifying the Signature
			$concatenate = $uuid.$timestamp;
			
			$secretKeyID = $this->config->get('pwa_secret_key');
			
			$generatedSignature = $this->calculateRFC2104HMAC($concatenate, $secretKeyID);
			
			if(($Signature != '' && $Signature == $generatedSignature) || $Signature == '') 
			{
				//Verify the Timestamp
				if($this->time_difference($timestamp) < 15) {
					
					if($NotificationType == 'NewOrderNotification') {
						
						$this->load->controller( 'payment/iopn/NewOrderNotification/index', array('NotificationData' => $NotificationData , 'iopn_record_id' => $iopn_record_id) );
					}
					
					if($NotificationType == 'OrderReadyToShipNotification') {
						
						if($Signature == '')
						{
							$xml = simplexml_load_string($NotificationData);
							$AmazonOrderID = (string)$xml->ProcessedOrder->AmazonOrderID;
							
							
							$order_data = $this->load->controller( 'payment/mws_order/GetOrder/init' , $AmazonOrderID );
							if(!empty($order_data))
							{
								$this->load->controller( 'payment/iopn/OrderReadyToShipNotification/index', array('NotificationData' => $NotificationData , 'iopn_record_id' => $iopn_record_id) );
							}
							else
							{
								echo 'Sorry! it seems that this order is a fake order.';
							}
						}
						else
						{
							$this->load->controller( 'payment/iopn/OrderReadyToShipNotification/index', array('NotificationData' => $NotificationData , 'iopn_record_id' => $iopn_record_id) );
						}
					}
					
					if($NotificationType == 'OrderCancelledNotification') {
						
						$this->load->controller( 'payment/iopn/OrderCancelledNotification/index', array('NotificationData' => $NotificationData , 'iopn_record_id' => $iopn_record_id) );
					}
				}
				else
				{
					$param['message'] = 'IOPN Notifications : '.$NotificationType.' : IOPN function called and with wrong timestamp.';
					$this->load->controller( 'payment/pwa/generate_log', $param );
					
					// Respond to the Request
					http_response_code(403);
				}
			}
			else
			{
				
				$param['message'] = 'IOPN Notifications : '.$NotificationType.' - '.$Signature.'-'.$generatedSignature.' - '.$secretKeyID.' : IOPN function called and with wrong signature.';
				$this->load->controller( 'payment/pwa/generate_log', $param );
						
				// Respond to the Request
				http_response_code(403);
			}
			
		} catch (Exception $e) {
			 $param['message'] = 'IOPN Notifications : Caught exception : '.$e->getMessage().'.';
			 $this->load->controller( 'payment/pwa/generate_log', $param );
		}
	}
	
	
	/*
	 * Calculate time difference 
	 */  
	public function time_difference($timestamp) {
		date_default_timezone_set("GMT");
		$mytimestamp =  date("Y-m-d H:i:s");
		
		$start_date = new DateTime($timestamp);
		$since_start = $start_date->diff(new DateTime($mytimestamp));
		
		$minutes = $since_start->days * 24 * 60;
		$minutes += $since_start->h * 60;
		$minutes += $since_start->i;
		return $minutes;
	}
	
	
	public function calculateRFC2104HMAC($data, $key) {
		// compute the hmac on input data bytes, make sure to set returning raw hmac to be true
		$rawHmac = hash_hmac('sha1', $data, $key, true);

		// base64-encode the raw hmac
		return base64_encode($rawHmac);
	}
	
}
