<?php
class ControllerPaymentPwa extends Controller {
	
	public function index() {
		
		$this->language->load('payment/pwa');
		
		$this->load->model('payment/pay_with_amazon');
		$this->load->model('checkout/coupon');
		$extensionModel = 'model_extension_extension';
        $this->load->model('extension/extension');
        
		$data['merchantID']   =  $this->config->get('pwa_merchant_id');
		$data['accessKeyID']  =  $this->config->get('pwa_access_key');
		$data['secretKeyID']  =  $this->config->get('pwa_secret_key');
		$data['btn_color']    =  $this->config->get('pwa_btn_color');
		$data['btn_size']     =  $this->config->get('pwa_btn_size');
		
		$total_data = array();
		$total = 0;
		$taxes = $this->cart->getTaxes();

		$sort_order = array();

		$results = $this->model_extension_extension->getExtensions('total');

		foreach ($results as $key => $value) {
			$sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
		}

		array_multisort($sort_order, SORT_ASC, $results);

		foreach ($results as $result) {
			if ($this->config->get($result['code'] . '_status')) {
					$this->load->model('total/' . $result['code']);

					$this->{'model_total_' . $result['code']}->getTotal($total_data, $total, $taxes);
			}
		}
		
        $data['total_data'] = array();
        $data['total_data'] = $total_data;
		
		$data['cart'] = $this->model_payment_pay_with_amazon->getSignatureInput($data['merchantID'], $data['accessKeyID']);
		$data['signature'] = $this->model_payment_pay_with_amazon->calculateRFC2104HMAC($data['cart'],$data['secretKeyID']);
		$data['cartHtml'] = $this->model_payment_pay_with_amazon->getCartHTML($data['merchantID'], $data['accessKeyID'],$data['signature']);
		$data['cartvalue'] = $this->model_payment_pay_with_amazon->getCartValue($data['merchantID'], $data['accessKeyID'],$data['signature']);
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/pwa.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/payment/pwa.tpl', $data);
		} else {
			return $this->load->view('default/template/payment/pwa.tpl', $data);
		}
		
	}
	
	
	public function thankyou(){
		$this->language->load('payment/pwa');
		$this->document->setTitle($this->language->get('thankyou_heading_title'));
		$data = $_GET;
		
		$pwa_order_status = $data['amznPmtsPaymentStatus'];
		$pwa_order_id = $data['amznPmtsOrderIds'];
		$data['AmazonOrderID'] = $data['amznPmtsOrderIds'];
		
		if(isset($data['OrderId']) && $data['OrderId'] > 0)
		$OrderId = $data['OrderId'];
		else
		$OrderId = 0;
		
		$this->load->model('payment/pwa');
		if($OrderId == 0)
		{
			$opencart_order_id = $this->model_payment_pwa->order_exist($pwa_order_id);
			
			if($opencart_order_id)
			{
				$data['opencart_order_id'] = $opencart_order_id;
			}
			else
			{
				$data['store_id'] = $this->config->get('config_store_id');
				$data['store_name'] = $this->config->get('config_name');
				$data['store_url'] = $this->config->get('config_url');
				$data['language_id'] = (int)$this->config->get('config_language_id');
				$data['currency_id'] = $this->currency->getId();
				$data['currency_code'] = $this->currency->getCode();
				$data['currency_value'] = $this->currency->getValue($this->currency->getCode());
				$data['ip'] = $this->request->server['REMOTE_ADDR'];
				
				if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
					$data['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
				} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
					$data['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
				} else {
					$data['forwarded_ip'] = '';
				}

				if (isset($this->request->server['HTTP_USER_AGENT'])) {
					$data['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
				} else {
					$data['user_agent'] = '';
				}

				if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
					$data['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
				} else {
					$data['accept_language'] = '';
				}	
				
				$order_id = $this->model_payment_pwa->create_order($data,false);
				
				$data['opencart_order_id'] = $order_id;
			}
		}
		else
		{
			$opencart_order_id = $this->model_payment_pwa->order_exist($pwa_order_id);
			if($opencart_order_id == 0)
			{
				$this->model_payment_pwa->create_order($data,true);
				$data['opencart_order_id'] = $OrderId;
			}
			else
			{
				$data['opencart_order_id'] = $opencart_order_id;
			}
		}
		
		$this->session->data['order_id'] = $data['opencart_order_id'];
		
		if (isset($this->session->data['order_id'])) {
			$this->cart->clear();

			// Add to activity log
			$this->load->model('account/activity');

			if ($this->customer->isLogged()) {
				$activity_data = array(
					'customer_id' => $this->customer->getId(),
					'name'        => $this->customer->getFirstName() . ' ' . $this->customer->getLastName(),
					'order_id'    => $this->session->data['order_id']
				);

				$this->model_account_activity->addActivity('order_account', $activity_data);
			} else {
				
				if(!empty($this->session->data['guest']['firstname']))
				{
					$activity_data = array(
						'name'     => $this->session->data['guest']['firstname'] . ' ' . $this->session->data['guest']['lastname'],
						'order_id' => $this->session->data['order_id']
					);

					$this->model_account_activity->addActivity('order_guest', $activity_data);
				}
			}

			unset($this->session->data['shipping_method']);
			unset($this->session->data['shipping_methods']);
			unset($this->session->data['payment_method']);
			unset($this->session->data['payment_methods']);
			unset($this->session->data['guest']);
			unset($this->session->data['comment']);
			unset($this->session->data['order_id']);
			unset($this->session->data['coupon']);
			unset($this->session->data['reward']);
			unset($this->session->data['voucher']);
			unset($this->session->data['vouchers']);
			unset($this->session->data['totals']);
		}
		
		
		/* Breadcrumb. */
		$data['breadcrumbs'] = array();

		$data['breadcrumbs']['home'] = array(
			'text' => '<i class="fa fa-home"></i>',
			'href' => $this->url->link('common/home')
		);
		
		$data['breadcrumbs']['thankyou'] = array(
			'text' => 'Thankyou Page',
			'href' => ''
		);
		
		/* Render some output. */
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/pwa_order.tpl')) {
			 $this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/payment/pwa_order.tpl', $data));
		} else {
			 $this->response->setOutput($this->load->view('default/template/payment/pwa_order.tpl', $data));
		}
	}
	
	
	public function iopn() {
		$this->load->model('setting/setting');
		
		$data = $_POST;
		if($this->config->get('pwa_order_update_api') == 'iopn')
		{
			if(!empty($data)) {
				$param['message'] = 'IOPN Notifications : IOPN function called with some POST data.';
				$this->generate_log($param);
				
				$dump = json_encode($data);
				$filename = '1_iopn_non';
				$myfile = fopen($filename, "w");
				fwrite($myfile, $dump);
				fclose($myfile);
				
				$this->load->controller( 'payment/pwa_iopn/index', $data );
			}else{
				$param['message'] = 'IOPN Notifications : IOPN function called without POST data.';
				$this->generate_log($param);
			}
		}
	}
	
	
	public function test_iopn() {
		$data =  '';
		$data = json_decode($data);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://works.aurigastore.com/opencart_dev/index.php?route=payment/pwa/iopn");
		curl_setopt($ch, CURLOPT_POST, 6);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$result = curl_exec($ch);
		curl_close($ch);
		exit;
	}
	
	
	public function mws_report_schedule() {
		$this->load->model('setting/setting');
		
		if($this->config->get('pwa_order_update_api') == 'mws')
		{
			$this->define_constants();
			$this->load->controller( 'payment/mws_report/ManageReportSchedule/init' );
		}
		else
		{
			echo "Sorry! MWS is not enabled in module settings.";
		}
		exit;	
	}
	
	
	public function mws_report() {
		$this->load->model('setting/setting');
		if($this->config->get('pwa_order_update_api') == 'mws')
		{
			$this->define_constants();
			$this->load->controller( 'payment/mws_report/GetReportRequestList/init' );
		}
		else
		{
			echo "Sorry! MWS is not enabled in module settings.";
		}
		exit;	
	}
	
	
	public function cancel_amazon_order($order_id){
		
		$this->load->model('payment/pwa');
		$order_status = $this->model_payment_pwa->already_cancelled($order_id);
		if($order_status == 7){
			$AmazonOrderID = $this->model_payment_pwa->get_amazon_order_id($order_id);
			if($AmazonOrderID != 0) {
				$this->define_constants();
				$param['AmazonOrderID'] = $AmazonOrderID;
				$param['MerchantOrderID'] = $order_id;
				$param['StatusCode'] = 'Failure';
				$this->load->controller( 'payment/mws_report/SubmitFeed/cancel_feed' , $param );
			}
		}
	}
	
	
	public function mws_order() {
		$this->load->model('setting/setting');
		
		if($this->config->get('pwa_order_update_api') == 'mws')
		{
			$this->define_constants();
			$this->load->controller( 'payment/mws_order/ListOrders/init' );
		}
		else
		{
			echo "Sorry! MWS is not enabled in module settings.";
		}
		exit;	
	}
	
	
	public function mws_get_order() {
		$this->load->model('setting/setting');
		
		$order_id = $this->request->get['order_id'];
		
		$this->load->model('payment/pwa');
		$AmazonOrderID = $this->model_payment_pwa->get_amazon_order_id($order_id);
	    
	    $this->define_constants();
		$order = $this->load->controller( 'payment/mws_order/GetOrder/init' , $AmazonOrderID);
		
		$response = $this->model_payment_pwa->get_easyship_detail($AmazonOrderID);
		
		$this->model_payment_pwa->save_easyship_detail($order ,  $AmazonOrderID);
		
		
		if(isset($order->GetOrderResult->Orders->Order->PaymentMethod) && $order->GetOrderResult->Orders->Order->PaymentMethod == 'COD') {
			$PaymentMethod = 'COD';
		} else {
			$PaymentMethod = 'Other';
		}
		
		$TFMShipmentStatus = '0';
		if(isset($order->GetOrderResult->Orders->Order->ShipServiceLevel) && $order->GetOrderResult->Orders->Order->ShipServiceLevel == 'IN Exp Dom 2') {
			$ShipServiceLevel = '1';
			if(isset($order->GetOrderResult->Orders->Order->TFMShipmentStatus) && $order->GetOrderResult->Orders->Order->TFMShipmentStatus != '') {
				$TFMShipmentStatus = $order->GetOrderResult->Orders->Order->TFMShipmentStatus;
				$TFMShipmentStatus_mail = $order->GetOrderResult->Orders->Order->TFMShipmentStatus;
			} else {
				$TFMShipmentStatus = '0';
				$TFMShipmentStatus_mail = 'Schedule Pickup';
			}
		} else {
			$ShipServiceLevel = '0';
		}
		
		//Send Mail to Customer and Admin
		if($response['easyship_TFM_status'] != $TFMShipmentStatus_mail &&  ($response['easyship_TFM_status'] != '' && $response['easyship_TFM_status'] != '0' ) ) {
		   if($this->config->get('pwa_easyship_customer_mail') == 'yes')
		   {
				$user = $this->model_payment_pwa->get_customer_email($order_id);
				
				$message .=  "Hi ".$user['firstname']."\n\n";
				$message .=  "Shipment Status for your order #".$order_id." has been changed. \n\n";
				$message .=  "Shipment Status : ".$TFMShipmentStatus_mail." \n\n";
				
				$mail = new Mail($this->config->get('config_mail'));
				$mail->setTo($email);
				$mail->setFrom($this->config->get('config_email'));
				$mail->setSender($this->config->get('config_name'));
				$mail->setSubject('Order Shipment Status');
				$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
				$mail->send();
			   
		   }
		   
		  if($this->config->get('pwa_easyship_mail_to') != '')
		  {
				$emails = explode(',',$this->config->get('pwa_easyship_mail_to'));
				
				$message .=  "Hi Admin\n\n";
				$message .=  "Shipment Status for order #".$order_id." has been changed. \n\n";
				$message .=  "Shipment Status : ".$TFMShipmentStatus_mail." \n\n";
				
				foreach($email as $email) {
					$mail = new Mail($this->config->get('config_mail'));
					$mail->setTo($email);
					$mail->setFrom($this->config->get('config_email'));
					$mail->setSender($this->config->get('config_name'));
					$mail->setSubject('Order Shipment Status');
					$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
					$mail->send();
				}
		  }
		}
		
		$this->response->setOutput(json_encode(array('ShipServiceLevel'=>$ShipServiceLevel,'PaymentMethod'=>$PaymentMethod,'TFMShipmentStatus'=>$TFMShipmentStatus)));
	}
	
	
	public function define_constants(){

		 if ( ! defined( 'AWS_ACCESS_KEY_ID' ) ) 
		 define('AWS_ACCESS_KEY_ID', $this->config->get('pwa_access_key'));
		 
		 if ( ! defined( 'AWS_SECRET_ACCESS_KEY' ) ) 
		 define('AWS_SECRET_ACCESS_KEY', $this->config->get('pwa_secret_key'));
		 
		 if ( ! defined( 'APPLICATION_NAME' ) ) 
		 define('APPLICATION_NAME', 'pwa_mws');
		 
		 if ( ! defined( 'APPLICATION_VERSION' ) ) 
		 define('APPLICATION_VERSION', '1.0.0');
		 
		 if ( ! defined( 'MERCHANT_ID' ) ) 
		 define('MERCHANT_ID', $this->config->get('pwa_merchant_id'));
		 
		 if ( ! defined( 'MARKETPLACE_ID' ) ) 
		 define('MARKETPLACE_ID', $this->config->get('pwa_marketplace_id'));
		 
		 if ( ! defined( 'MWS_ENDPOINT_URL' ) ) 
		 define('MWS_ENDPOINT_URL','https://mws.amazonservices.in/');
		 
		 if ( ! defined( 'PLUGIN_PATH' ) ) 
		 define('PLUGIN_PATH',dirname(__FILE__).'/mws_report/');
	}
	
	
	/*
	 * Generate log for every activity of module
	 */ 
	public function generate_log($param) {
		
		$filename =  'pwa_error.log';	
		if(!file_exists($filename)) {
			$myfile = fopen($filename, "w");
			$entry = date('Y-m-d H:i:s').' : '.$param['message'];
			fwrite($myfile, $entry);
			fclose($myfile);	
		}else{
			$myfile = fopen($filename, "r+");
			$filedata = fread($myfile,filesize($filename));
			$entry = date('Y-m-d H:i:s').' : '.$param['message'];
			fwrite($myfile, $entry.PHP_EOL);
			fclose($myfile);
		}
	}
	
	
	
}
