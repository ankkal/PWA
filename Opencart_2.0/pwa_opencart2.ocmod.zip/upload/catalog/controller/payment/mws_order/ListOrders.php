<?php

class ControllerPaymentMwsOrderListOrders extends Controller {

	public $serviceUrl = MWS_ENDPOINT_URL;
	
	public $LastUpdatedAfter = "";
	
	public $order_status_array = array('Pending'=>'pending','Unshipped'=>'processing','Canceled'=>'cancelled');

	/**
	 * Include required core files used in admin and on the frontend.
	 */
	public function includes() {
		require_once('MarketplaceWebServiceOrders/Client.php');
		require_once('MarketplaceWebServiceOrders/Model/ListOrdersRequest.php');
	}

	
	function init(){
		
		$this->includes();
		
		$this->load->model('payment/pwa');
		$result = $this->model_payment_pwa->get_mws_cron_time();
		
		if(!empty($result)) {
			$this->LastUpdatedAfter = $result['created_before'];
		}else{
			$dateTime = new DateTime('-3 day', new DateTimeZone('UTC'));
			$time = $dateTime->format(DATE_ISO8601);  
			$this->LastUpdatedAfter = $time;
		}
		
		$config = array (
		   'ServiceURL' => $this->serviceUrl."Orders/2013-09-01",
		   'ProxyHost' => null,
		   'ProxyPort' => -1,
		   'ProxyUsername' => null,
		   'ProxyPassword' => null,
		   'MaxErrorRetry' => 3,
		 );
		 
		 $service = new MarketplaceWebServiceOrders_Client(
					AWS_ACCESS_KEY_ID,
					AWS_SECRET_ACCESS_KEY,
					APPLICATION_NAME,
					APPLICATION_VERSION,
					$config);
		
		 $request = new MarketplaceWebServiceOrders_Model_ListOrdersRequest();
		 $request->setSellerId(MERCHANT_ID);
		 $request->setMarketplaceId(MARKETPLACE_ID);
		 $request->setLastUpdatedAfter($this->LastUpdatedAfter);
		
		// object or array of parameters
		$this->invokeListOrders($service, $request);
	}

	
	function invokeListOrders(MarketplaceWebServiceOrders_Interface $service, $request) {
		  try {
			  
			$response = $service->ListOrders($request);
			$dom = new DOMDocument();
			$dom->loadXML($response->toXML());
			$dom->preserveWhiteSpace = false;
			$dom->formatOutput = true;
			$xml = $dom->saveXML();
			$this->update_order($xml);

		 } catch (MarketplaceWebServiceOrders_Exception $ex) {
			 
			$message  =  'MWS Order API : Caught Exception : '.$ex->getMessage(). "\n";
			$message .= "Response Status Code: " . $ex->getStatusCode() . "\n";
			$message .= "Error Code: " . $ex->getErrorCode() . "\n";
			$message .= "Error Type: " . $ex->getErrorType() . "\n";

			$param['message'] = $message;
			$this->load->controller( 'payment/pwa/generate_log', $param );
			return $message;
		 }
	}
	
	
	public function update_order($data) {
		
		$xml = simplexml_load_string($data);
		
		// Check and dump MWS Report API Response
		$mws_order_dump = $this->config->get('pwa_mws_order_dump');
		if( $mws_order_dump == '1' && $this->config->get('pwa_mws_order_dump_url') != ''){

			$dir = $this->config->get('pwa_mws_order_dump_url');
			if (!file_exists($dir) && !is_dir($dir)) {
				mkdir($dir, 0777);
			} 

			$filename = $dir.time().'_mws_order';
			$myfile = fopen($filename, "w");
			fwrite($myfile, $data);
			fclose($myfile);
		 }
		
		$this->load->model('payment/pwa');
		$LastUpdatedBefore = $xml->ListOrdersResult->LastUpdatedBefore;
		$result = $this->model_payment_pwa->insert_mws_cron_time($LastUpdatedBefore);
		
		$this->load->model('payment/pwa');
		foreach($xml->ListOrdersResult->Orders->Order as $order)
		{
			$AmazonOrderId = (string)$order->AmazonOrderId;
			$OrderStatus   = (string)$order->OrderStatus;
			
			$order['PaymentMethod'] = $order->PaymentMethod;
			$order['ShipServiceLevel'] = $order->ShipServiceLevel;
			$order['TFMShipmentStatus'] = $order->TFMShipmentStatus;
			
			$this->model_payment_pwa->save_easyship_detail($order ,  $AmazonOrderId);
			
			$opencart_order_id = $this->model_payment_pwa->order_exist($AmazonOrderId);

			if($opencart_order_id && $OrderStatus=='Canceled')
			{
				$already_cancel = $this->model_payment_pwa->already_cancelled($opencart_order_id);
				if($already_cancel != 7){
					$this->load->model('checkout/order');
					$comment = '<b>Pay with Amazon</b><br /><b>Status</b> : Order Cancelled';
					$this->model_checkout_order->addOrderHistory($opencart_order_id, 7 ,  $comment, true);
				}
			}
		}
	}
	
	
	
	

}
