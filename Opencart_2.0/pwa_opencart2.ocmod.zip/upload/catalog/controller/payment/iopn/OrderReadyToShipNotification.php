<?php
class ControllerPaymentIopnOrderReadyToShipNotification extends Controller {
	
	public function index($param) {
		$this->load->model('payment/pwa');
		
		$data = $param['NotificationData'];
		$iopn_record_id = $param['iopn_record_id'];
		
		$xml = simplexml_load_string($data);
		
		$NotificationReferenceId = (string)$xml->NotificationReferenceId;
		$OrderChannel = $xml->ProcessedOrder->OrderChannel;
		$AmazonOrderID = (string)$xml->ProcessedOrder->AmazonOrderID;
		$OrderDate = $xml->ProcessedOrder->OrderDate;
		
		$param['NotificationReferenceId'] = $NotificationReferenceId;
		$param['AmazonOrderID'] = $AmazonOrderID;
		$param['iopn_record_id'] = $iopn_record_id;
		
		
		$order_id = $this->model_payment_pwa->order_exist($AmazonOrderID);
		if(!$order_id) 
		{
			$record = $this->model_payment_pwa->get_iopn_record($param);
			if($record) 
			{
				
				$xml = simplexml_load_string($data);
		
				$ClientRequestId = 0;
				foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item) {
					$ClientRequestId = $item->ClientRequestId;
					break;
				}
			
				if(substr($ClientRequestId,0,1) == 'c')
				{
					$already_exist = 0;
				}
				else
				{
					if(substr($ClientRequestId,0,1) == 'o')
					{
						$order_id = str_replace('o','',$ClientRequestId);
						$already_exist = 1;
					}
					else
					{
						$already_exist = 0;
					}
				}
				
				
				if($already_exist == 0)
				{
					
					$param['Status'] = 'Accepted';
					$this->model_payment_pwa->update_request($param);
					
					$array['AmazonOrderID'] =  $AmazonOrderID;
					$array['store_id'] = $this->config->get('config_store_id');
					$array['store_name'] = $this->config->get('config_name');
					$array['store_url'] = $this->config->get('config_url');
					$array['language_id'] = (int)$this->config->get('config_language_id');
					$array['currency_id'] = $this->currency->getId();
					$array['currency_code'] = $this->currency->getCode();
					$array['currency_value'] = $this->currency->getValue($this->currency->getCode());
					$array['ip'] = $this->request->server['REMOTE_ADDR'];
					
					if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
						$array['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
					} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
						$array['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
					} else {
						$array['forwarded_ip'] = '';
					}

					if (isset($this->request->server['HTTP_USER_AGENT'])) {
						$array['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
					} else {
						$array['user_agent'] = '';
					}

					if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
						$array['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
					} else {
						$array['accept_language'] = '';
					}	
					
					$order_id = $this->model_payment_pwa->create_order($array,false);
				
					$this->update_order_detail($order_id , $data);
				}
				else
				{
					$param['Status'] = 'Accepted';
					$this->model_payment_pwa->update_request($param);
					
					$param['OrderId'] = $order_id;
					$order_id = $this->model_payment_pwa->create_order($param,true);
					
					$this->update_order_detail($order_id , $data);
				}
			}
			else 
			{	
				$param['Status'] = 'Rejected';
				$this->model_payment_pwa->update_request($param);
		
				http_response_code(503);
			}
		} 
		else 
		{	
			$param['Status'] = 'Accepted';
			$this->model_payment_pwa->update_request($param);
			
			$this->update_order_detail($order_id , $data);
		}
	}
	
	
	public function update_order_detail($order_id , $data) {
			$this->load->model('payment/pwa');
			
			$non_received = $this->model_payment_pwa->check_iopn_received($order_id);
			if($non_received == 0)
			{
				// Check and generate IOPN dump file 
				$iopn_dump = $this->config->get('pwa_iopn_dump');
				if( $iopn_dump == '1' && $this->config->get('pwa_iopn_dump_url') != ''){
					$dir = $this->config->get('pwa_iopn_dump_url');
					if ( !file_exists($dir) && !is_dir($dir) ) {
						mkdir($dir, 0777);
					}

					$filename = $dir.$order_id.'_iopn_non';
				 	$myfile = fopen($filename, "w");
				 	fwrite($myfile, $data);
				 	fclose($myfile);
				}
				
				$this->model_payment_pwa->iopn_received($order_id);
				
				$this->update_cart_by_xml($order_id,$data);
			}
			
			$this->update_detail($order_id,$data);
			
			$already_processed = $this->model_payment_pwa->already_cancelled($order_id);
			if($already_processed != 2) {
				$this->load->model('checkout/order');
				$comment = '<b>Pay with Amazon</b><br /><b>Status</b> : Payment Received';
				$this->model_checkout_order->addOrderHistory($order_id, 2 ,  $comment, true);
			}
			
			// Respond to the Request
			http_response_code(200);
	}
	
	
	public function update_cart_by_xml($order_id,$data){
		
		$xml = simplexml_load_string($data);
		
		$ClientRequestId = 0;
		foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item) {
			$ClientRequestId = $item->ClientRequestId;
			break;
	    }
	    
	    if(strlen($ClientRequestId) < 9)
	    {
			$this->update_cart_by_site_xml($order_id,$data);
		}
		else
		{
			$this->update_cart_by_junglee_xml($order_id,$data);
		}
	}
	
	
	/*
	 * Update the order detail by using Notification XML Data
	 */
	public function update_cart_by_site_xml($order_id,$data){
 
      $xml = simplexml_load_string($data);
      
      $AmazonOrderID = (string)$xml->ProcessedOrder->AmazonOrderID;
      $ShippingLabel = (string)$xml->ProcessedOrder->DisplayableShippingLabel;
      if($ShippingLabel == 'Amazon Shipping')
      {
		  $this->load->model('payment/pwa');
		  $array['ShipServiceLevel']  = 'IN Exp Dom 2';
		  $array['TFMShipmentStatus'] = '';
		  $this->model_payment_pwa->save_iopn_easyship_detail($array ,  $AmazonOrderID);
	  }
	  
	  
      $total_amount    = 0;
      $total_principal = 0;
      $shipping_amount = 0;
      $total_promo     = 0;
      $ClientRequestId = 0;
      $ClientCustomerId = 0;
      
      foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item) {
			
			$Amount = (float)$item->Price->Amount;
			
			if(substr((string)$item->ClientRequestId,0,1) == 'c')
			{
				$ClientRequestId = 0;
				$ClientCustomerId = str_replace('c','',(string)$item->ClientRequestId);
			}
			else
			{
				if(substr((string)$item->ClientRequestId,0,1) == 'o')
				{
					$ClientRequestId = str_replace('o','',(string)$item->ClientRequestId);
				}
				else
				{
					$ClientRequestId = (int)$item->ClientRequestId;
				}
			}
			
			$other_promo = 0;
			foreach($item->ItemCharges->Component as $amount_type) {
				  $item_charge_type = (string)$amount_type->Type; 
				  if($item_charge_type == 'Principal') {
					$principal = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'Shipping') {
					$Shipping = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'PrincipalPromo') {
					$principal_promo = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'ShippingPromo') {
					$shipping_promo = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'OtherPromo') {
					$other_promo = (string)$amount_type->Charge->Amount;
				  }
			}
			
			/*
			 * Total Item Charge = (Principal - PrincipalPromo) + (Shipping - ShippingPromo) + Tax + ShippingTax
			 */
			$total_principal += $principal;
			
			$total_amount += ($principal - $principal_promo) + ($Shipping - $shipping_promo) ;
			
			$shipping_amount += $Shipping;

			$total_promo += $principal_promo + $shipping_promo + $other_promo;
	  }
	  
	  $ShippingServiceLevel = (string)$xml->ProcessedOrder->ShippingServiceLevel;
     
	  $this->model_payment_pwa->update_shipping($ShippingServiceLevel,$order_id);
	  
	    $email    = (string)$xml->ProcessedOrder->BuyerInfo->BuyerEmailAddress;
	    $customer = array();
		  
		$name = (string)$xml->ProcessedOrder->BuyerInfo->BuyerName;
		$name_arr = explode(' ',$name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<=count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $name;
			$lastname = '.';
		}
		
		$password = $this->generate_password();
		
		$customer['firstname']   = $firstname;
		$customer['lastname']    = $lastname;
		$customer['email']       = $email;
		$customer['telephone']   = 0;
		$customer['password']    = $password;
		$customer['newsletter']  = 1;
		
		$country = $this->model_payment_pwa->get_country((string)$xml->ProcessedOrder->ShippingAddress->CountryCode);
		if(empty($country))
		{
			$id_country = 99;
		}
		else
		{
			$id_country = $country['country_id'];
		}
		
		$name = (string)$xml->ProcessedOrder->ShippingAddress->Name;
		$name_arr = explode(' ',$name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<=count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $name;
			$lastname = '.';
		}
			
		$zone_id = $this->model_payment_pwa->get_zone((string)$xml->ProcessedOrder->ShippingAddress->State);
		$customer['address']['firstname']  =  $firstname;
		$customer['address']['lastname']   =  $lastname;
		$customer['address']['address_1']  =  (string)$xml->ProcessedOrder->ShippingAddress->AddressFieldOne;
		$customer['address']['address_2']  =  (string)$xml->ProcessedOrder->ShippingAddress->AddressFieldTwo;
		$customer['address']['city']       =  (string)$xml->ProcessedOrder->ShippingAddress->City;
		$customer['address']['postcode']   =  (string)$xml->ProcessedOrder->ShippingAddress->PostalCode;
		$customer['address']['country_id'] =  $id_country;
		$customer['address']['zone_id']    =  $zone_id;
		
		$customer_id = 0;
		if($order_id == $ClientRequestId)
		{
			  $customer_id = $this->model_payment_pwa->order_customer($order_id);
		}
		else
		{
			  if($ClientCustomerId == 0)
			  {
				  if ($this->config->get('config_checkout_guest')) {
			 	 
				  } else {
					  $customer_id =  $this->model_payment_pwa->customer_exist($email);
					  if(!$customer_id)
					  { 	
						$customer_id = $this->model_payment_pwa->add_customer($customer);
					  }
				  }
			  }
			  else
			  {
				  $customer_id = $ClientCustomerId;
			  }
		}
		  
		    
		$order = array();
		$order['customer_id'] = $customer_id;
		$order['order_id']   = $order_id;
		$order['customer_group_id'] = $this->config->get('config_customer_group_id');
		$order['firstname']  = $customer['firstname'];
		$order['lastname']   = $customer['lastname'];
		$order['email']      = $customer['email'];
		$order['payment_firstname']   = $customer['firstname'];
		$order['payment_lastname']    = $customer['lastname'];
		$order['payment_address_1']   = $customer['address']['address_1'];
		$order['payment_address_2']   = $customer['address']['address_2'];
		$order['payment_city']        = $customer['address']['city'];
		$order['payment_postcode']    = $customer['address']['postcode'];
		$order['payment_country']     = $country['name'];
		$order['payment_country_id']  = $customer['address']['country_id'];
		$order['payment_zone']  	  = (string)$xml->ProcessedOrder->ShippingAddress->State;
		$order['payment_zone_id']  	  = $customer['address']['zone_id'];
		$order['shipping_firstname']  = $customer['address']['firstname'];
		$order['shipping_lastname']   = $customer['address']['lastname'];
		$order['shipping_address_1']  = $customer['address']['address_1'];
		$order['shipping_address_2']  = $customer['address']['address_2'];
		$order['shipping_city']       = $customer['address']['city'];
		$order['shipping_postcode']   = $customer['address']['postcode'];
		$order['shipping_country']    = $country['name'];
		$order['shipping_country_id'] = $customer['address']['country_id'];
		$order['shipping_zone']		  = (string)$xml->ProcessedOrder->ShippingAddress->State;
		$order['shipping_zone_id']    = $customer['address']['zone_id'];
		$order['shipping_method']     = $ShippingServiceLevel;
		$order['shipping_code']       = $ShippingServiceLevel;
		$order['total']               = $total_amount;
		
		
	    $acknowledge_arr = array();
	    $i = 0;
	    foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item) {
				
			$SKU = (string)$item->SKU;  
			if($SKU == 'low_order_fee' || $SKU == 'handling_fee')
			{
				//Nothing
			}
			else
			{
				$AmazonOrderItemCode = (string)$item->AmazonOrderItemCode;
				$Title        = (string)$item->Title;
				$Amount       = (float)$item->Price->Amount;
				$Product_id   = (int)$item->ItemCustomData->Product_id;
				$Model        = $item->ItemCustomData->Model;
				$Reward       = (int)$item->ItemCustomData->Reward;
				$Tax          = (int)$item->ItemCustomData->Tax;
				$CurrencyCode = (string)$item->Price->CurrencyCode;
				$Category     = (string)$item->Price->Category;
				$Quantity     = (int)$item->Quantity;
				
				$acknowledge_arr['items'][$i]['AmazonOrderItemCode'] = $AmazonOrderItemCode;
				$acknowledge_arr['items'][$i]['product_id']          = $Product_id;
				
				
				if(1)
				{
					$order['products'][$i]['order_id']   =  $order_id;
					$order['products'][$i]['product_id'] =  $Product_id;
					$order['products'][$i]['name']       =  $Title;
					$order['products'][$i]['model']      =  $Model;
					$order['products'][$i]['quantity']   =  $Quantity;
					$order['products'][$i]['price']      =  $Amount;
					$order['products'][$i]['total']      =  $Amount*$Quantity;
					$order['products'][$i]['tax']        =  0;
					$order['products'][$i]['reward']     =  $Reward;
					
					$k = 0;
					foreach($item->ItemCustomData->Item_Options as $item_options) {
						$order['products'][$i]['option'][$k]['product_option_id']        = $item_options->Product_option_id;
						$order['products'][$i]['option'][$k]['product_option_value_id']  = $item_options->Product_option_value_id;
						$order['products'][$i]['option'][$k]['name']   = $item_options->Name;
						$order['products'][$i]['option'][$k]['value']  = htmlentities($item_options->Value);
						$order['products'][$i]['option'][$k]['type']   = $item_options->Type;
						$k++;
					}
				}
			}
			
			if($i == 0)
			{
				$j = 0;
				$shipping_flag = 0;
				foreach($item->CartCustomData->Totals as $total) {
					$total_array = unserialize($total);
					if($total_array['code'] == 'shipping')
					{
						$shipping_flag = 1;
						$order['totals'][$j]['order_id']    =  $order_id;
						$order['totals'][$j]['code']        =  $total_array['code'];
						$order['totals'][$j]['title']       =  $ShippingServiceLevel.' Shipping Rate';
						$order['totals'][$j]['value']       =  $shipping_amount;
						$order['totals'][$j]['sort_order']  =  $total_array['sort_order'];
					}
					else if($total_array['code'] == 'voucher')
					{
						$order['totals'][$j]['order_id']    =  $order_id;
						$order['totals'][$j]['code']        =  $total_array['code'];
						$order['totals'][$j]['title']       =  $total_array['title'];
						$order['totals'][$j]['value']       =  $total_array['value'];
						$order['totals'][$j]['sort_order']  =  $total_array['sort_order'];
						
						if($order_id != $ClientRequestId){
							$start = strpos($total_array['title'], '(') + 1;
							$end = strrpos($total_array['title'], ')');

							if ($start && $end) {
								$code = substr($total_array['title'], $start, $end - $start);
							}
							
							$this->load->model('checkout/voucher');
							$voucher = $this->model_checkout_voucher->getVoucher($code);
							
							$order['vouchers'][$j]['order_id']         = $order_id;
							$order['vouchers'][$j]['description']      = $voucher['description'];
							$order['vouchers'][$j]['code']             = $voucher['code'];
							$order['vouchers'][$j]['from_name']        = $voucher['from_name'];
							$order['vouchers'][$j]['from_email']       = $voucher['from_email'];
							$order['vouchers'][$j]['to_name']          = $voucher['to_name'];
							$order['vouchers'][$j]['to_email']         = $voucher['to_email'];
							$order['vouchers'][$j]['voucher_theme_id'] = $voucher['voucher_theme_id'];
							$order['vouchers'][$j]['message']          = $voucher['message'];
							$order['vouchers'][$j]['amount']           = $total_array['value'];
						}
					}
					else if($total_array['code'] == 'total')
					{
						$order['totals'][$j]['order_id']    =  $order_id;
						$order['totals'][$j]['code']        =  $total_array['code'];
						$order['totals'][$j]['title']       =  $total_array['title'];
						$order['totals'][$j]['value']       =  $total_amount;
						$order['totals'][$j]['sort_order']  =  $total_array['sort_order'];
					}
					else
					{
						$order['totals'][$j]['order_id']    =  $order_id;
						$order['totals'][$j]['code']        =  $total_array['code'];
						$order['totals'][$j]['title']       =  $total_array['title'];
						$order['totals'][$j]['value']       =  $total_array['value'];
						$order['totals'][$j]['sort_order']  =  $total_array['sort_order'];
					}
				
					$j++;
				}
				
				if($shipping_flag == 0)
				{
					$order['totals'][$j]['order_id']    =  $order_id;
					$order['totals'][$j]['code']        =  'shipping';
					$order['totals'][$j]['title']       =  $ShippingServiceLevel.' Shipping Rate';
					$order['totals'][$j]['value']       =  $shipping_amount;
					$order['totals'][$j]['sort_order']  =  $this->config->get('shipping_sort_order');
				}
			}
			$i++;
		}
		
		
		if($order_id == $ClientRequestId){
			$this->model_payment_pwa->update_order_details($order,true);
		}else{
			$this->model_payment_pwa->update_order_details($order,false);
		}
		
		
		$this->load->model('checkout/order');
		$comment = '<b>Pay with Amazon</b><br /><b>Status</b> : Awaiting Payment<br /><b>Amazon Order Id</b> : <a target="_blank" href="https://sellercentral.amazon.in/gp/orders-v2/details/ref=cb_orddet_cont_myo?ie=UTF8&orderID='.$AmazonOrderID.'">'.$AmazonOrderID.'</a>';
		$this->model_checkout_order->addOrderHistory($order_id, 1 , $comment ,true);
		
		$this->load->controller( 'payment/pwa/define_constants');
		$param['AmazonOrderID'] = $AmazonOrderID;
        $param['MerchantOrderID'] = $order_id;
        $param['StatusCode'] = 'Success';
		$this->load->controller( 'payment/mws_report/SubmitFeed/acknowledge_feed' , $param );
		  
    }
    
    
    public function update_cart_by_junglee_xml(){
		
		$xml = simplexml_load_string($data);
      
      $AmazonOrderID = (string)$xml->ProcessedOrder->AmazonOrderID;
      
      $total_amount    = 0;
      $total_principal = 0;
      $shipping_amount = 0;
      $total_promo     = 0;
      $ClientRequestId = 0;
     
      foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item) {
			
			$Amount = (float)$item->Price->Amount;
			$ClientRequestId = (int)$item->ClientRequestId;
			$other_promo = 0;
			foreach($item->ItemCharges->Component as $amount_type) {
				  $item_charge_type = (string)$amount_type->Type; 
				  if($item_charge_type == 'Principal') {
					$principal = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'Shipping') {
					$Shipping = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'PrincipalPromo') {
					$principal_promo = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'ShippingPromo') {
					$shipping_promo = (string)$amount_type->Charge->Amount;
				  }
				  if($item_charge_type == 'OtherPromo') {
					$other_promo = (string)$amount_type->Charge->Amount;
				  }
			}
			
			/*
			 * Total Item Charge = (Principal - PrincipalPromo) + (Shipping - ShippingPromo) + Tax + ShippingTax
			 */
			$total_principal += $principal;
			
			$total_amount += ($principal - $principal_promo) + ($Shipping - $shipping_promo) ;
			
			$shipping_amount += $Shipping;

			$total_promo += $principal_promo + $shipping_promo + $other_promo;
	  }
	  
	  $ShippingServiceLevel = (string)$xml->ProcessedOrder->ShippingServiceLevel;
     
	  $this->model_payment_pwa->update_shipping($ShippingServiceLevel,$order_id);
	  
	    $email    = (string)$xml->ProcessedOrder->BuyerInfo->BuyerEmailAddress;
	    $customer = array();
		  
		$name = (string)$xml->ProcessedOrder->BuyerInfo->BuyerName;
		$name_arr = explode(' ',$name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<=count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $name;
			$lastname = '.';
		}
		
		$password = $this->generate_password();
		
		$customer['firstname']   = $firstname;
		$customer['lastname']    = $lastname;
		$customer['email']       = $email;
		$customer['telephone']   = 0;
		$customer['password']    = $password;
		$customer['newsletter']  = 1;
		
		$country = $this->model_payment_pwa->get_country((string)$xml->ProcessedOrder->ShippingAddress->CountryCode);
		if(empty($country))
		{
			$id_country = 99;
		}
		else
		{
			$id_country = $country['country_id'];
		}
		
		$name = (string)$xml->ProcessedOrder->ShippingAddress->Name;
		$name_arr = explode(' ',$name);
		if(count($name_arr) > 1)
		{
			$firstname = '';
			for($i=0;$i<=count($name_arr)-2;$i++)
			{
				$firstname = $firstname.' '.$name_arr[$i];
			}
			$lastname = $name_arr[count($name_arr)-1];
		}
		else
		{
			$firstname = $name;
			$lastname = '.';
		}
			
		$zone_id = $this->model_payment_pwa->get_zone((string)$xml->ProcessedOrder->ShippingAddress->State);
		$customer['address']['firstname']  =  $firstname;
		$customer['address']['lastname']   =  $lastname;
		$customer['address']['address_1']  =  (string)$xml->ProcessedOrder->ShippingAddress->AddressFieldOne;
		$customer['address']['address_2']  =  (string)$xml->ProcessedOrder->ShippingAddress->AddressFieldTwo;
		$customer['address']['city']       =  (string)$xml->ProcessedOrder->ShippingAddress->City;
		$customer['address']['postcode']   =  (string)$xml->ProcessedOrder->ShippingAddress->PostalCode;
		$customer['address']['country_id'] =  $id_country;
		$customer['address']['zone_id']    =  $zone_id;
		
		$customer_id = 0;
		if($order_id == $ClientRequestId)
		{
			  $customer_id = $this->model_payment_pwa->order_customer($order_id);
		}
		else
		{
			  if($ClientRequestId == 0)
			  {
				  if ($this->config->get('config_checkout_guest')) {
			 	 
				  } else {
					  $customer_id =  $this->model_payment_pwa->customer_exist($email);
					  if(!$customer_id)
					  { 	
						$customer_id = $this->model_payment_pwa->add_customer($customer);
					  }
				  }
			  }
			  else
			  {
				  $customer_id = $ClientRequestId;
			  }
		}
		  
		    
		$order = array();
		$order['customer_id'] = $customer_id;
		$order['order_id']   = $order_id;
		$order['customer_group_id'] = $this->config->get('config_customer_group_id');
		$order['firstname']  = $customer['firstname'];
		$order['lastname']   = $customer['lastname'];
		$order['email']      = $customer['email'];
		$order['payment_firstname']   = $customer['firstname'];
		$order['payment_lastname']    = $customer['lastname'];
		$order['payment_address_1']   = $customer['address']['address_1'];
		$order['payment_address_2']   = $customer['address']['address_2'];
		$order['payment_city']        = $customer['address']['city'];
		$order['payment_postcode']    = $customer['address']['postcode'];
		$order['payment_country']     = $country['name'];
		$order['payment_country_id']  = $customer['address']['country_id'];
		$order['payment_zone']  	  = (string)$xml->ProcessedOrder->ShippingAddress->State;
		$order['payment_zone_id']  	  = $customer['address']['zone_id'];
		$order['shipping_firstname']  = $customer['address']['firstname'];
		$order['shipping_lastname']   = $customer['address']['lastname'];
		$order['shipping_address_1']  = $customer['address']['address_1'];
		$order['shipping_address_2']  = $customer['address']['address_2'];
		$order['shipping_city']       = $customer['address']['city'];
		$order['shipping_postcode']   = $customer['address']['postcode'];
		$order['shipping_country']    = $country['name'];
		$order['shipping_country_id'] = $customer['address']['country_id'];
		$order['shipping_zone']		  = (string)$xml->ProcessedOrder->ShippingAddress->State;
		$order['shipping_zone_id']    = $customer['address']['zone_id'];
		$order['shipping_method']     = $ShippingServiceLevel;
		$order['shipping_code']       = $ShippingServiceLevel;
		$order['total']               = $total_amount;
		
		
	    $acknowledge_arr = array();
	    $i = 0;
	    foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item) {
				
				$AmazonOrderItemCode = (string)$item->AmazonOrderItemCode;
				$Title        = (string)$item->Title;
				$Amount       = (float)$item->Price->Amount;
				$Product_id   = (int)$item->SKU;  
				$CurrencyCode = (string)$item->Price->CurrencyCode;
				$Category     = (string)$item->Price->Category;
				$Quantity     = (int)$item->Quantity;
				
				$acknowledge_arr['items'][$i]['AmazonOrderItemCode'] = $AmazonOrderItemCode;
				$acknowledge_arr['items'][$i]['product_id']          = $Product_id;
				
				
				if($order_id != $ClientRequestId)
				{
					$order['products'][$i]['order_id']   =  $order_id;
					$order['products'][$i]['product_id'] =  $Product_id;
					$order['products'][$i]['name']       =  $Title;
					$order['products'][$i]['quantity']   =  $Quantity;
					$order['products'][$i]['price']      =  $Amount;
					$order['products'][$i]['total']      =  $Amount*$Quantity;
					$order['products'][$i]['tax']        =  0;
					$order['products'][$i]['reward']     =  0;
				}
			$i++;
		}
		
		$order['totals'][0]['order_id']  =  $order_id;
		$order['totals'][0]['code']      =  'sub_total';
		$order['totals'][0]['title']     =  'Sub-Total';
		$order['totals'][0]['value']     =  $total_principal;
		$order['totals'][0]['sort_order']  = $this->config->get('sub_total_sort_order');
		
		
		$order['totals'][1]['order_id']  =  $order_id;
		$order['totals'][1]['code']      =  'shipping';
		$order['totals'][1]['title']     =  $ShippingServiceLevel.' Shipping Rate';
		$order['totals'][1]['value']     =  $shipping_amount;
		$order['totals'][1]['sort_order']  =  $this->config->get('shipping_sort_order');
		
		if($total_promo > 0)
		{
			$order['totals'][2]['order_id']  =  $order_id;
			$order['totals'][2]['code']      =  'coupon';
			$order['totals'][2]['title']     =  'Coupon';
			$order['totals'][2]['value']     =  $total_promo;
			$order['totals'][2]['sort_order']  =  $this->config->get('coupon_sort_order');
		}
		
		$order['totals'][3]['order_id']  =  $order_id;
		$order['totals'][3]['code']      =  'total';
		$order['totals'][3]['title']     =  'Total';
		$order['totals'][3]['value']     =  $total_amount;
		$order['totals'][3]['sort_order']  =  $this->config->get('total_sort_order');
		
		
		if($order_id == $ClientRequestId){
			$this->model_payment_pwa->update_order_details($order,true);
		}else{
			$this->model_payment_pwa->update_order_details($order,false);
		}
		
		
		$this->load->model('checkout/order');
		$comment = '<b>Pay with Amazon</b><br /><b>Status</b> : Awaiting Payment<br /><b>Amazon Order Id</b> : <a target="_blank" href="https://sellercentral.amazon.in/gp/orders-v2/details/ref=cb_orddet_cont_myo?ie=UTF8&orderID='.$AmazonOrderID.'">'.$AmazonOrderID.'</a>';
		$this->model_checkout_order->addOrderHistory($order_id, 1 , $comment ,true);
		
		$this->load->controller( 'payment/pwa/define_constants');
		$param['AmazonOrderID'] = $AmazonOrderID;
        $param['MerchantOrderID'] = $order_id;
        $param['StatusCode'] = 'Success';
		$this->load->controller( 'payment/mws_report/SubmitFeed/acknowledge_feed' , $param );
	}
    
    
    public function generate_password(){
		return uniqid();
	}
	
	
	public function update_detail($order_id,$data){
		
		$xml = simplexml_load_string($data);
		$phone_mobile = (string)$xml->ProcessedOrder->ShippingAddress->PhoneNumber;
		
		$param = array();
		$param['order_id']     = $order_id;
		$param['phone_mobile'] = $phone_mobile;
		
		$this->load->model('payment/pwa');
		$this->model_payment_pwa->update_telephone($param);
	}
 
	
}
