<?php
class ModelPaymentPwa extends Model {
	
	  public function getMethod($address, $total) {
			$this->load->language('payment/pwa');
		  
			$method_data = array(
			  'code'       => 'pwa',
			  'title'      => $this->language->get('text_title'),
			  'terms'      => '',
			  'sort_order' => $this->config->get('pwa_sort_order')
			);
		  
			return $method_data;
	  }
	  
	  public function order_exist($amazon_order_id){
		  $order_query = $this->db->query( 'SELECT * from `'.DB_PREFIX.'pwa_orders` where `amazon_order_id` = "'.$amazon_order_id.'" ');
		  if ($order_query->num_rows) {
			  return $order_query->row['opencart_order_id'];
		  }else{
			  return 0;
		  }
	  }
	  
	  public function get_amazon_order_id($order_id){
		  $order_query = $this->db->query( 'SELECT * from `'.DB_PREFIX.'pwa_orders` where `opencart_order_id` = "'.$order_id.'" ');
		  if ($order_query->num_rows) {
			  return $order_query->row['amazon_order_id'];
		  }else{
			  return 0;
		  }
	  }
	  
	  public function create_order($data , $exist=true){
		  if(!$exist)
		  {
			//thankyou page and notifications page
			$this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($this->config->get('config_invoice_prefix')) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "', store_url = '" . $this->db->escape($data['store_url']) . "', payment_method = '" . $this->db->escape('Pay with Amazon') . "', payment_code = '" . $this->db->escape('pwa') . "',  language_id = '" . (int)$data['language_id'] . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', ip = '" . $this->db->escape($data['ip']) . "', forwarded_ip = '" .  $this->db->escape($data['forwarded_ip']) . "', user_agent = '" . $this->db->escape($data['user_agent']) . "', accept_language = '" . $this->db->escape($data['accept_language']) . "', date_added = NOW(), date_modified = NOW()");
			$order_id = $this->db->getLastId();
		  }
		  else
		  {
			$order_id = $data['OrderId'];
		  }
		  
		  $this->db->query('INSERT into `'.DB_PREFIX.'pwa_orders` (`opencart_order_id` , `amazon_order_id` ) VALUES( "'.$order_id.'", "'.$data['AmazonOrderID'].'" )');
		  
		  return $order_id;
	  }
	  
	  public function add_iopn_record($param){
		  extract($param);
		  $this->db->query('INSERT into `'.DB_PREFIX.'pwa_iopn_records` (`uuid`,`timestamp`,`notification_type`) VALUES("'.$uuid.'" , "'.$timestamp.'" , "'.$notification_type.'") ');
		  return $this->db->getLastId();
	  }
	  
	  public function get_iopn_record($param){
		  extract($param);
		  $record_query = $this->db->query('SELECT * from `'.DB_PREFIX.'pwa_iopn_records` where amazon_order_id = "'.$AmazonOrderID.'" and notification_reference_id = "'.$NotificationReferenceId.'" and status = "Rejected" ');
		  return $record_query->num_rows;
	  }
	  
	  public function update_request($param) {
			
		   extract($param);
		   $this->db->query('UPDATE `'.DB_PREFIX.'pwa_iopn_records`  set `notification_reference_id` =  "'.$NotificationReferenceId.'" , `amazon_order_id` = "'.$AmazonOrderID.'" ,  `status` = "'.$Status.'"  where `id` = "'.$iopn_record_id.'" ');
		   return $this->db->getLastId();
	  }
	  
	  public function check_iopn_received($order_id){
		   $record_query = $this->db->query('select * from `'.DB_PREFIX.'pwa_orders` where `opencart_order_id` = '.$order_id.' ');
		   return $record_query->row['_non_received'];
	  }
	  
	  public function iopn_received($order_id){
		   $this->db->query('UPDATE `'.DB_PREFIX.'pwa_orders` set `_non_received` = 1 where `opencart_order_id` = '.$order_id.' ');
		   return true;
	  }
	  
	  public function update_shipping($ShippingServiceLevel,$order_id){
		   $this->db->query('UPDATE `'.DB_PREFIX.'pwa_orders` set `shipping_service` = "'.$ShippingServiceLevel.'" , `order_type` = "site" where `opencart_order_id` = "'.$order_id.'" ');
		   return true;
	  }
	  
	  public function customer_exist($email){
		  $customer_query = $this->db->query( 'SELECT * from `'.DB_PREFIX.'customer` where `email` = "'.$email.'" ');
		  if ($customer_query->num_rows) {
			  return $customer_query->row['customer_id'];
		  }else{
			  return 0;
		  }
	  }
	  
	  public function add_customer($data){  
		    $customer_group_id = $this->config->get('config_customer_group_id');
		  
		    $this->load->model('account/customer_group');

		    $customer_group_info = $this->model_account_customer_group->getCustomerGroup($customer_group_id);
		
		    $this->db->query("INSERT INTO " . DB_PREFIX . "customer SET customer_group_id = '" . (int)$customer_group_id . "', store_id = '" . (int)$this->config->get('config_store_id') . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', salt = '" . $this->db->escape($salt = substr(md5(uniqid(rand(), true)), 0, 9)) . "', password = '" . $this->db->escape(sha1($salt . sha1($salt . sha1($data['password'])))) . "', newsletter = '" . (isset($data['newsletter']) ? (int)$data['newsletter'] : 0) . "', status = '1', approved = '" . (int)!$customer_group_info['approval'] . "', date_added = NOW()");
		  
		    $customer_id = $this->db->getLastId();
		    
		    $this->db->query("INSERT INTO " . DB_PREFIX . "address SET customer_id = '" . (int)$customer_id . "', firstname = '" . $this->db->escape($data['address']['firstname']) . "', lastname = '" . $this->db->escape($data['address']['lastname']) . "', address_1 = '" . $this->db->escape($data['address']['address_1']) . "', address_2 = '" . $this->db->escape($data['address']['address_2']) . "', city = '" . $this->db->escape($data['address']['city']) . "', postcode = '" . $this->db->escape($data['address']['postcode']) . "', country_id = '" . (int)$data['address']['country_id'] . "', zone_id = '" . (int)$data['address']['zone_id'] . "' ");

		    $address_id = $this->db->getLastId();

		    $this->db->query("UPDATE " . DB_PREFIX . "customer SET address_id = '" . (int)$address_id . "' WHERE customer_id = '" . (int)$customer_id . "'");
		  
		    $this->load->language('mail/customer');

			$subject = sprintf($this->language->get('text_subject'), $this->config->get('config_name'));

			$message = sprintf($this->language->get('text_welcome'), $this->config->get('config_name')) . "\n\n";

			if (!$customer_group_info['approval']) {
				$message .= $this->language->get('text_login') . "\n";
			} else {
				$message .= $this->language->get('text_approval') . "\n";
			}

			$message .= $this->url->link('account/login', '', 'SSL') . "\n\n";
			$message .= $this->language->get('text_services') . "\n\n";
			$message .= $this->language->get('text_thanks') . "\n";
			$message .= $this->config->get('config_name');

			$mail = new Mail($this->config->get('config_mail'));
			$mail->setTo($data['email']);
			$mail->setFrom($this->config->get('config_email'));
			$mail->setSender($this->config->get('config_name'));
			$mail->setSubject($subject);
			$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
			$mail->send();

			// Send to main admin email if new account email is enabled
			if ($this->config->get('config_account_mail')) {
				$message  = $this->language->get('text_signup') . "\n\n";
				$message .= $this->language->get('text_website') . ' ' . $this->config->get('config_name') . "\n";
				$message .= $this->language->get('text_firstname') . ' ' . $data['firstname'] . "\n";
				$message .= $this->language->get('text_lastname') . ' ' . $data['lastname'] . "\n";
				$message .= $this->language->get('text_customer_group') . ' ' . $customer_group_info['name'] . "\n";
				$message .= $this->language->get('text_email') . ' '  .  $data['email'] . "\n";
				
				$mail->setTo($this->config->get('config_email'));
				$mail->setSubject(html_entity_decode($this->language->get('text_new_customer'), ENT_QUOTES, 'UTF-8'));
				$mail->setText(html_entity_decode($message, ENT_QUOTES, 'UTF-8'));
				$mail->send();

				// Send to additional alert emails if new account email is enabled
				$emails = explode(',', $this->config->get('config_mail_alert'));

				foreach ($emails as $email) {
					if (utf8_strlen($email) > 0 && preg_match('/^[^\@]+@.*\.[a-z]{2,6}$/i', $email)) {
						$mail->setTo($email);
						$mail->send();
					}
				}
			}
			
		 return $customer_id;
	  }
	  
	  public function get_country($iso_code){
		  $country_query = $this->db->query('SELECT * from `'.DB_PREFIX.'country` where `iso_code_2` = "'.$iso_code.'" ');
		  if ($country_query->num_rows) {
			  return $country_query->row;
		  }else{
			  return array();
		  }
	  }
	  
	  public function get_zone($zone){
		  $zone_query = $this->db->query('SELECT * from `'.DB_PREFIX.'zone` where `name` = "'.$zone.'" ');
		  if ($zone_query->num_rows) {
			  return $zone_query->row['zone_id'];
		  }else{
			  return 0;
		  }
	  }
	  
	  public function update_order_details($data,$exist=true){
		 
		 $this->db->query("UPDATE `" . DB_PREFIX . "order` SET customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', total = '" . (float)$data['total'] . "', date_modified = NOW() where order_id = '".(int)$data['order_id']."' ");
		 
		 if(!empty($data['products'])){
			 // Products
			foreach ($data['products'] as $product) {
				
				$request_query = $this->db->query("SELECT * from " . DB_PREFIX . "order_product where order_id = '" . (int)$data['order_id'] . "' and product_id = '" . (int)$product['product_id'] . "'");
				if (!$request_query->num_rows) {
					$this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$data['order_id'] . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

					$order_product_id = $this->db->getLastId();
					
					 if(!empty($product['option'])){
						 
						foreach ($product['option'] as $option) {
							
							$this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$data['order_id'] . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
						}
					}
				}
			}
		}
		
		if(!empty($data['vouchers']))
		{
			// Gift Voucher
			$this->load->model('checkout/voucher');

			// Vouchers
			foreach ($data['vouchers'] as $voucher) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "order_voucher SET order_id = '" . (int)$order_id . "', description = '" . $this->db->escape($voucher['description']) . "', code = '" . $this->db->escape($voucher['code']) . "', from_name = '" . $this->db->escape($voucher['from_name']) . "', from_email = '" . $this->db->escape($voucher['from_email']) . "', to_name = '" . $this->db->escape($voucher['to_name']) . "', to_email = '" . $this->db->escape($voucher['to_email']) . "', voucher_theme_id = '" . (int)$voucher['voucher_theme_id'] . "', message = '" . $this->db->escape($voucher['message']) . "', amount = '" . (float)$voucher['amount'] . "'");

				$order_voucher_id = $this->db->getLastId();

				$voucher_id = $this->model_checkout_voucher->addVoucher($order_id, $voucher);

				$this->db->query("UPDATE " . DB_PREFIX . "order_voucher SET voucher_id = '" . (int)$voucher_id . "' WHERE order_voucher_id = '" . (int)$order_voucher_id . "'");
			}
		}
		
		// Totals 
		if(!$exist)
		{
			foreach ($data['totals'] as $total) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$total['order_id'] . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
			}
		}
		else
		{
			foreach ($data['totals'] as $total) {
				if($total['code'] == 'tax'){
					$this->db->query("UPDATE " . DB_PREFIX . "order_total SET `value` = '" . (float)$total['value'] . "' where order_id = '" . (int)$total['order_id'] . "' and code = '" . $this->db->escape($total['code']) . "' and title = '" . $this->db->escape($total['title']) . "'");
				}else{
					if($total['code'] == 'shipping'){
						$request_query = $this->db->query("SELECT * from " . DB_PREFIX . "order_total where where order_id = '" . (int)$total['order_id'] . "' and code = '" . $this->db->escape($total['code']) . "'");
						if ($request_query->num_rows) {
						    $this->db->query("UPDATE " . DB_PREFIX . "order_total SET title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "' where order_id = '" . (int)$total['order_id'] . "' and code = '" . $this->db->escape($total['code']) . "'");
					    }else{
						    $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$total['order_id'] . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
					    }
					}else{
						$this->db->query("UPDATE " . DB_PREFIX . "order_total SET title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "' where order_id = '" . (int)$total['order_id'] . "' and code = '" . $this->db->escape($total['code']) . "'");
					}
				}
			}
		}
		 
	  }
	  
	  public function update_telephone($param){
		   $this->db->query('UPDATE `'.DB_PREFIX.'order` set `telephone` = "'.$param['phone_mobile'].'" where `order_id` = "'.$param['order_id'].'" ');
		   return true;
	  }
	  
	  public function get_last_request(){
		  $request_query = $this->db->query('SELECT * from `'.DB_PREFIX.'pwa_mws_report_cron` order by id desc limit 0,1 ');
		  if ($request_query->num_rows) {
			  return $request_query->row['created_before'];
		  }else{
			  return 0;
		  }
	  }
	  
	  public function update_last_request($time){
		  $this->db->query('INSERT INTO `'.DB_PREFIX.'pwa_mws_report_cron` set `created_before` = "'.$time.'"  ');
		  return true;
	  }
	  
	  public function already_cancelled($order_id){
		   $record_query = $this->db->query('select `order_status_id` from `'.DB_PREFIX.'order` where `order_id` = '.$order_id.' ');
		   return $record_query->row['order_status_id'];
	  }
	  
	  public function order_customer($order_id){
		   $record_query = $this->db->query('select `customer_id` from `'.DB_PREFIX.'order` where `order_id` = '.$order_id.' ');
		   return $record_query->row['customer_id'];
	  }
	  
	  public function save_easyship_detail($order , $AmazonOrderID){
		  
		    if(isset($order->GetOrderResult->Orders->Order->PaymentMethod) && $order->GetOrderResult->Orders->Order->PaymentMethod == 'COD') {
			$PaymentMethod = 'COD';
			} else {
				$PaymentMethod = 'Other';
			}
			
			$TFMShipmentStatus = '0';
			if(isset($order->GetOrderResult->Orders->Order->ShipServiceLevel) && $order->GetOrderResult->Orders->Order->ShipServiceLevel == 'IN Exp Dom 2') {
				$ShipServiceLevel = '1';
				if(isset($order->GetOrderResult->Orders->Order->TFMShipmentStatus) && $order->GetOrderResult->Orders->Order->TFMShipmentStatus != '') {
					$TFMShipmentStatus = $order->GetOrderResult->Orders->Order->TFMShipmentStatus;
				} else {
					$TFMShipmentStatus = '0';
				}
			} else {
				$ShipServiceLevel = '0';
			}
		
		    $this->db->query("UPDATE `" . DB_PREFIX . "pwa_orders` set `easyship_status` = '".$ShipServiceLevel."', `payment_method` = '".$PaymentMethod."', `easyship_TFM_status` = '".$TFMShipmentStatus."' where `amazon_order_id` = '".$AmazonOrderID."'");
	  }
	  
	   public function save_iopn_easyship_detail($order , $AmazonOrderID){
		  
		    $TFMShipmentStatus = '0';
			if(isset($order['ShipServiceLevel']) && $order['ShipServiceLevel'] == 'IN Exp Dom 2') {
				$ShipServiceLevel = '1';
				if(isset($order['TFMShipmentStatus']) && $order['TFMShipmentStatus'] != '') {
					$TFMShipmentStatus = $order['TFMShipmentStatus'];
				} else {
					$TFMShipmentStatus = '0';
				}
			} else {
				$ShipServiceLevel = '0';
			}
		
		  $this->db->query("UPDATE `" . DB_PREFIX . "pwa_orders` set `easyship_status` = $ShipServiceLevel and `easyship_TFM_status` = $TFMShipmentStatus where `amazon_order_id` = '".$AmazonOrderID."'");
	  }
	  
	   public function get_easyship_detail($AmazonOrderID){
		  
		  $request_query = $this->db->query("SELECT * from `" . DB_PREFIX . "pwa_orders` where `amazon_order_id` = '".$AmazonOrderID."'");
		  if ($request_query->num_rows) {
			  return $request_query->row;
		  }else{
			  return array();
		  }
		    
	  }
	  
	  public function get_mws_cron_time() {
		  $request_query = $this->db->query("SELECT * from `" . DB_PREFIX . "pwa_mws_order_cron` order by id desc limit 0 , 1");
		  if ($request_query->num_rows) {
			  return $request_query->row;
		  }else{
			  return array();
		  }
	  }
	  
	  public function insert_mws_cron_time($LastUpdatedBefore) {
		  $request_query = $this->db->query("INSERT INTO `" . DB_PREFIX . "pwa_mws_order_cron` set created_before = '".$LastUpdatedBefore."'");
	  }
	  
	  public function get_customer_email($order_id) {
		   $record_query = $this->db->query('select `firstname`,`email` from `'.DB_PREFIX.'order` where `order_id` = '.$order_id.' ');
		   return $record_query->row;
	  }
	  
	  
}
