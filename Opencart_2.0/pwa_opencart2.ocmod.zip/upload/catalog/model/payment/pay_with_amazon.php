<?php
class ModelPaymentPayWithAmazon extends Model {
    public $global_mindays =0;
    public $global_maxdays =0;
	protected static $HMAC_SHA1_ALGORITHM = "sha1";
	
	protected static $PROD_CART_JAVASCRIPT_START = "
	<!--<script type=\"text/javascript\" src=\"https://images-na.ssl-images-amazon.com/images/G/01/cba/js/jquery.js\"></script>\n
	<script type=\"text/javascript\" src=\"https://static-eu.payments-amazon.com/cba/js/in/PaymentWidgets.js\"></script>\n-->";
	
	
	protected static $SAND_CART_JAVASCRIPT_START = "
	<!--<script type=\"text/javascript\" src=\"https://images-na.ssl-images-amazon.com/images/G/01/cba/js/jquery.js\"></script>\n
	<script type=\"text/javascript\" src=\"https://static-eu.payments-amazon.com/cba/js/in/sandbox/PaymentWidgets.js\"></script>\n-->";
	
	protected static $CBA_BUTTON_DIV = "<div id=\"cbaButton\"></div>\n";

	protected static $CART_ORDER_INPUT_FIELD ="type:merchant-signed-order/aws-accesskey/1;order:[ORDER];signature:[SIGNATURE];aws-access-key-id:[AWS_ACCESS_KEY_ID]";
	
	protected static $STANDARD_CHECKOUT_WIDGET_SCRIPT = "<script type=\"text/javascript\">\n$(document).ready(function () {new CBA.Widgets.StandardCheckoutWidget({ merchantId: '[MERCHANT_ID]', buttonSettings: { size: 'medium', color: 'orange', background: 'light' }
	, orderInput: { format: '[CART_TYPE]', value: '[CART_VALUE]' } }).render('cbaButton'); });\n</script>";

	public function calculateRFC2104HMAC($data, $key) {
	    // compute the hmac on input data bytes, make sure to set returning raw hmac to be true
	    $rawHmac = hash_hmac(ModelPaymentPayWithAmazon::$HMAC_SHA1_ALGORITHM, $data, $key, true);

	    // base64-encode the raw hmac
	    return base64_encode($rawHmac);
  	}

  	public function getCart($merchantID, $awsAccessKeyID) {
        $cartXML = $this->getCartXML($merchantID, $awsAccessKeyID);
        return base64_encode($cartXML);
    }

  	public function getCartHTML($merchantID, $awsAccessKeyID, $signature) {
        $cartHTML = '';

		/*if($this->config->get('pwa_environment') == 'production')
		$cartHTML = $cartHTML . ModelPaymentPayWithAmazon::$PROD_CART_JAVASCRIPT_START;
		else
		$cartHTML = $cartHTML . ModelPaymentPayWithAmazon::$SAND_CART_JAVASCRIPT_START;
		*/
		//$cartHTML = $cartHTML . ModelPaymentPayWithAmazon::$CBA_BUTTON_DIV;       
		// construct the order-input section
		
        $input = $this->getCartValue($merchantID, $awsAccessKeyID, $signature);
        //$widgetScript = ereg_replace("\\[CART_TYPE\\]", "XML",ModelPaymentPayWithAmazon::$STANDARD_CHECKOUT_WIDGET_SCRIPT);
        //$widgetScript = ereg_replace("\\[MERCHANT_ID\\]", $merchantID,$widgetScript);
        //$widgetScript = ereg_replace("\\[CART_VALUE\\]",$input,$widgetScript);

        $cartHTML = $cartHTML;        

		return $cartHTML;
    }

    public function getCartValue($merchantID, $awsAccessKeyID, $signature){
    	$encodedCart = $this->getCart($merchantID, $awsAccessKeyID);
    	$input = preg_replace("/\\[ORDER\\]/", $encodedCart, ModelPaymentPayWithAmazon::$CART_ORDER_INPUT_FIELD);
        $input = preg_replace("/\\[SIGNATURE\\]/", $signature, $input);
        $input = preg_replace("/\\[AWS_ACCESS_KEY_ID\\]/", $awsAccessKeyID, $input);
        return $input;
    }

	public function getSignatureInput($merchantID, $awsAccessKeyID) {
        return $this->getCartXML($merchantID, $awsAccessKeyID);
    }

    private function getCartXML($merchantID, $awsAccessKeyID) {

		// Validate cart has products and has stock.	
        if (!empty($this->session->data['vouchers']) || !$this->cart->hasProducts() || (!$this->cart->hasStock() && !$this->config->get('config_stock_checkout'))) {
            return false;
        }

        // Validate minimum quantity requirments.			
        $product_data = $this->cart->getProducts();
        foreach ($product_data as $product) {
            $product_total = 0;

            foreach ($product_data as $product_2) {
                if ($product_2['product_id'] == $product['product_id']) {
                    $product_total += $product_2['quantity'];
                }
            }

            if ($product['minimum'] > $product_total) {
                return false;
                //$this->redirect($this->link('checkout/cart'));
            }
        }

        $total_data = array();
        $total = 0;
        $currency = 'INR';
        $taxes = $this->cart->getTaxes();

        $sort_order = $shipping_method = array();
        $calculate_data = array();

        $this->load->model('extension/extension');
		$results = $this->model_extension_extension->getExtensions('total');

		foreach ($results as $key => $value) {
			$sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
		}

		array_multisort($sort_order, SORT_ASC, $results);
        $total_old = 0;
        $tax_old = array();
        
		foreach ($results as $result) {
			if ($this->config->get($result['code'] . '_status')) {
                $tax_item_total = $tax_item_old_total = 0;
				$this->load->model('total/' . $result['code']);

				$this->{'model_total_' . $result['code']}->getTotal($total_data, $total, $taxes);
                if(!empty($taxes))
                {
                    foreach ($taxes as $key => $value) {
                        $tax_item_total += $value;
                    }
                }
                if(!empty($tax_old))
                {
                    foreach ($tax_old as $key => $value) {
                        $tax_item_old_total += $value;
                    }
                }
                $calculate_data[] = array('code' => $result['code'],'value' => ($total-$total_old),'tax' => ($tax_item_total-$tax_item_old_total));
                $total_old = $total;
                $tax_old = $taxes;

			}
		}
        
        $tax_flag = $flag_subtotal = $total_subtotal_tax = $total_tax = $tax_fraction_amazon = 0;
        foreach ($calculate_data as $key => $data) {
            if($data['code'] == 'sub_total')
            {
                $sub_total_value = $data['value'];
                if(!$data['tax'])
                    $flag_subtotal = 1;
                else
                {
                    $total_subtotal_tax = $data['tax'];
                    break;
                }

            }
            if($data['code'] == 'tax')
            {
                $total_tax += abs($data['value']); 
            }
        }

        if($flag_subtotal)
            $total_subtotal_tax = $total_tax;
		if($sub_total_value > 0)
			$tax_fraction_amazon = $total_subtotal_tax/$sub_total_value;

        $coupon_total = $credit_total = $store_credit = $reward_points = $voucher_total = $low_order_fee = $handling_fee = 0;
        foreach($calculate_data as $data){
            if($data['code'] == 'tax')
            {
                $tax_flag = 1;
                continue;
            }
            if($data['code'] == 'coupon')
            {
                $coupon_total = abs($data['value']);
                if(!$tax_flag)
                {
                     $this->load->model('total/' . $data['code']);
                    $tax_products = $tax_item_total = $total = 0;
                    $total_datas = array();
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_products += $value;
                        }
                    }
                    $this->{'model_total_' . $data['code']}->getTotal($total_datas, $total, $taxes);
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_item_total += $value;
                        }
                    }
                    $coupon_total += abs($tax_item_total-$tax_products);
				}
                // else
                //     $coupon_total += $tax_fraction_amazon*$coupon_total;
                continue;
            }
            if($data['code'] == 'credit')
            {
                $store_credit = abs($data['value']);
                continue;
            }
            if($data['code'] == 'reward')
            {
                $reward_points = abs($data['value']);
                if(!$tax_flag)
                {
                    $this->load->model('total/' . $data['code']);
                    $tax_products = $tax_item_total = $total = 0;
                    $total_datas = array();
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_products += $value;
                        }
                    }
                    $this->{'model_total_' . $data['code']}->getTotal($total_datas, $total, $taxes);
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_item_total += $value;
                        }
                    }
                    $reward_points += abs($tax_item_total-$tax_products);
				}
                //else
                //$reward_points += $tax_fraction_amazon*$reward_points;
                continue;
            }
            if($data['code'] == 'voucher')
            {
                $voucher_total = abs($data['value']);
                continue;
            }
            if($data['code'] == 'low_order_fee')
            {
                $low_order_fee = abs($data['value']);
                if(!$tax_flag )
                {
                    $this->load->model('total/' . $data['code']);
                    $tax_products = $tax_item_total = $total = 0;
                    $total_datas = array();
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_products += $value;
                        }
                    }
                    $this->{'model_total_' . $data['code']}->getTotal($total_datas, $total, $taxes);
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_item_total += $value;
                        }
                    }
                    $low_order_fee += abs($tax_item_total-$tax_products);
                }
                continue;
            }
            
            if($data['code'] == 'handling')
            {
                $handling_fee = $data['value'];
                if(!$tax_flag )
                {
                    $this->load->model('total/' . $data['code']);
                    $tax_products = $tax_item_total = $total = 0;
                    $total_datas = array();
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_products += $value;
                        }
                    }
                    $this->{'model_total_' . $data['code']}->getTotal($total_datas, $total, $taxes);
                    if(!empty($taxes))
                    {
                        foreach ($taxes as $key => $value) {
                            $tax_item_total += $value;
                        }
                    }
                    $handling_fee += abs($tax_item_total-$tax_products);
                }
                continue;
            }


        }
        $total_discount = $coupon_total + $reward_points + $voucher_total + $store_credit;
        // Sending order_id created before going to checkout pipline
       
		$order_id  = isset($this->session->data['order_id']) ? $this->session->data['order_id'] : 0;
		if($order_id == 0)
		{
			$client_id = isset($this->session->data['customer_id']) ? 'c'.$this->session->data['customer_id'] : 0;
		}
		else
		{
			$client_id = 'o'.$order_id;
		}
    
        if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) 
        {
            $site_url = $this->config->get('config_ssl');
        } 
        else 
        {
            $site_url = $this->config->get('config_url');
        }

        $return_url = $site_url.'?route=payment/pwa/thankyou&amp;OrderId='.$order_id;

		$doc = new DOMDocument('1.0');
        $doc->formatOutput = true;
        $root = $doc->createElement('Order');
        $attribute = $doc->createAttribute('xmlns');
        $attribute->value = 'http://payments.amazon.com/checkout/2009-05-15/';
        $root_attr = $root->appendChild($attribute);
        $root = $doc->appendChild($root);

        $ClientRequestId = $doc->createElement('ClientRequestId',$client_id);
        $ClientRequestId = $root->appendChild($ClientRequestId);

        $Cart = $doc->createElement('Cart');
        $Cart = $root->appendChild($Cart);

        $Items = $doc->createElement('Items');
        $Items = $Cart->appendChild($Items);

        $CartPromotionId = $doc->createElement('CartPromotionId','total-promotion');
        $CartPromotionId = $Cart->appendChild($CartPromotionId);

        $CartCustomData = $doc->createElement('CartCustomData');
        $CartCustomData = $Cart->appendChild($CartCustomData);

        foreach ($total_data as $key => $data) {
            //$XMLcode = ucfirst($data['code']);
            $XMLcode = ucfirst('totals');
            $cart_data = serialize($data);

            $Cart_details = $doc->createElement($XMLcode,$cart_data);
            $Cart_details = $CartCustomData->appendChild($Cart_details);
        }

        $Promotions = $doc->createElement('Promotions');
        $Promotions = $root->appendChild($Promotions);

	    $Promotion = $doc->createElement('Promotion');
	    $Promotion = $Promotions->appendChild($Promotion);

	    $Promotion_pro_id = $doc->createElement('PromotionId','total-promotion');
	    $Promotion_pro_id = $Promotion->appendChild($Promotion_pro_id);

	    $Promotion_pro_desc = $doc->createElement('Description','Custom discount');
	    $Promotion_pro_desc = $Promotion->appendChild($Promotion_pro_desc);

	    $Promotion_pro_benf = $doc->createElement('Benefit');
	    $Promotion_pro_benf = $Promotion->appendChild($Promotion_pro_benf);

	    $Promotion_pro_benf_fad = $doc->createElement('FixedAmountDiscount');
	    $Promotion_pro_benf_fad = $Promotion_pro_benf->appendChild($Promotion_pro_benf_fad);
        
	    $Promotion_pro_benf_fad_amount = $doc->createElement('Amount',$total_discount);
	    $Promotion_pro_benf_fad_amount = $Promotion_pro_benf_fad->appendChild($Promotion_pro_benf_fad_amount);

	    $Promotion_pro_benf_fad_currency = $doc->createElement('CurrencyCode',$currency);
	    $Promotion_pro_benf_fad_currency = $Promotion_pro_benf_fad->appendChild($Promotion_pro_benf_fad_currency); 
        
        foreach ($product_data as $product) {

            $price = $this->tax->calculate($product['price'], $product['tax_class_id'], true);

        	$Item = $doc->createElement('Item');
            $Item = $Items->appendChild($Item);
            
            $SKU = $doc->createElement('SKU',$product['product_id']);
            $SKU = $Item->appendChild($SKU);

            $MerchantId = $doc->createElement('MerchantId',$merchantID);
            $MerchantId = $Item->appendChild($MerchantId);
			
			$product_name = substr($product['name'],0,80);
            $product_name = $this->replace_char($product_name);
            $product_name = htmlentities($product_name,ENT_QUOTES,'UTF-8');
            $Title = $doc->createElement('Title',$product_name);
            $Title = $Item->appendChild($Title);

            $Description = $doc->createElement('Description');
            $Description = $Item->appendChild($Description);

            $Price = $doc->createElement('Price');
            $Price = $Item->appendChild($Price);

            $Amount = $doc->createElement('Amount',$price);
            $Amount = $Price->appendChild($Amount);

            $CurrencyCode = $doc->createElement('CurrencyCode',$currency);
            $CurrencyCode = $Price->appendChild($CurrencyCode);

            $Quantity = $doc->createElement('Quantity',$product['quantity']);
            $Quantity = $Item->appendChild($Quantity);

            if($product['weight'])
            {
              $Weight = $doc->createElement('Weight');
              $Weight = $Item->appendChild($Weight);

              $unit = $this->weight->getUnit($product['weight_class_id']);

              if($unit == 'g'){
                $p_weight = $product['weight']/1000;
              }
              else if($unit == 'lb'){
                // pound 
                $p_weight = $product['weight']/2.20462;
              }
              else if($unit == 'oz'){
                // Ounce
                $p_weight = $product['weight']/35.274;
              }
              else{
                $p_weight = $product['weight']; 
              }

              $Amount_wt = $doc->createElement('Amount',$p_weight);
              $Amount_wt = $Weight->appendChild($Amount_wt);

              $Wt_unit = $doc->createElement('Unit','kg');
              $Wt_unit = $Weight->appendChild($Wt_unit);
            }
            
            // Add easy ship attribute from vqmod or product attribute 
            $this->easyshipattributes($doc,$Item,$product['product_id'],$shipping_method);
            
            /*if(true)
            {
                $this->updateitemdimension($doc,$Item,$product);

                $Category = $doc->createElement('Category','Books');
                $Category = $Item->appendChild($Category);

                $Hazmat = $doc->createElement('Hazmat','false');
                $Hazmat = $Item->appendChild($Hazmat);
            }

            if(true)
            {
                $ShippingMethodIds = $doc->createElement('ShippingMethodIds');
                $ShippingMethodIds = $Item->appendChild($ShippingMethodIds);

                $ShippingMethodId = $doc->createElement('ShippingMethodId','shipping_id');
                $ShippingMethodId = $ShippingMethodIds->appendChild($ShippingMethodId);

                if(!in_array('shipping_id', $shipping_method))
                    $shipping_method[] = 'shipping_id';
            }

            if(true)
            {
                $HandlingTime = $doc->createElement('HandlingTime');
                $HandlingTime = $Item->appendChild($HandlingTime);

                $MinDays = $doc->createElement('MinDays','2');
                $MinDays = $HandlingTime->appendChild($MinDays);

                $MaxDays = $doc->createElement('MaxDays','4');
                $MaxDays = $HandlingTime->appendChild($MaxDays);
            }*/

            $ItemCustomData = $doc->createElement('ItemCustomData');
            $ItemCustomData = $Item->appendChild($ItemCustomData);

            $Product_id = $doc->createElement('Product_id',$product['product_id']);
            $Product_id = $ItemCustomData->appendChild($Product_id);
            
            $product_model = substr($product['model'],0,80);
            $product_model = $this->replace_char($product_model);
            $product_model = htmlentities($product_model,ENT_QUOTES,'UTF-8');
            $Model = $doc->createElement('Model',$product_model);
            $Model = $ItemCustomData->appendChild($Model);
            
            $Reward = $doc->createElement('Reward',$product['reward']);
            $Reward = $ItemCustomData->appendChild($Reward);
            
            $Tax = $doc->createElement('Tax',$product['tax_class_id']);
            $Tax = $ItemCustomData->appendChild($Tax);

            foreach ($product['option'] as $key => $variant) 
            {
                $Item_attribute = $doc->createElement('Item_Options');
                $Item_attribute = $ItemCustomData->appendChild($Item_attribute);
                
                $Product_option_id = $doc->createElement('Product_option_id',$variant['product_option_id']);
                $Product_option_id = $Item_attribute->appendChild($Product_option_id);

                $Product_option_value_id = $doc->createElement('Product_option_value_id',$variant['product_option_value_id']);
                $Product_option_value_id = $Item_attribute->appendChild($Product_option_value_id);

                $Option_id = $doc->createElement('Option_id',$variant['option_id']);
                $Option_id = $Item_attribute->appendChild($Option_id);  

                $Option_value_id = $doc->createElement('Option_value_id',$variant['option_value_id']);
                $Option_value_id = $Item_attribute->appendChild($Option_value_id);

                $Name = $doc->createElement('Name',$variant['name']);
                $Name = $Item_attribute->appendChild($Name);

                $Value = $doc->createElement('Value',$variant['value']);
                $Value = $Item_attribute->appendChild($Value);

                $Type = $doc->createElement('Type',$variant['type']);
                $Type = $Item_attribute->appendChild($Type);

                $Price = $doc->createElement('Price',$variant['price']);
                $Price = $Item_attribute->appendChild($Price);

                $Price_prefix = $doc->createElement('Price_prefix',$variant['price_prefix']);
                $Price_prefix = $Item_attribute->appendChild($Price_prefix);

                $Points = $doc->createElement('Points',$variant['points']);
                $Points = $Item_attribute->appendChild($Points);

                $Points_prefix = $doc->createElement('Points_prefix',$variant['points_prefix']);
                $Points_prefix = $Item_attribute->appendChild($Points_prefix);

                $Weight = $doc->createElement('Weight',$variant['weight']);
                $Weight = $Item_attribute->appendChild($Weight);

                $Weight_prefix = $doc->createElement('Weight_prefix',$variant['weight_prefix']);
                $Weight_prefix = $Item_attribute->appendChild($Weight_prefix);          
            }
        }
        if($low_order_fee)
        {
               
        		$Item = $doc->createElement('Item');
	            $Item = $Items->appendChild($Item);
	            
	            $SKU = $doc->createElement('SKU','low_order_fee');
	            $SKU = $Item->appendChild($SKU);

	            $MerchantId = $doc->createElement('MerchantId',$merchantID);
	            $MerchantId = $Item->appendChild($MerchantId);

	            $Title = $doc->createElement('Title','Low order fees');
	            $Title = $Item->appendChild($Title);

	            $Description = $doc->createElement('Description');
	            $Description = $Item->appendChild($Description);

	            $Price = $doc->createElement('Price');
	            $Price = $Item->appendChild($Price);

	            $Amount = $doc->createElement('Amount',$low_order_fee);
	            $Amount = $Price->appendChild($Amount);

	            $CurrencyCode = $doc->createElement('CurrencyCode',$currency);
	            $CurrencyCode = $Price->appendChild($CurrencyCode);

	            $Quantity = $doc->createElement('Quantity',1);
	            $Quantity = $Item->appendChild($Quantity);

                if(true)
                {
                    $this->updateitemdimension($doc,$Item,$product);

                    $Category = $doc->createElement('Category','Books');
                    $Category = $Item->appendChild($Category);

                    $Hazmat = $doc->createElement('Hazmat','false');
                    $Hazmat = $Item->appendChild($Hazmat);
                }

                if(true)
                {
                    $ShippingMethodIds = $doc->createElement('ShippingMethodIds');
                    $ShippingMethodIds = $Item->appendChild($ShippingMethodIds);

                    $ShippingMethodId = $doc->createElement('ShippingMethodId','shipping_id_fees');
                    $ShippingMethodId = $ShippingMethodIds->appendChild($ShippingMethodId);

                    if(!in_array('shipping_id_fees', $shipping_method))
                        $shipping_method[] = 'shipping_id_fees';
                }

                if($this->global_mindays > 0 && $this->global_maxdays > 0)
                {

                    $HandlingTime = $doc->createElement('HandlingTime');
                    $HandlingTime = $Item->appendChild($HandlingTime);

                    $MinDays = $doc->createElement('MinDays',$this->global_mindays);
                    $MinDays = $HandlingTime->appendChild($MinDays);

                    $MaxDays = $doc->createElement('MaxDays',$this->global_maxdays);
                    $MaxDays = $HandlingTime->appendChild($MaxDays);
                }
        }
        if($handling_fee)
        {
                $Item = $doc->createElement('Item');
                $Item = $Items->appendChild($Item);
                
                $SKU = $doc->createElement('SKU','handling_fee');
                $SKU = $Item->appendChild($SKU);

                $MerchantId = $doc->createElement('MerchantId',$merchantID);
                $MerchantId = $Item->appendChild($MerchantId);

                $Title = $doc->createElement('Title','Handling fees');
                $Title = $Item->appendChild($Title);

                $Description = $doc->createElement('Description');
                $Description = $Item->appendChild($Description);

                $Price = $doc->createElement('Price');
                $Price = $Item->appendChild($Price);

                $Amount = $doc->createElement('Amount',$handling_fee);
                $Amount = $Price->appendChild($Amount);

                $CurrencyCode = $doc->createElement('CurrencyCode',$currency);
                $CurrencyCode = $Price->appendChild($CurrencyCode);

                $Quantity = $doc->createElement('Quantity',1);
                $Quantity = $Item->appendChild($Quantity);

                if(true)
                {
                    $this->updateitemdimension($doc,$Item,$product);

                    $Category = $doc->createElement('Category','Books');
                    $Category = $Item->appendChild($Category);

                    $Hazmat = $doc->createElement('Hazmat','false');
                    $Hazmat = $Item->appendChild($Hazmat);
                }

                if(true)
                {
                    $ShippingMethodIds = $doc->createElement('ShippingMethodIds');
                    $ShippingMethodIds = $Item->appendChild($ShippingMethodIds);

                    $ShippingMethodId = $doc->createElement('ShippingMethodId','shipping_id_fees');
                    $ShippingMethodId = $ShippingMethodIds->appendChild($ShippingMethodId);

                    if(!in_array('shipping_id_fees', $shipping_method))
                        $shipping_method[] = 'shipping_id_fees';
                }
                if($this->global_mindays > 0 && $this->global_maxdays > 0)
                {
                    $HandlingTime = $doc->createElement('HandlingTime');
                    $HandlingTime = $Item->appendChild($HandlingTime);

                    $MinDays = $doc->createElement('MinDays',$this->global_mindays);
                    $MinDays = $HandlingTime->appendChild($MinDays);

                    $MaxDays = $doc->createElement('MaxDays',$this->global_maxdays);
                    $MaxDays = $HandlingTime->appendChild($MaxDays);
                }
        }

        if(true)
            $this->overrideshippingmethods($doc,$root,$shipping_method);

        $ReturnUrl = $doc->createElement('ReturnUrl',$return_url);
        $ReturnUrl = $root->appendChild($ReturnUrl);
		return $doc->saveXML();
			
    }
    
    // easy ship attribute from product attribute 
    public function easyshipattributesproduct($product_id){
        $this->load->model('catalog/product');
        $attributes = $this->model_catalog_product->getProductAttributes($product_id);
        foreach ($attributes as $key => $attribute) {
            if($attribute['name'] == 'Easy Ship'){
                $easyship_attribute = $attribute['attribute'];
            }
        }
        $result = array();
        if(! empty($easyship_attribute)){
            foreach ($easyship_attribute as $es_attribute) {

                if($es_attribute['name'] == 'Easy Ship Length(cm)'){
                    $result['es_length'] = $es_attribute['text'];
                }
                if($es_attribute['name'] == 'Easy Ship Width(cm)'){
                    $result['es_width'] = $es_attribute['text'];   
                }
                if($es_attribute['name'] == 'Easy Ship Height(cm)'){
                    $result['es_height'] = $es_attribute['text'];
                }
                if($es_attribute['name'] == 'Easy Ship GI'){
                    $result['es_gi'] = $es_attribute['text'];
                }
                if($es_attribute['name'] == 'Easy Ship Hazmat'){
                    $result['es_hazmat'] = $es_attribute['text'];
                }
                if($es_attribute['name'] == 'Easy Ship Handling Time Minimum(in days)'){
                    $result['es_min_day'] = $es_attribute['text'];
                }
                if($es_attribute['name'] == 'Easy Ship Handling Time Maximum(in days)'){
                    $result['es_max_day'] = $es_attribute['text'];
                }

            }
        }
        return $result;
    }
    
    
    // Add easy ship attribute from vqmod or product attribute 
    public function easyshipattributes($doc,$Item,$product_id, &$shipping_method) {               
        $es_length = $es_width = $es_height = $es_gi = $es_hazmat = $es_min_day = $es_max_day = '';
        $result_data = $easyship_data = "";
       
        // check vqmod in installed if yes then attribute will be taken from vqmod attribute
        if(class_exists('VQMod')) {
            $easyship_data = $this->db->query("SELECT pwa_easyship_length,pwa_easyship_width,pwa_easyship_height, pwa_easyship_category,pwa_easyship_hazmat,pwa_easyship_min_days,pwa_easyship_max_days,pwa_easyship_weight FROM ".DB_PREFIX."product where product_id='".$product_id."'");
            if($easyship_data->rows){
                $es_length = $easyship_data->row['pwa_easyship_length'];
                $es_width  = $easyship_data->row['pwa_easyship_width'];
                $es_height = $easyship_data->row['pwa_easyship_height'];
                //$es_weight = $easyship_data->row['pwa_easyship_weight'];
                $es_gi     = $easyship_data->row['pwa_easyship_category'];
                $es_hazmat = $easyship_data->row['pwa_easyship_hazmat'];
                $es_min_day= $easyship_data->row['pwa_easyship_min_days'];
                $es_max_day= $easyship_data->row['pwa_easyship_max_days'];

            }
        }
        
        //check if vqmod attribute is empty if empty then attribute will take from product attribute
        if(empty($es_gi) && empty($es_hazmat)){
           $result_data = $this->easyshipattributesproduct($product_id);
           if(!empty($result_data)){
                $es_length = isset($result_data['es_length']) ? $result_data['es_length'] : 0;
                $es_width  = isset($result_data['es_width']) ? $result_data['es_width'] : 0;
                $es_height = isset($result_data['es_height']) ? $result_data['es_height'] : 0;
                //$es_weight = $result_data['es_weight'];
                $es_gi     = isset($result_data['es_gi']) ? $result_data['es_gi'] : 0;
                $es_hazmat = isset($result_data['es_hazmat']) ? $result_data['es_hazmat'] :0;
                $es_min_day= isset($result_data['es_min_day']) ?$result_data['es_min_day'] :0;
                $es_max_day= isset($result_data['es_max_day']) ? $result_data['es_max_day'] :0;
           }
        }

        // if easy ship enable then pass diamension, category, hazmat
        if( $this->config->get('pwa_easyship_status')){
            // easy ship dimension settings
            if($es_length > 0 && $es_width > 0 && $es_height > 0){
                $ItemDimension = $doc->createElement('ItemDimension');
                $ItemDimension = $Item->appendChild($ItemDimension);

                $Unit = $doc->createElement('Unit','cm');
                $Unit = $ItemDimension->appendChild($Unit);
                $Length = $doc->createElement('Length',$es_length);
                $Length = $ItemDimension->appendChild($Length);

                $Width = $doc->createElement('Width',$es_width);
                $Width = $ItemDimension->appendChild($Width);

                $Height = $doc->createElement('Height',$es_height);
                $Height = $ItemDimension->appendChild($Height);
            } 
            
            if(!empty($es_gi)){
                $Category = $doc->createElement('Category',$es_gi);
                $Category = $Item->appendChild($Category);
            }
            else
            {
				 $es_gi =  $this->config->get('pwa_easyship_category');
				 if(!empty($es_gi)){
					$Category = $doc->createElement('Category',$es_gi);
					$Category = $Item->appendChild($Category);
				 }
			}
            
            if(!empty($es_hazmat)){
                $Hazmat = $doc->createElement('Hazmat',$es_hazmat);
                $Hazmat = $Item->appendChild($Hazmat);
            }
            else
            {
				$es_hazmat = $this->config->get('pwa_easyship_hazmat');
				if(!empty($es_hazmat)){
					$Hazmat = $doc->createElement('Hazmat',$es_hazmat);
					$Hazmat = $Item->appendChild($Hazmat);
				}
			}
        }
        //if easy ship override enable then pass shipping method
        if($this->config->get('pwa_easyship_shipping_override') == 'yes'){
            $ShippingMethodIds = $doc->createElement('ShippingMethodIds');
            $ShippingMethodIds = $Item->appendChild($ShippingMethodIds);

            $ShippingMethodId = $doc->createElement('ShippingMethodId','shipping_id');
            $ShippingMethodId = $ShippingMethodIds->appendChild($ShippingMethodId);

            if(!in_array('shipping_id', $shipping_method))
                $shipping_method[] = 'shipping_id';
        }
        
        // if easyship attribute handling time set then passed always 
        if($es_min_day > 0 && $es_max_day > 0){
			
            // set global min days for low order fees and handling fees
            if($es_min_day < $this->global_mindays || $this->global_mindays == 0)
                $this->global_mindays = $es_min_day;
            // set global max days for low order fees and handling fees
            if($es_max_day > $this->global_maxdays)
                $this->global_maxdays = $es_max_day;

            $HandlingTime = $doc->createElement('HandlingTime');
            $HandlingTime = $Item->appendChild($HandlingTime);

            $MinDays = $doc->createElement('MinDays',$es_min_day);
            $MinDays = $HandlingTime->appendChild($MinDays);

            $MaxDays = $doc->createElement('MaxDays',$es_max_day);
            $MaxDays = $HandlingTime->appendChild($MaxDays);
        }
        else
        {
			$es_min_day = $this->config->get('pwa_easyship_min_days');
			$es_max_day = $this->config->get('pwa_easyship_max_days');
			
			if($es_min_day > 0 && $es_max_day > 0){
			
				// set global min days for low order fees and handling fees
				if($es_min_day < $this->global_mindays || $this->global_mindays == 0)
					$this->global_mindays = $es_min_day;
				// set global max days for low order fees and handling fees
				if($es_max_day > $this->global_maxdays)
					$this->global_maxdays = $es_max_day;

				$HandlingTime = $doc->createElement('HandlingTime');
				$HandlingTime = $Item->appendChild($HandlingTime);

				$MinDays = $doc->createElement('MinDays',$es_min_day);
				$MinDays = $HandlingTime->appendChild($MinDays);

				$MaxDays = $doc->createElement('MaxDays',$es_max_day);
				$MaxDays = $HandlingTime->appendChild($MaxDays);
			}
		}        
    }

    public function updateitemdimension($doc,$Item,$product)
    {
        $ItemDimension = $doc->createElement('ItemDimension');
        $ItemDimension = $Item->appendChild($ItemDimension);

        $Unit = $doc->createElement('Unit','cm');
        $Unit = $ItemDimension->appendChild($Unit);

        $Length = $doc->createElement('Length','2');
        $Length = $ItemDimension->appendChild($Length);

        $Width = $doc->createElement('Width','3');
        $Width = $ItemDimension->appendChild($Width);

        $Height = $doc->createElement('Height','4');
        $Height = $ItemDimension->appendChild($Height);

    }

    public function overrideshippingmethods($doc,$root,$shipping_method)
    {
        $ship_price = 0;
        
        // if easy ship shipping overrride enable then pass data in xml 
        if($this->config->get('pwa_easyship_shipping_override') == 'yes'){
            $ShippingMethods  =  $doc->createElement('ShippingMethods');
            $ShippingMethods  =  $root->appendChild($ShippingMethods);
            $es_servicelevel  =  $this->config->get('pwa_easyship_service_level');
            $es_shippingbased =  $this->config->get('pwa_easyship_shipping_rate');
            $es_mindays       =  $this->config->get('pwa_easyship_shipping_days_min');
            $es_maxdays       =  $this->config->get('pwa_easyship_shipping_days_max');
            foreach ($shipping_method as $key => $value) {

                if($value == 'shipping_id_fees')
                    $ship_price = 0;
                else
                    $ship_price = $this->config->get('pwa_easyship_price');

                $ShippingMethod = $doc->createElement('ShippingMethod');
                $ShippingMethod = $ShippingMethods->appendChild($ShippingMethod);

                $ShippingMethodId = $doc->createElement('ShippingMethodId',$value);
                $ShippingMethodId = $ShippingMethod->appendChild($ShippingMethodId);

                $ServiceLevel = $doc->createElement('ServiceLevel',$es_servicelevel);
                $ServiceLevel = $ShippingMethod->appendChild($ServiceLevel);

                $Rate = $doc->createElement('Rate');
                $Rate = $ShippingMethod->appendChild($Rate);

                $ItemQuantityBased = $doc->createElement($es_shippingbased);
                $ItemQuantityBased = $Rate->appendChild($ItemQuantityBased);
				
				//if($ship_price != ''){
					$Amount = $doc->createElement('Amount',$ship_price);
					$Amount = $ItemQuantityBased->appendChild($Amount);
				//}	
				
                $CurrencyCode = $doc->createElement('CurrencyCode','INR');
                $CurrencyCode = $ItemQuantityBased->appendChild($CurrencyCode);

                $IncludedRegions = $doc->createElement('IncludedRegions');
                $IncludedRegions = $ShippingMethod->appendChild($IncludedRegions);

                $WorldRegion = $doc->createElement('WorldRegion');
                $WorldRegion = $IncludedRegions->appendChild($WorldRegion);

                $CountryCode = $doc->createElement('CountryCode',"IN");
                $CountryCode = $WorldRegion->appendChild($CountryCode);

                $DeliveryTime = $doc->createElement('DeliveryTime');
                $DeliveryTime = $ShippingMethod->appendChild($DeliveryTime);
				
				//if($es_mindays != '' && $es_mindays > 0 && $es_maxdays != '' && $es_maxdays > 0){
					$MinDays = $doc->createElement('MinDays',$es_mindays);
					$MinDays = $DeliveryTime->appendChild($MinDays);
					
					$MaxDays = $doc->createElement('MaxDays',$es_maxdays);
					$MaxDays = $DeliveryTime->appendChild($MaxDays);
				//}
            }
        }
    }
    
    public function replace_char($string)
    {
		$string = str_replace('&','',$string);
		$string = str_replace('<','',$string);
		$string = str_replace('>','',$string);
		$string = str_replace('"','',$string);
		$string = str_replace("'","",$string);
		return $string;
    }
}
