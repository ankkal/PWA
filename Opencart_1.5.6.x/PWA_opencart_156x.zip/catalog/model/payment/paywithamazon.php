<?php
class ModelPaymentPaywithamazon extends Model {
	public function getCountry($iso2) {
		return $this->db->query("SELECT `country_id`, `name`, `iso_code_2`, `iso_code_3`, `address_format` FROM `" . DB_PREFIX . "country` WHERE `iso_code_2` = '" . $this->db->escape(strtoupper($iso2)) . "' AND `status` = 1 LIMIT 1")->row;
	}

	public function getZone($name, $country_id) {
		return $this->db->query("SELECT `zone_id`, `code` FROM `" . DB_PREFIX . "zone` WHERE (LOWER(`name`) LIKE '" . $this->db->escape(strtolower($name)) . "' OR `code` LIKE '" . $this->db->escape(strtolower($name)) . "') AND `country_id` = " . (int)$country_id . " LIMIT 1")->row;
	}

	public function isAmazonOrder($order_id) {
		/*amazonorder status change */
		if ($this->config->get('amazon_checkout_status')) {
		//if ($this->config->get('paywithamazon_status')) {
			$status = $this->db->query("SELECT COUNT(*) AS `count` FROM " . DB_PREFIX . "order_amazon WHERE order_id =  " . (int)$order_id)->row['count'] == 1;
		} else {
			$status = false;
		}

		return $status;
	}

	public function setOrderShipping($order_id, $has_free_shipping) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "order_amazon` (order_id, free_shipping) VALUES (" . (int)$order_id . ", " . (int)$has_free_shipping . ")");
	}

	public function hasFreeShipping($order_id) {
		return $this->db->query("SELECT `free_shipping` FROM `" . DB_PREFIX . "order_amazon` WHERE `order_id` = " . (int)$order_id)->row['free_shipping'] == '1';
	}

	public function getShippingPrice($order_id) {
		return $this->db->query("SELECT `value` + IF(`tax` IS NULL, 0, `tax`) AS 'price' FROM `" . DB_PREFIX . "order_total` `ot` LEFT JOIN `" . DB_PREFIX . "order_total_tax` `ott` USING(`order_total_id`) WHERE `ot`.`code` = 'shipping' AND `order_id` = " . (int)$order_id)->row['price'];
	}

	public function getAdditionalCharges($order_id) {
		return $this->db->query("SELECT `ot`.`title`, `ot`.`order_total_id`, `value` + IF(`tax` IS NULL, 0, `tax`) AS 'price' FROM `" . DB_PREFIX . "order_total` `ot` LEFT JOIN `" . DB_PREFIX . "order_total_tax` `ott` USING(`order_total_id`)  WHERE `ott`.`code` NOT IN ('shipping', 'total', 'sub_total', 'tax') AND `value` > 0 AND `order_id` = " . (int)$order_id)->rows;
	}

	public function addAmazonOrderId($order_id, $amazon_order_id) {
		
		//$this->db->query("UPDATE `" . DB_PREFIX . "order_paywithamazon` SET `amazon_order_id` = '" . $this->db->escape($amazon_order_id) . "' WHERE `order_id` = " . (
		$this->db->query("INSERT INTO `" . DB_PREFIX . "order_paywithamazon` (`order_id`, `amazon_order_id`, `free_shipping`) VALUES ('" . (int)$order_id. "', '" . $this->db->escape($amazon_order_id) . "', '0')");

	}
	public function getOrderId($amazon_order_id) {
		
		
		$row = $this->db->query("SELECT `order_id` FROM `" . DB_PREFIX . "order_paywithamazon` WHERE `amazon_order_id` =\"$amazon_order_id\" LIMIT 1")->row;
		
		if (isset($row['order_id']) && !empty($row['order_id'])) {

			return $row['order_id'];
		}

		return null;
	}
	public function getAmazonOrderId($order_id) {
		$row = $this->db->query("SELECT `amazon_order_id` FROM `" . DB_PREFIX . "order_paywithamazon` WHERE `order_id` = " . (int)$order_id . " LIMIT 1")->row;

		if (isset($row['amazon_order_id']) && !empty($row['amazon_order_id'])) {
			return $row['amazon_order_id'];
		}

		return null;
	}

	public function addTaxesForTotals($order_id, $totals) {
		foreach ($totals as $total) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "order_total_tax` (`order_total_id`, `code`, `tax`) SELECT `order_total_id`, `code`, " . (float)$total['cba_tax'] . " FROM `" . DB_PREFIX . "order_total` WHERE `order_id` = " . (int)$order_id . " AND `code` = '" . $this->db->escape($total['code']) . "' AND `title` = '" . $this->db->escape($total['title']) . "'");
		}
	}

	public function getMethod($address, $total) {
		// Not shown in the payment method list
		return array();
	}

	public function updateCronJobRunTime() {
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'paywithamazon' AND `key` = 'paywithamazon_last_cron_job_run'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` (`store_id`, `code`, `key`, `value`, `serialized`) VALUES (0, 'paywithamazon', 'paywithamazon_last_cron_job_run', NOW(), 0)");
	}
	/*public function getMethod($address, $total = 0) {
		return array();
	}*/  
	public function getTestdata()
	{
		$product_data = array();

		foreach ($this->cart->getProducts() as $product) {
			print_r($product);
			exit;
		}
	}
	public function createOrderInputValue()
	{
		$result = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "pwa_cart_xml'");
		if(!$result->num_rows){
			$this->db->query("
				CREATE TABLE `" . DB_PREFIX . "pwa_cart_xml` (
					`cart_id`  int NOT NULL AUTO_INCREMENT,
					`session_id`  varchar(255) NOT NULL ,
					`customer_id` int NULL ,
					`cart_xml`  text NOT NULL,
					PRIMARY KEY (`cart_id`),
					INDEX (`cart_id`)
				) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");
		}
		$dom = new \DOMDocument("1.0","utf-8");
		$dom->formatOutput = true;
		$orderXML = $dom->saveXML($this->toXML($dom));
		//$log = new Log('cart-xml.log');
		//$log->Write($orderXML);
	   /*amazonorder access key change*/
		//$aacceskey=$this->config->get('paywithamazon_access_key');
		$aacceskey=$this->config->get('amazon_checkout_access_key');
		
		$orderInput = "type:merchant-signed-order/aws-accesskey/1;order:".$this->encodeCart($orderXML).";"."signature:".$this->signCart($orderXML) .";aws-access-key-id:". $aacceskey;
		return $orderInput;
	}

	public function toXML($dom)
	{
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$baseurl = $this->config->get('config_ssl')."index.php/";
		} else {
			$baseurl = $this->config->get('config_url')."index.php/";
		}

		//$this->validateOptionalProperties();
		$orderXML = $dom->createElement("Order");
		$orderXML->setAttribute("xmlns","http://payments.amazon.com/checkout/2009-05-15/");
		 /*amazonorder merchant key change*/
		//$merchantId=$this->config->get('paywithamazon_merchant_id');
		$merchantId=$this->config->get('amazon_checkout_merchant_id');
		
		//Arrays for item Shipping Tables and Promotions
		$itemShippingMethods = array();
		$itemPromotions = array();
		$cart = $dom->createElement("Cart");
		$itemsTag = $dom->createElement("Items");
		foreach ($this->cart->getProducts() as $product)
		{
			if(!$product['download']){
				$itemsTag->appendChild($dom->importNode($this->toitemXML($merchantId,$dom,$product),true));
			}
		}
		$cart->appendChild($itemsTag);
		if(isset($this->session->data['coupon']))
		{
			$discountvalue = $this->currency->format($this->getDiscountValue(), '', '', false);
			$promotions = $dom->createElement("Promotions");
			$cart->appendChild($dom->createElement("CartPromotionId",$this->session->data['coupon']));
			$orderXML->appendChild($cart);
			$promotions->appendChild($dom->importNode($this->topromotionXML($merchantId,$discountvalue,$this->session->data['coupon'],$dom),true));
			$orderXML->appendChild($promotions);
		}
		else
		{
			$orderXML->appendChild($cart);
		}
		$cartXMl = $dom->saveXML($orderXML);
		$cartXmlId = $this->getCartXmlId($this->encodeCart($cartXMl));
		$cartDetails = serialize(array('cart_id' => $cartXmlId, 'store_id' => $this->config->get('config_store_id')));
		$cartCustomData = $dom->createElement("CartCustomData");
		$cartDetailsTag = $dom->createElement('cartDetails', $cartDetails);
		$cartCustomData->appendChild($dom->importNode($cartDetailsTag));
		$cart->appendChild($cartCustomData);

		$returnUrl = htmlentities($baseurl."?route=payment/paywithamazon/returnprocessorder&cart_id=".$cartXmlId."&store_id=".$this->config->get('config_store_id'));
		$orderXML->appendChild($dom->createElement("IntegratorId",""));
		$orderXML->appendChild($dom->createElement("IntegratorName","standard checkout"));
		$orderXML->appendChild($dom->createElement("ReturnUrl", $returnUrl));
		$orderXML->appendChild($dom->createElement("CancelUrl",$baseurl."?route=checkout/cart"));
		$callbacksTag = $dom->createElement("OrderCalculationCallbacks");
		$callbacksTag->appendChild($dom->createElement("CalculatePromotions","false"));
		$callbacksTag->appendChild($dom->createElement("CalculateShippingRates","false"));
		$callbacksTag->appendChild($dom->createElement("OrderCallbackEndpoint",$baseurl."?route=checkout/cart"));
		$callbacksTag->appendChild($dom->createElement("ProcessOrderOnCallbackFailure","false"));
		$orderXML->appendChild($callbacksTag);
		return $orderXML;
	}
	
	public function encodeCart($orderXML)
	{
		return base64_encode($orderXML);
	}
	public function signCart($orderXML)
	{
		/* amazonorder access secret  change */
	    // $secretekey=$this->config->get('paywithamazon_access_secret');
		$secretekey=$this->config->get('amazon_checkout_access_secret');
		return $this->calculateRFC2104HMAC($orderXML,$secretekey);
	}

	public function calculateRFC2104HMAC($data, $key) {
		// compute the hmac on input data bytes, make sure to set returning raw hmac to be true
		$HMAC_SHA1_ALGORITHM = "sha1";
		$rawHmac = hash_hmac($HMAC_SHA1_ALGORITHM, $data, $key, true);
		// base64-encode the raw hmac
		return base64_encode($rawHmac);
	}
	public function toitemXML($merchantId,$dom,$product)
	{
		$this->load->model('catalog/product');
		$productDetail = $this->model_catalog_product->getProduct($product['product_id']);
		$price_num = $this->tax->calculate($product['price'],$product['tax_class_id'], $this->config->get('config_tax'));
		$indianCurrency = $this->getCurrency('INR');
		$price = (float)$price_num * (float)$indianCurrency['value'];
		$removespecialchar = preg_replace("/[^a-zA-Z0-9]/", "", $product['name']);
		$productname = substr($removespecialchar, 0, 80);
		$description = substr($removespecialchar, 0, 2000);
		if(isset($productDetail['description'])){
			$removeHtmldescription = strip_tags(html_entity_decode($productDetail['description']));
			if($removeHtmldescription != ''){
				$removeSpecialCharDescription = preg_replace("/[^a-zA-Z0-9]/", "", $removeHtmldescription);
				$description = substr($removeSpecialCharDescription, 0, 2000);
			}
		}
		$itemXML = $dom->createElement("Item");
		$itemXML->appendChild($dom->createElement("SKU",$product['product_id']));
		$itemXML->appendChild($dom->createElement("MerchantId",$merchantId));
		$itemXML->appendChild($dom->createElement("Title",$productname));
		$itemXML->appendChild($dom->createElement("Description",$description));
		$itemXML->appendChild($dom->importNode($this->topriceXML($price,$dom),true));
		$itemXML->appendChild($dom->createElement("Quantity",$product['quantity']));
		if(!empty($product['weight']))
		{
			/* Amazon only support 'KG' weight so we hard coded it */
			//$weightUnit = $this->getWeightUnit($product['weight_class_id']);
			$weightUnit = 'KG';
			$itemXML->appendChild($dom->importNode($this->towightXML($product['weight'], $weightUnit, $dom),true));  
		}
		$itemXML->appendChild($dom->importNode($this->addProductParams($dom,$product['key'])));
		return $itemXML;
	}
	public function addProductParams($dom, $options)
	{
		$customTag = $dom->createElement('ItemCustomData');
		$productParamsTag = $dom->createElement('ProductParams');
		$productParamsTag->appendChild($dom->createCDATASection($options));
		$customTag->appendChild($dom->importNode($productParamsTag));
		return $customTag;
	}

	public function towightXML($weight, $weightUnit, $dom)
	{
		$itemWeight = $dom->createElement("Weight");
		$itemWeight->appendChild($dom->createElement("Amount",$weight));
		$itemWeight->appendChild($dom->createElement("Unit",$weightUnit));
		return $itemWeight;
	}

	public function topriceXML($price,$dom)
	{
		$itemPrice = $dom->createElement("Price");
		$itemPrice->appendChild($dom->createElement("Amount",$price));
		$itemPrice->appendChild($dom->createElement("CurrencyCode","INR"));
		return $itemPrice;
	}
	public function toordercalculationXML($dom)
	{
		$ordercal = $dom->createElement("OrderCalculationCallbacks");
		$ordercal->appendChild($dom->createElement("CalculateTaxRates",true));
		$ordercal->appendChild($dom->createElement("CalculatePromotions",true));
		$ordercal->appendChild($dom->createElement("CalculateShippingRates",true));
		$ordercal->appendChild($dom->createElement("OrderCallbackEndpoint","https://amazonetest.com/cba/CallBack.php"));
		$ordercal->appendChild($dom->createElement("ProcessOrderOnCallbackFailure",true));
		return $ordercal;
	}
	public function topromotionXML($properties,$discount,$coupancode,$dom)
	{
			$promotionXML = $dom->createElement("Promotion");
			$promotionXML->appendChild($dom->createElement("PromotionId",$coupancode));
			$benefitTag = $dom->createElement("Benefit");
			$benefitTag->appendChild($dom->importNode($this->fixedpricediscount($discount,$dom),true));
			$promotionXML->appendChild($benefitTag);
			return $promotionXML;
	}
	public function fixedpricediscount($price,$dom)
	{
		$fixedpricediscount1 = $dom->createElement("FixedAmountDiscount");
		$fixedpricediscount1->appendChild($dom->createElement("Amount",$price));
		$fixedpricediscount1->appendChild($dom->createElement("CurrencyCode","INR"));
		return $fixedpricediscount1;
	}
	public function getWeightUnit($id)
	{
		$unit = $this->db->query("SELECT `unit` FROM " . DB_PREFIX . "weight_class_description WHERE weight_class_id = '" . (int)$id . "'");
		if($unit->num_rows)
			return $unit->row['unit'];
		return 'kg';
	}
	
	public function getCartXmlId($xml)
	{
		$customerId = (isset($this->session->data['customer_id'])) ? $this->session->data['customer_id'] : NULL;
		$isOldRecord = $this->db->query("SELECT `cart_id` FROM ". DB_PREFIX ."pwa_cart_xml WHERE session_id = '".session_id()."' AND cart_xml = '".$xml."' AND customer_id = '".$customerId."'");
		if($isOldRecord->num_rows){
			return $isOldRecord->row['cart_id'];
		}
		else{
			$test = $this->db->query("INSERT INTO " . DB_PREFIX . "pwa_cart_xml SET session_id = '" . session_id() . "', cart_xml = '".$xml."', customer_id = '".$customerId."'");
			return $this->db->getLastId();
		}
	}
	public function getDiscountValue()
	{
		if (isset($this->session->data['coupon'])) {
			$this->language->load('total/coupon');

			$this->load->model('checkout/coupon');

			$coupon_info = $this->model_checkout_coupon->getCoupon($this->session->data['coupon']);

			if ($coupon_info) {
				$discount_total = 0;

				if (!$coupon_info['product']) {
					$sub_total = $this->cart->getSubTotal();
				} else {
					$sub_total = 0;

					foreach ($this->cart->getProducts() as $product) {
						if (in_array($product['product_id'], $coupon_info['product'])) {
							$sub_total += $product['total'];
						}
					}
				}

				if ($coupon_info['type'] == 'F') {
					$coupon_info['discount'] = min($coupon_info['discount'], $sub_total);
				}

				foreach ($this->cart->getProducts() as $product) {
					$discount = 0;

					if (!$coupon_info['product']) {
						$status = true;
					} else {
						if (in_array($product['product_id'], $coupon_info['product'])) {
							$status = true;
						} else {
							$status = false;
						}
					}

					if ($status) {
						if ($coupon_info['type'] == 'F') {
							$discount = $coupon_info['discount'] * ($product['total'] / $sub_total);
						} elseif ($coupon_info['type'] == 'P') {
							$discount = $product['total'] / 100 * $coupon_info['discount'];
						}
					}

					$discount_total += $discount;
				}
				return $discount_total;
			}
		}
	}
	
	public function isNewOrder($amazonOrderId)
	{
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_amazon WHERE amazon_order_id='".$amazonOrderId."'");
		if($query->num_rows){
			return $query->row['order_id'];
		}
		return 0;
	}
	public function createNewOrder($amazonOrderId, $cartId, $storeId = 0)
	{
		$this->load->model('catalog/product');
		$cartXml = $this->getCartXml($cartId);
		$decodeCartXml = $this->getDecodedCartXml($cartXml['cart_xml']);
		$this->setConfigByStore($storeId);
		$this->currency->set('INR');
		$this->cart->clear();
		$cart = $decodeCartXml->Cart->Items;
		foreach($cart->children() as $item){
			if(isset($item)){
				$product_id = (string)$item->SKU;
				$product_info = $this->model_catalog_product->getProduct($product_id);
				if($product_info){
					$product_options = explode(':',(string)$item->ItemCustomData->ProductParams);
					if($product_options[1]){
						$option = unserialize(base64_decode($product_options[1]));
					}
					else{
						$option = array();
					}
					$this->cart->add($product_id, (string)$item->Quantity, $option, null);
				}
			}
		}
		if(isset($decodeCartXml->Promotions->Promotion->PromotionId)){
			$this->applyCoupon((string)$decodeCartXml->Promotions->Promotion->PromotionId, $cartXml['customer_id']);
		}
		
		$data = array();

		// Store Details
		$data['invoice_prefix'] = $this->config->get('config_invoice_prefix');
		$data['store_id'] = $this->config->get('config_store_id');
		$data['store_name'] = $this->config->get('config_name');
		$data['store_url'] = $this->config->get('config_url');

		// Customer Details
		if(isset($cartXml['customer_id']))			
		$data['customer_id'] = $cartXml['customer_id'];
		else
		$data['customer_id'] = '';
		if($customerGroupId = $this->getCustomerGroupId($cartXml['customer_id']))
		$data['customer_group_id'] = $customerGroupId;
		else
		$data['customer_group_id'] = '';
		
		$data['firstname'] = "Amazon";
		$data['lastname'] = "User";
		$data['email'] = "dummy@amazon.com";
		$data['telephone'] = "XXX";
		$data['fax'] = "XXX";
		
		// Payment Details	
		$data['payment_firstname'] = "XXX";
		$data['payment_lastname'] = "XXX";
		$data['payment_company'] = "XXX";
		$data['payment_address_1'] = "XXX";
		$data['payment_address_2'] = "XXX";
		$data['payment_city'] = "XXX";
		$data['payment_postcode'] = "XXX";
		$data['payment_zone'] = "XXX";
		$data['payment_zone_id'] = "XXX";
		$data['payment_country'] = "XXX";
		$data['payment_country_id'] ="XXX";
		$data['payment_method'] = 'Pay with Amazon';
		$data['payment_code'] = "amazon_checkout";
		$data['payment_tax_id']='';
		$data['payment_address_format']='';
		$data['payment_company']="";
		$data['payment_company_id']="";

		// Shipping Details
			
		$data['shipping_firstname'] = "XXX";
		$data['shipping_lastname'] = "XXX";
		$data['shipping_company'] = "XXX";
		$data['shipping_address_1'] = "XXX";
		$data['shipping_address_2'] = "XXX";
		$data['shipping_city'] ="XXX";
		$data['shipping_postcode'] = "XXX";
		$data['shipping_zone'] = "XXX";
		$data['shipping_zone_id'] = "XXX";
		$data['shipping_country'] = "XXX";
		$data['shipping_country_id'] = "XXX";
		$data['shipping_address_format']='';
		$data['shipping_method'] = "Standard";
		$data['shipping_code'] = 'Standard';
		// Products
		$data['products'] = array();

		foreach ($this->cart->getProducts() as $product) {
			$option_data = array();

			foreach ($product['option'] as $option) {
				if ($option['type'] != 'file') {
					$value = $option['option_value'];	
				} else {
					$value = $this->encryption->decrypt($option['option_value']);
				}
					
				$option_data[] = array(
					'product_option_id'       => $option['product_option_id'],
					'product_option_value_id' => $option['product_option_value_id'],
					'option_id'               => $option['option_id'],
					'option_value_id'         => $option['option_value_id'],
					'name'                    => $option['name'],
					'value'                   => $value,
					'type'                    => $option['type']
				);
			}

			$data['products'][] = array(
				'product_id' => $product['product_id'],
				'name'       => $product['name'],
				'model'      => $product['model'],
				'option'     => $option_data,
				'download'   => $product['download'],
				'quantity'   => $product['quantity'],
				'subtract'   => $product['subtract'],
				'price'      => $product['price'],
				'total'      => $product['total'],
				'tax'        => $this->tax->getTax($product['price'], $product['tax_class_id']),
				'reward'     => $product['reward']
			);
		}
		// Gift Voucher will not support by PWA.
		$data['vouchers'] = array();
		$extensionModel = 'model_setting_extension';
		$this->load->model('setting/extension');

		$data['totals'] = array();
		$total = 0;
		$taxes = $this->cart->getTaxes();

		$sort_order = array();

		//$results = $this->model_extension_extension->getExtensions('total');
		$results = $this->$extensionModel->getExtensions('total');

		foreach ($results as $key => $value) {
			$sort_order[$key] = $this->config->get($value['code'] . '_sort_order');
		}

		array_multisort($sort_order, SORT_ASC, $results);

		foreach ($results as $result) {
			if ($this->config->get($result['code'] . '_status')) {
				$this->load->model('total/' . $result['code']);

				$this->{'model_total_' . $result['code']}->getTotal($data['totals'], $total, $taxes);
			}
		}

		$sort_order = array();

		foreach ($data['totals'] as $key => $value) {
			$sort_order[$key] = $value['sort_order'];
		}

		array_multisort($sort_order, SORT_ASC, $data['totals']);

		$data['comment'] = '';
		//Currency HardCoded because PWA only support Indian Rupee
		$currency = $this->getCurrency('INR');
		$data['total'] = $total;
		$data['affiliate_id'] = 0;
		$data['commission'] = 0;
		$data['marketing_id'] = 0;
		$data['tracking'] = '';
		$data['language_id'] = $this->config->get('config_language_id');
		$data['currency_id'] = $currency['currency_id'];
		$data['currency_code'] = $currency['code'];
		$data['currency_value'] = $currency['value'];
		$data['ip'] = $this->request->server['REMOTE_ADDR'];

		if (!empty($this->request->server['HTTP_X_FORWARDED_FOR'])) {
			$data['forwarded_ip'] = $this->request->server['HTTP_X_FORWARDED_FOR'];
		} elseif (!empty($this->request->server['HTTP_CLIENT_IP'])) {
			$data['forwarded_ip'] = $this->request->server['HTTP_CLIENT_IP'];
		} else {
			$data['forwarded_ip'] = '';
		}

		if (isset($this->request->server['HTTP_USER_AGENT'])) {
			$data['user_agent'] = $this->request->server['HTTP_USER_AGENT'];
		} else {
			$data['user_agent'] = '';
		}

		if (isset($this->request->server['HTTP_ACCEPT_LANGUAGE'])) {
			$data['accept_language'] = $this->request->server['HTTP_ACCEPT_LANGUAGE'];
		} else {
			$data['accept_language'] = '';
		}
		
		$this->load->model('checkout/order');
		$order_status_id = $this->config->get('amazon_checkout_order_default_status');
		$data['order_status_id'] = $order_status_id;
		$orderId = $this->model_checkout_order->addOrder($data); 
		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET `order_status_id` = " . $order_status_id . " WHERE `order_id` = " . $orderId);
		$this->db->query("INSERT INTO `" . DB_PREFIX . "order_history` (`order_id`, `order_status_id`, `comment`, `date_added`) VALUES (" . (int)$orderId . ", " . $order_status_id . ", 'Order placed by PWA', NOW())");
		$this->load->model('payment/amazon_checkout');
		$this->model_payment_amazon_checkout->setOrderShipping($orderId, 0);
		$this->model_payment_amazon_checkout->addAmazonOrderId($orderId, $amazonOrderId);
		$this->cart->clear();
		unset($this->session->data['coupon']);
		unset($this->session->data['reward']);
		unset($this->session->data['voucher']);
		unset($this->session->data['vouchers']);
		return $orderId;		
	}
	public function getCartXml($cartId)
	{
		$query = $this->db->query("SELECT * FROM ". DB_PREFIX ."pwa_cart_xml WHERE cart_id = '".$cartId."'");
		if($query->num_rows){
			return $query->row;
		}
		return false;
	}
	public function updateOrderByIOPN($order_id, $xml)
	{
		$json = json_encode($xml);
		$response = json_decode($json,TRUE);
		$notification_type = $_POST['NotificationType'];
		$iopnData = $response['ProcessedOrder'];
		$billing_name = (isset($iopnData['BuyerInfo']['BuyerName'])) ? (string)$iopnData['BuyerInfo']['BuyerName'] : '';
		$billing_email = (isset($iopnData['BuyerInfo']['BuyerEmailAddress'])) ? (string)$iopnData['BuyerInfo']['BuyerEmailAddress'] : '';
		$shipping_name = (isset($iopnData['ShippingAddress']['Name'])) ? (string)$iopnData['ShippingAddress']['Name'] : '';
		$shipping_address1 = (isset($iopnData['ShippingAddress']['AddressFieldOne'])) ? (string)$iopnData['ShippingAddress']['AddressFieldOne'] : '';
		$shipping_address2 = (isset($iopnData['ShippingAddress']['AddressFieldTwo'])) ? (string)$iopnData['ShippingAddress']['AddressFieldTwo'] : '';
		$shipping_city = (isset($iopnData['ShippingAddress']['City'])) ? (string)$iopnData['ShippingAddress']['City'] : '';
		$shipping_zone = (isset($iopnData['ShippingAddress']['State'])) ? (string)$iopnData['ShippingAddress']['State'] : '';
		$shipping_post_code = (isset($iopnData['ShippingAddress']['PostalCode'])) ? (string)$iopnData['ShippingAddress']['PostalCode'] : '';
		$shipping_country_code = (isset($iopnData['ShippingAddress']['CountryCode'])) ? (string)$iopnData['ShippingAddress']['CountryCode'] : '';
		$billing_phone_number = isset($iopnData['ShippingAddress']['PhoneNumber']) ? (string)$iopnData['ShippingAddress']['PhoneNumber'] : 'xxx';
		$shipping_method = isset($iopnData['ShippingServiceLevel']) ? (string)$iopnData['ShippingServiceLevel'] : '';
		$countryid =  $this->getcountryid($shipping_country_code);
		$stateid = $this->getstateid($shipping_zone,$countryid);
		$stateid = ($stateid!=0)?$stateid:'';
		$amazonShippingAmount = 0.00;
		foreach($xml->ProcessedOrder->ProcessedOrderItems->ProcessedOrderItem as $item){
			$itemarray = json_decode(json_encode($item), true);
			if(isset($itemarray['ItemCharges']['Component'])){
				foreach($itemarray['ItemCharges']['Component'] as $component => $key){
					if($key['Type'] == 'Shipping'){
						$amazonShippingAmount += (float)$key['Charge']['Amount'];
					}
				}
			}
		}
		$order_status_id = (int)$this->config->get('amazon_checkout_order_default_status');
		$db = $this->db;
		if($notification_type == 'OrderReadyToShipNotification'){
			$amazonpending = (int)$this->config->get('amazon_checkout_order_default_status');
			$resultorder = $db->query("SELECT `order_status_id` FROM `" . DB_PREFIX . "order` WHERE `order_id` = '" . $order_id . "'")->row;
			$order_status_id = $this->config->get('amazon_checkout_order_ready_status');
			/*orderamazon reduce inventory in order processing*/
			
			if($resultorder['order_status_id'] == $amazonpending){
				$order_product_query = $db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");
				foreach ($order_product_query->rows as $order_product) {
					$db->query("UPDATE " . DB_PREFIX . "product SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_id = '" . (int)$order_product['product_id'] . "' AND subtract = '1'");
					$order_option_query = $db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$order_product['order_product_id'] . "'");
					foreach ($order_option_query->rows as $option) {
						$db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
					}
				}
				$this->amazonconfirmemail($order_id,$amazonpending);
			}
		}
		if($notification_type == 'OrderCancelledNotification'){
			$order_status_id = (int)$this->config->get('amazon_checkout_order_canceled_status');
			$this->increaseinventory((string)$iopnData['AmazonOrderID']);
		}
		
		$db->query("UPDATE `" . DB_PREFIX . "order` AS `o`, `" . DB_PREFIX . "order_amazon` `oa` SET `o`.`payment_firstname` = '" . $db->escape($billing_name) . "',`o`.`payment_lastname` = '',`o`.`payment_address_1` = '" . $db->escape($shipping_address1) . "',`o`.`payment_address_2` = '" . $db->escape($shipping_address2) . "',`payment_city` = '" . $db->escape($shipping_city) . "',`payment_postcode` = '" . $db->escape($shipping_post_code) . "',`payment_country` = '" . $db->escape($shipping_country_code) . "',`payment_country_id` = '" . $db->escape($countryid) . "',`payment_zone` = '" . $db->escape($shipping_zone) . "',`payment_zone_id` = '" . $db->escape($stateid) . "', `o`.`firstname` = '" . $db->escape($billing_name) . "',`o`.`lastname` = '',`o`.`email` = '" . $db->escape($billing_email) . "', `o`.`telephone` = '" . $db->escape($billing_phone_number) . "', `o`.`shipping_firstname` = '" . $db->escape($shipping_name) . "', `o`.`shipping_lastname` = '', `o`.`shipping_company` = '', `o`.`shipping_address_1` = '" . $db->escape($shipping_address1) . "', `o`.`shipping_address_2` = '" . $db->escape($shipping_address2) . "', `o`.`shipping_city` = '" . $db->escape($shipping_city) . "', `o`.`shipping_zone` = '" . $db->escape($shipping_zone) . "', `o`.`shipping_country` = '" . $db->escape($shipping_country_code) . "', `o`.`shipping_postcode` = '" . $db->escape($shipping_post_code) . "',`o`.`shipping_country_id` = '" . $db->escape($countryid) . "',`o`.`shipping_zone_id` = '" . $db->escape($stateid) . "', `o`.`shipping_method` = '" . $db->escape($shipping_method) . "',`o`.`shipping_code` = '" . $db->escape($shipping_method) . "',`o`.`order_status_id` = " . $order_status_id. " WHERE `o`.`order_id` = " . (int)$order_id);
		$this->updatetotal($order_id,$amazonShippingAmount,$shipping_method);
		if($notification_type != 'NewOrderNotification'){
			$db->query("INSERT INTO `" . DB_PREFIX . "order_history` (`order_id`, `order_status_id`, `comment`, `date_added`) VALUES (" . (int)$order_id . ", " . (int)$order_status_id . ", 'order updated by IOPN Amazon', NOW())");
		}
		return;
	}
	public function getDecodedCartXml($cartXml)
	{
		return simplexml_load_string(base64_decode($cartXml), 'SimpleXMLElement', LIBXML_NOCDATA);
	}
	
	public function applyCoupon($code, $customerId = 0)
	{
		//Refer Coupon.php in model
		
		$status = true;

		$coupon_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "coupon` WHERE code = '" . $this->db->escape($code) . "' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) AND status = '1'");

		if ($coupon_query->num_rows) {
			if ($coupon_query->row['total'] >= $this->cart->getSubTotal()) {
				$status = false;
			}

			$coupon_history_query = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "coupon_history` ch WHERE ch.coupon_id = '" . (int)$coupon_query->row['coupon_id'] . "'");

			if ($coupon_query->row['uses_total'] > 0 && ($coupon_history_query->row['total'] >= $coupon_query->row['uses_total'])) {
				$status = false;
			}

			if ($coupon_query->row['logged'] && !$this->customer->getId()) {
				$status = false;
			}

			if ($customerId) {
				$coupon_history_query = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "coupon_history` ch WHERE ch.coupon_id = '" . (int)$coupon_query->row['coupon_id'] . "' AND ch.customer_id = '" . $customerId . "'");

				if ($coupon_query->row['uses_customer'] > 0 && ($coupon_history_query->row['total'] >= $coupon_query->row['uses_customer'])) {
					$status = false;
				}
			}

			// Products
			$coupon_product_data = array();

			$coupon_product_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "coupon_product` WHERE coupon_id = '" . (int)$coupon_query->row['coupon_id'] . "'");

			foreach ($coupon_product_query->rows as $product) {
				$coupon_product_data[] = $product['product_id'];
			}

			// Categories
			$coupon_category_data = array();

			$coupon_category_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "coupon_category` cc LEFT JOIN `" . DB_PREFIX . "category_path` cp ON (cc.category_id = cp.path_id) WHERE cc.coupon_id = '" . (int)$coupon_query->row['coupon_id'] . "'");

			foreach ($coupon_category_query->rows as $category) {
				$coupon_category_data[] = $category['category_id'];
			}			
			
			$product_data = array();
			
			if ($coupon_product_data || $coupon_category_data) {
				foreach ($this->cart->getProducts() as $product) {
					if (in_array($product['product_id'], $coupon_product_data)) {
						$product_data[] = $product['product_id'];

						continue;
					}

					foreach ($coupon_category_data as $category_id) {
						$coupon_category_query = $this->db->query("SELECT COUNT(*) AS total FROM `" . DB_PREFIX . "product_to_category` WHERE `product_id` = '" . (int)$product['product_id'] . "' AND category_id = '" . (int)$category_id . "'");

						if ($coupon_category_query->row['total']) {
							$product_data[] = $product['product_id'];

							continue;
						}						
					}
				}	

				if (!$product_data) {
					$status = false;
				}
			}
		} else {
			$status = false;
		}
		if($status){
			$this->session->data['coupon'] = $code;
		}
		return ;
	}
	public function setConfigByStore($storeId)
	{
		$this->config->set('config_store_id', $storeId);
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE store_id = '0' OR store_id = '" . $storeId . "' ORDER BY store_id ASC");

		foreach ($query->rows as $setting) {
			if (!$setting['serialized']) {
				$this->config->set($setting['key'], $setting['value']);
			} else {
				$this->config->set($setting['key'], unserialize($setting['value']));
			}
		}
	}
	
	public function getCustomerGroupId($customerId)
	{
		$customer = $this->db->query("SELECT * FROM " . DB_PREFIX . "customer WHERE customer_id = '" . $customerId . "' AND status = '1'");
		if ($customer->num_rows) {
			return $customer->row['customer_group_id'];
		}
		return false;
	}
	public function getCurrency($code)
	{
		$currency = $this->db->query("SELECT * FROM " . DB_PREFIX . "currency WHERE code='" . $code . "'");
		if($currency->num_rows){
			return $currency->row;
		}
	}
	public function cartHasDownloadable()
	{
		$total_count = $this->cart->hasProducts(); 
		$downloadcount = 0;
		foreach ($this->cart->getProducts() as $product) {
			if ($product['download']) {
				$downloadcount++;
			}
		}
		return ($total_count == $downloadcount) ? true : false;
	}
	public function confirm($order_id, $order_status_id, $comment = '', $notify = false) {
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($order_id);

		if ($order_info && !$order_info['order_status_id']) {
			// Fraud Detection
			if ($this->config->get('config_fraud_detection')) {
				$this->load->model('checkout/fraud');

				$risk_score = $this->model_checkout_fraud->getFraudScore($order_info);

				if ($risk_score > $this->config->get('config_fraud_score')) {
					$order_status_id = $this->config->get('config_fraud_status_id');
				}
			}

			// Ban IP
			$status = false;

			$this->load->model('account/customer');

			if ($order_info['customer_id']) {
				$results = $this->model_account_customer->getIps($order_info['customer_id']);

				foreach ($results as $result) {
					if ($this->model_account_customer->isBanIp($result['ip'])) {
						$status = true;

						break;
					}
				}
			} else {
				$status = $this->model_account_customer->isBanIp($order_info['ip']);
			}

			if ($status) {
				$order_status_id = $this->config->get('config_order_status_id');
			}		

			$this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '" . (int)$order_status_id . "', date_modified = NOW() WHERE order_id = '" . (int)$order_id . "'");

			$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '1', comment = '" . $this->db->escape(($comment && $notify) ? $comment : '') . "', date_added = NOW()");

			$order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");
			
			
			/*  commenting the lines for inventory should not update on amazon order  */
			/* 
			foreach ($order_product_query->rows as $order_product) {
				$this->db->query("UPDATE " . DB_PREFIX . "product SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_id = '" . (int)$order_product['product_id'] . "' AND subtract = '1'");

				$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$order_product['order_product_id'] . "'");

				foreach ($order_option_query->rows as $option) {
					$this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$order_product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
				}
			}
			*/

			if(!isset($passArray) || empty($passArray)){ $passArray = null; }
			$this->openbay->orderNew((int)$order_id);

			$this->cache->delete('product');

			// Downloads
			$order_download_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_download WHERE order_id = '" . (int)$order_id . "'");

			// Gift Voucher
			$this->load->model('checkout/voucher');

			$order_voucher_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_voucher WHERE order_id = '" . (int)$order_id . "'");

			foreach ($order_voucher_query->rows as $order_voucher) {
				$voucher_id = $this->model_checkout_voucher->addVoucher($order_id, $order_voucher);

				$this->db->query("UPDATE " . DB_PREFIX . "order_voucher SET voucher_id = '" . (int)$voucher_id . "' WHERE order_voucher_id = '" . (int)$order_voucher['order_voucher_id'] . "'");
			}			

			// Send out any gift voucher mails
			if ($this->config->get('config_complete_status_id') == $order_status_id) {
				$this->model_checkout_voucher->confirm($order_id);
			}

			// Order Totals			
			$order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");

			foreach ($order_total_query->rows as $order_total) {
				$this->load->model('total/' . $order_total['code']);

				if (method_exists($this->{'model_total_' . $order_total['code']}, 'confirm')) {
					$this->{'model_total_' . $order_total['code']}->confirm($order_info, $order_total);
				}
			}

			// Send out order confirmation mail
			$language = new Language($order_info['language_directory']);
			$language->load($order_info['language_filename']);
			$language->load('mail/order');

			$order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

			if ($order_status_query->num_rows) {
				$order_status = $order_status_query->row['name'];	
			} else {
				$order_status = '';
			}

			$subject = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

			// HTML Mail
			$template = new Template();

			$template->data['title'] = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

			$template->data['text_greeting'] = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
			$template->data['text_link'] = $language->get('text_new_link');
			$template->data['text_download'] = $language->get('text_new_download');
			$template->data['text_order_detail'] = $language->get('text_new_order_detail');
			$template->data['text_instruction'] = $language->get('text_new_instruction');
			$template->data['text_order_id'] = $language->get('text_new_order_id');
			$template->data['text_date_added'] = $language->get('text_new_date_added');
			$template->data['text_payment_method'] = $language->get('text_new_payment_method');	
			$template->data['text_shipping_method'] = $language->get('text_new_shipping_method');
			$template->data['text_email'] = $language->get('text_new_email');
			$template->data['text_telephone'] = $language->get('text_new_telephone');
			$template->data['text_ip'] = $language->get('text_new_ip');
			$template->data['text_payment_address'] = $language->get('text_new_payment_address');
			$template->data['text_shipping_address'] = $language->get('text_new_shipping_address');
			$template->data['text_product'] = $language->get('text_new_product');
			$template->data['text_model'] = $language->get('text_new_model');
			$template->data['text_quantity'] = $language->get('text_new_quantity');
			$template->data['text_price'] = $language->get('text_new_price');
			$template->data['text_total'] = $language->get('text_new_total');
			$template->data['text_footer'] = $language->get('text_new_footer');
			$template->data['text_powered'] = $language->get('text_new_powered');

			$template->data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');		
			$template->data['store_name'] = $order_info['store_name'];
			$template->data['store_url'] = $order_info['store_url'];
			$template->data['customer_id'] = $order_info['customer_id'];
			$template->data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

			if ($order_download_query->num_rows) {
				$template->data['download'] = $order_info['store_url'] . 'index.php?route=account/download';
			} else {
				$template->data['download'] = '';
			}

			$template->data['order_id'] = $order_id;
			$template->data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));    	
			$template->data['payment_method'] = $order_info['payment_method'];
			$template->data['shipping_method'] = $order_info['shipping_method'];
			$template->data['email'] = $order_info['email'];
			$template->data['telephone'] = $order_info['telephone'];
			$template->data['ip'] = $order_info['ip'];

			if ($comment && $notify) {
				$template->data['comment'] = nl2br($comment);
			} else {
				$template->data['comment'] = '';
			}

			if ($order_info['payment_address_format']) {
				$format = $order_info['payment_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $order_info['payment_firstname'],
				'lastname'  => $order_info['payment_lastname'],
				'company'   => $order_info['payment_company'],
				'address_1' => $order_info['payment_address_1'],
				'address_2' => $order_info['payment_address_2'],
				'city'      => $order_info['payment_city'],
				'postcode'  => $order_info['payment_postcode'],
				'zone'      => $order_info['payment_zone'],
				'zone_code' => $order_info['payment_zone_code'],
				'country'   => $order_info['payment_country']  
			);

			$template->data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));						

			if ($order_info['shipping_address_format']) {
				$format = $order_info['shipping_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $order_info['shipping_firstname'],
				'lastname'  => $order_info['shipping_lastname'],
				'company'   => $order_info['shipping_company'],
				'address_1' => $order_info['shipping_address_1'],
				'address_2' => $order_info['shipping_address_2'],
				'city'      => $order_info['shipping_city'],
				'postcode'  => $order_info['shipping_postcode'],
				'zone'      => $order_info['shipping_zone'],
				'zone_code' => $order_info['shipping_zone_code'],
				'country'   => $order_info['shipping_country']  
			);

			$template->data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

			// Products
			$template->data['products'] = array();

			foreach ($order_product_query->rows as $product) {
				$option_data = array();

				$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

				foreach ($order_option_query->rows as $option) {
					if ($option['type'] != 'file') {
						$value = $option['value'];
					} else {
						$value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
					}

					$option_data[] = array(
						'name'  => $option['name'],
						'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
					);					
				}

				$template->data['products'][] = array(
					'name'     => $product['name'],
					'model'    => $product['model'],
					'option'   => $option_data,
					'quantity' => $product['quantity'],
					'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
					'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
				);
			}

			// Vouchers
			$template->data['vouchers'] = array();

			foreach ($order_voucher_query->rows as $voucher) {
				$template->data['vouchers'][] = array(
					'description' => $voucher['description'],
					'amount'      => $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']),
				);
			}

			$template->data['totals'] = $order_total_query->rows;

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/mail/order.tpl')) {
				$html = $template->fetch($this->config->get('config_template') . '/template/mail/order.tpl');
			} else {
				$html = $template->fetch('default/template/mail/order.tpl');
			}

			// Can not send confirmation emails for CBA orders as email is unknown
			$this->load->model('payment/amazon_checkout');
			if (!$this->model_payment_amazon_checkout->isAmazonOrder($order_info['order_id'])) {
				// Text Mail
				$text = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
				$text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
				$text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
				$text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

				if ($comment && $notify) {
					$text .= $language->get('text_new_instruction') . "\n\n";
					$text .= $comment . "\n\n";
				}

				// Products
				$text .= $language->get('text_new_products') . "\n";

				foreach ($order_product_query->rows as $product) {
					$text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

					$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

					foreach ($order_option_query->rows as $option) {
						$text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($option['value']) > 20 ? utf8_substr($option['value'], 0, 20) . '..' : $option['value']) . "\n";
					}
				}

				foreach ($order_voucher_query->rows as $voucher) {
					$text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
				}

				$text .= "\n";

				$text .= $language->get('text_new_order_total') . "\n";

				foreach ($order_total_query->rows as $total) {
					$text .= $total['title'] . ': ' . html_entity_decode($total['text'], ENT_NOQUOTES, 'UTF-8') . "\n";
				}

				$text .= "\n";

				if ($order_info['customer_id']) {
					$text .= $language->get('text_new_link') . "\n";
					$text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
				}

				if ($order_download_query->num_rows) {
					$text .= $language->get('text_new_download') . "\n";
					$text .= $order_info['store_url'] . 'index.php?route=account/download' . "\n\n";
				}

				// Comment
				if ($order_info['comment']) {
					$text .= $language->get('text_new_comment') . "\n\n";
					$text .= $order_info['comment'] . "\n\n";
				}

				$text .= $language->get('text_new_footer') . "\n\n";

				$mail = new Mail();
				$mail->protocol = $this->config->get('config_mail_protocol');
				$mail->parameter = $this->config->get('config_mail_parameter');
				$mail->hostname = $this->config->get('config_smtp_host');
				$mail->username = $this->config->get('config_smtp_username');
				$mail->password = $this->config->get('config_smtp_password');
				$mail->port = $this->config->get('config_smtp_port');
				$mail->timeout = $this->config->get('config_smtp_timeout');
				$mail->setTo($order_info['email']);
				$mail->setFrom($this->config->get('config_email'));
				$mail->setSender($order_info['store_name']);
				$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
				$mail->setHtml($html);
				$mail->setText(html_entity_decode($text, ENT_QUOTES, 'UTF-8'));
				$mail->send();
			}

			// Admin Alert Mail
			if ($this->config->get('config_alert_mail')) {
				$subject = sprintf($language->get('text_new_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), $order_id);

				// Text 
				$text  = $language->get('text_new_received') . "\n\n";
				$text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
				$text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
				$text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";
				$text .= $language->get('text_new_products') . "\n";

				foreach ($order_product_query->rows as $product) {
					$text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

					$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

					foreach ($order_option_query->rows as $option) {
						if ($option['type'] != 'file') {
							$value = $option['value'];
						} else {
							$value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
						}

						$text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
					}
				}

				foreach ($order_voucher_query->rows as $voucher) {
					$text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
				}

				$text .= "\n";

				$text .= $language->get('text_new_order_total') . "\n";

				foreach ($order_total_query->rows as $total) {
					$text .= $total['title'] . ': ' . html_entity_decode($total['text'], ENT_NOQUOTES, 'UTF-8') . "\n";
				}			

				$text .= "\n";

				if ($order_info['comment']) {
					$text .= $language->get('text_new_comment') . "\n\n";
					$text .= $order_info['comment'] . "\n\n";
				}

				$mail = new Mail(); 
				$mail->protocol = $this->config->get('config_mail_protocol');
				$mail->parameter = $this->config->get('config_mail_parameter');
				$mail->hostname = $this->config->get('config_smtp_host');
				$mail->username = $this->config->get('config_smtp_username');
				$mail->password = $this->config->get('config_smtp_password');
				$mail->port = $this->config->get('config_smtp_port');
				$mail->timeout = $this->config->get('config_smtp_timeout');
				$mail->setTo($this->config->get('config_email'));
				$mail->setFrom($this->config->get('config_email'));
				$mail->setSender($order_info['store_name']);
				$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
				$mail->setText(html_entity_decode($text, ENT_QUOTES, 'UTF-8'));
				$mail->send();

				// Send to additional alert emails
				$emails = explode(',', $this->config->get('config_alert_emails'));

				foreach ($emails as $email) {
					if ($email && preg_match('/^[^\@]+@.*\.[a-z]{2,6}$/i', $email)) {
						$mail->setTo($email);
						$mail->send();
					}
				}				
			}		
		}
	}
	
	public function amazonconfirmemail($order_id, $order_status_id, $comment = '', $notify = false){
			
			$this->load->model('checkout/order');
			$order_info = $this->model_checkout_order->getOrder($order_id);
			
			// order product query
			$order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");
			
			
			// Downloads
			$order_download_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_download WHERE order_id = '" . (int)$order_id . "'");

			// Gift Voucher
			$order_voucher_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_voucher WHERE order_id = '" . (int)$order_id . "'");

			// Order Totals			
			$order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");
		
		// Send out order confirmation mail
			$language = new Language($order_info['language_directory']);
			$language->load($order_info['language_filename']);
			$language->load('mail/order');

			$order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

			if ($order_status_query->num_rows) {
				$order_status = $order_status_query->row['name'];	
			} else {
				$order_status = '';
			}

			$subject = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

			// HTML Mail
			$template = new Template();

			$template->data['title'] = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

			$template->data['text_greeting'] = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
			$template->data['text_link'] = $language->get('text_new_link');
			$template->data['text_download'] = $language->get('text_new_download');
			$template->data['text_order_detail'] = $language->get('text_new_order_detail');
			$template->data['text_instruction'] = $language->get('text_new_instruction');
			$template->data['text_order_id'] = $language->get('text_new_order_id');
			$template->data['text_date_added'] = $language->get('text_new_date_added');
			$template->data['text_payment_method'] = $language->get('text_new_payment_method');	
			$template->data['text_shipping_method'] = $language->get('text_new_shipping_method');
			$template->data['text_email'] = $language->get('text_new_email');
			$template->data['text_telephone'] = $language->get('text_new_telephone');
			$template->data['text_ip'] = $language->get('text_new_ip');
			$template->data['text_payment_address'] = $language->get('text_new_payment_address');
			$template->data['text_shipping_address'] = $language->get('text_new_shipping_address');
			$template->data['text_product'] = $language->get('text_new_product');
			$template->data['text_model'] = $language->get('text_new_model');
			$template->data['text_quantity'] = $language->get('text_new_quantity');
			$template->data['text_price'] = $language->get('text_new_price');
			$template->data['text_total'] = $language->get('text_new_total');
			$template->data['text_footer'] = $language->get('text_new_footer');
			$template->data['text_powered'] = $language->get('text_new_powered');

			$template->data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');		
			$template->data['store_name'] = $order_info['store_name'];
			$template->data['store_url'] = $order_info['store_url'];
			$template->data['customer_id'] = $order_info['customer_id'];
			$template->data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

			if ($order_download_query->num_rows) {
				$template->data['download'] = $order_info['store_url'] . 'index.php?route=account/download';
			} else {
				$template->data['download'] = '';
			}

			$template->data['order_id'] = $order_id;
			$template->data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));    	
			$template->data['payment_method'] = $order_info['payment_method'];
			$template->data['shipping_method'] = $order_info['shipping_method'];
			$template->data['email'] = $order_info['email'];
			$template->data['telephone'] = $order_info['telephone'];
			$template->data['ip'] = $order_info['ip'];

			if ($comment && $notify) {
				$template->data['comment'] = nl2br($comment);
			} else {
				$template->data['comment'] = '';
			}

			if ($order_info['payment_address_format']) {
				$format = $order_info['payment_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $order_info['payment_firstname'],
				'lastname'  => $order_info['payment_lastname'],
				'company'   => $order_info['payment_company'],
				'address_1' => $order_info['payment_address_1'],
				'address_2' => $order_info['payment_address_2'],
				'city'      => $order_info['payment_city'],
				'postcode'  => $order_info['payment_postcode'],
				'zone'      => $order_info['payment_zone'],
				'zone_code' => $order_info['payment_zone_code'],
				'country'   => $order_info['payment_country']  
			);

			$template->data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));						

			if ($order_info['shipping_address_format']) {
				$format = $order_info['shipping_address_format'];
			} else {
				$format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
			}

			$find = array(
				'{firstname}',
				'{lastname}',
				'{company}',
				'{address_1}',
				'{address_2}',
				'{city}',
				'{postcode}',
				'{zone}',
				'{zone_code}',
				'{country}'
			);

			$replace = array(
				'firstname' => $order_info['shipping_firstname'],
				'lastname'  => $order_info['shipping_lastname'],
				'company'   => $order_info['shipping_company'],
				'address_1' => $order_info['shipping_address_1'],
				'address_2' => $order_info['shipping_address_2'],
				'city'      => $order_info['shipping_city'],
				'postcode'  => $order_info['shipping_postcode'],
				'zone'      => $order_info['shipping_zone'],
				'zone_code' => $order_info['shipping_zone_code'],
				'country'   => $order_info['shipping_country']  
			);

			$template->data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

			// Products
			$template->data['products'] = array();

			foreach ($order_product_query->rows as $product) {
				$option_data = array();

				$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

				foreach ($order_option_query->rows as $option) {
					if ($option['type'] != 'file') {
						$value = $option['value'];
					} else {
						$value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
					}

					$option_data[] = array(
						'name'  => $option['name'],
						'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
					);					
				}

				$template->data['products'][] = array(
					'name'     => $product['name'],
					'model'    => $product['model'],
					'option'   => $option_data,
					'quantity' => $product['quantity'],
					'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
					'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
				);
			}

			// Vouchers
			$template->data['vouchers'] = array();

			foreach ($order_voucher_query->rows as $voucher) {
				$template->data['vouchers'][] = array(
					'description' => $voucher['description'],
					'amount'      => $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']),
				);
			}

			$template->data['totals'] = $order_total_query->rows;

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/mail/order.tpl')) {
				$html = $template->fetch($this->config->get('config_template') . '/template/mail/order.tpl');
			} else {
				$html = $template->fetch('default/template/mail/order.tpl');
			}

			// Can not send confirmation emails for CBA orders as email is unknown
			$this->load->model('payment/amazon_checkout');
			
				// Text Mail
				$text = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
				$text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
				$text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
				$text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

				if ($comment && $notify) {
					$text .= $language->get('text_new_instruction') . "\n\n";
					$text .= $comment . "\n\n";
				}

				// Products
				$text .= $language->get('text_new_products') . "\n";

				foreach ($order_product_query->rows as $product) {
					$text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

					$order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

					foreach ($order_option_query->rows as $option) {
						$text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($option['value']) > 20 ? utf8_substr($option['value'], 0, 20) . '..' : $option['value']) . "\n";
					}
				}

				foreach ($order_voucher_query->rows as $voucher) {
					$text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
				}

				$text .= "\n";

				$text .= $language->get('text_new_order_total') . "\n";

				foreach ($order_total_query->rows as $total) {
					$text .= $total['title'] . ': ' . html_entity_decode($total['text'], ENT_NOQUOTES, 'UTF-8') . "\n";
				}

				$text .= "\n";

				if ($order_info['customer_id']) {
					$text .= $language->get('text_new_link') . "\n";
					$text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
				}

				if ($order_download_query->num_rows) {
					$text .= $language->get('text_new_download') . "\n";
					$text .= $order_info['store_url'] . 'index.php?route=account/download' . "\n\n";
				}

				// Comment
				if ($order_info['comment']) {
					$text .= $language->get('text_new_comment') . "\n\n";
					$text .= $order_info['comment'] . "\n\n";
				}

				$text .= $language->get('text_new_footer') . "\n\n";

				$mail = new Mail();
				$mail->protocol = $this->config->get('config_mail_protocol');
				$mail->parameter = $this->config->get('config_mail_parameter');
				$mail->hostname = $this->config->get('config_smtp_host');
				$mail->username = $this->config->get('config_smtp_username');
				$mail->password = $this->config->get('config_smtp_password');
				$mail->port = $this->config->get('config_smtp_port');
				$mail->timeout = $this->config->get('config_smtp_timeout');
				$mail->setTo($order_info['email']);
				$mail->setFrom($this->config->get('config_email'));
				$mail->setSender($order_info['store_name']);
				$mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
				$mail->setHtml($html);
				$mail->setText(html_entity_decode($text, ENT_QUOTES, 'UTF-8'));
				$log = new Log('mailcheck.log');
				$log->write('Mail working upto end');
				$mail->send();
			
	}
	
	public function getmarketplace(){
		$marketplace = $this->config->get('amazon_checkout_marketplace');
		return $marketplace;
	}
	
	public function getcountryid($country='IN'){
		$querycountry = $this->db->query("SELECT * FROM " . DB_PREFIX . "country WHERE iso_code_2 ='".$country."'");
		return $querycountry->row['country_id'];
	}
	
	public function getstateid($state='',$country_id){
		$statearray = explode(" ", trim($state));
		$statetext = $statearray[0];
		$querystate = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone WHERE name LIKE '%".$statetext."%' and country_id= $country_id");
		$zoneid = ($querystate->num_rows==1)?$querystate->row['zone_id']:0;
		return $zoneid; 
		
	}
	
	public function updatetotal($order_id, $shippingcharge=0, $shippingmethod='Standard'){
		if(!empty($order_id)){
			$this->load->model('checkout/order');
			$order_info = $this->model_checkout_order->getOrder($order_id);
			$queryship = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_total WHERE code='shippwa' AND order_id=".(int)$order_id."");
			if($queryship->num_rows==0)
			{
				$currency = $this->getCurrency('INR');
				$shippingvalue  = (float)round($shippingcharge/$order_info['currency_value']);
				$ordertotal = (int)round($order_info['total']*$order_info['currency_value']);
				$updatetotal = $ordertotal+$shippingcharge;
				$updatevalue = (float)round($updatetotal/$order_info['currency_value']);
				$total = (float)$updatetotal/$order_info['currency_value'];
				if(isset($currency)){
					$shippingchargetext = $currency['symbol_left'].$shippingcharge.$currency['symbol_right'];
					$updatetext = $currency['symbol_left'].$updatetotal.$currency['symbol_right'];
				}
				else{
					$shippingchargetext = 'Rs.'.$shippingcharge;
					$updatetext = 'Rs.'.$updatetotal;
				}
				$this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = 'shippwa', title = '".$shippingmethod."', text = '".$shippingchargetext."', `value` = '".$shippingvalue."', sort_order = '3'");
				$this->db->query("UPDATE " . DB_PREFIX . "order_total SET text ='" . $updatetext . "', value = $updatevalue WHERE order_id=".(int)$order_id." AND code='total'");
				$this->db->query("UPDATE " . DB_PREFIX . "order SET total ='" . $total . "' WHERE order_id='".(int)$order_id."'");
			}
		}	
	}
	
	public function increaseinventory($amazon_order_id=''){
		$db=$this->db;
		$result = $db->query("SELECT order_id FROM " . DB_PREFIX . "order_amazon WHERE amazon_order_id = '" .$amazon_order_id."'");
		if ($result->num_rows) {
			$order_id = $result->row['order_id'];
			$amazonstatus = $this->config->get('amazon_checkout_order_ready_status'); 
			$resultorder = $db->query("SELECT `order_status_id` FROM `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . $order_id . "' order by `order_history_id` desc LIMIT 1 , 1")->row;
			 if($resultorder['order_status_id']==$amazonstatus){
				$order_product_query = $db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");
					foreach ($order_product_query->rows as $order_product) {
					   $db->query("UPDATE " . DB_PREFIX . "product SET quantity = (quantity + " . (int)$order_product['quantity'] . ") WHERE product_id = '" . (int)$order_product['product_id'] . "' AND subtract = '1'");
					   $order_option_query = $db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$order_product['order_product_id'] . "'");
					   foreach ($order_option_query->rows as $option) {
							$db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity + " . (int)$order_product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
						}
					}
			 }
	    }
	}



}
