<?php
class ControllerModulePaywithamazonLayout extends Controller {
	
	protected function index($setting)
	{
		$currency=$this->currency->getCode();
		$this->config->get('paywithamazon_mode'); 
		$status = $this->config->get('paywithamazon_status'); 
    	$this->data['currency'] = $this->currency->getCode();
		if ((!$this->cart->hasProducts() && empty($this->session->data['vouchers'])) ||
			(!$this->cart->hasStock() && !$this->config->get('config_stock_checkout')) ||
			(!$this->customer->isLogged() && ($this->cart->hasRecurringProducts() || $this->cart->hasDownload()))) {

			$status = false;
		}
		if($currency == 'INR' && $status) {
			$this->load->model('payment/paywithamazon');
			$orderinput = $this->model_payment_paywithamazon->createOrderInputValue();
			$this->data['orderinput'] = $orderinput;
			$this->data['merchantid']=$this->config->get('paywithamazon_merchant_id');

			if ($this->config->get('paywithamazon_mode') == 'sandbox') {
				if ($this->config->get('paywithamazon_marketplace') == 'in') {  
					$amazonPaymentJs = 'https://static-eu.payments-amazon.com/cba/js/in/sandbox/PaymentWidgets.js';
				} 
			} 
			elseif ($this->config->get('paywithamazon_mode') == 'live') {
				if ($this->config->get('paywithamazon_marketplace') == 'in') {
					$amazonPaymentJs = 'https://static-eu.payments-amazon.com/cba/js/in/PaymentWidgets.js';
				} 
			}
			$this->data['layout_id'] = $setting['layout_id'];
			$this->data['position'] = $setting['position'];
			$this->document->addScript($amazonPaymentJs);
			$this->data['button_colour'] = $this->config->get('paywithamazon_button_colour');
			$this->data['button_background'] = $this->config->get('paywithamazon_button_background');
			$this->data['button_size'] = $this->config->get('paywithamazon_button_size');
				
			$this->template = 'default/template/module/paywithamazon_layout.tpl';
			$this->render();
		}
	}
}
?>
