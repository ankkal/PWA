<?php
class ModelPaymentPaywithamazon extends Model {
	public function install() {
		$this->db->query("
			CREATE TABLE `" . DB_PREFIX . "order_paywithamazon` (
				`order_id` int(11) NOT NULL,
				`amazon_order_id` varchar(255) NOT NULL,
				`free_shipping`  tinyint NOT NULL DEFAULT 0,
				KEY `amazon_order_id` (`amazon_order_id`),
				PRIMARY KEY `order_id` (`order_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
		");

		$this->db->query("
			CREATE TABLE `" . DB_PREFIX . "order_paywithamazon_product` (
			`order_product_id`  int NOT NULL ,
			`amazon_order_item_code`  varchar(255) NOT NULL,
			PRIMARY KEY (`order_product_id`)
		) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
		");

		$this->db->query("
			CREATE TABLE `" . DB_PREFIX . "order_paywithamazon_report` (
				`order_id`  int NOT NULL ,
				`submission_id`  varchar(255) NOT NULL ,
				`status` enum('processing','error','success') NOT NULL ,
				`text`  text NOT NULL,
				PRIMARY KEY (`submission_id`),
				INDEX (`order_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
		");

		$this->db->query("
			CREATE TABLE `" . DB_PREFIX . "order_paywithamazon_total_tax` (
				`order_total_id`  INT,
				`code` VARCHAR(255),
				`tax` DECIMAL(10, 4) NOT NULL,
				PRIMARY KEY (`order_total_id`)
			) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
		");
	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "order_paywithamazon`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "order_paywithamazon_product`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "order_paywithamazon_report`;");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "order_paywithamazon_total_tax`;");
	}

	public function orderStatusChange($order_id, $data) {
		if ($this->config->get('paywithamazon_status') == 1) {
			$order = $this->getOrder($order_id);

			if ($order) {
				$this->load->library('cba');
				$cba = new CBA($this->config->get('paywithamazon_merchant_id'), $this->config->get('paywithamazon_access_key'), $this->config->get('paywithamazon_access_secret'), $this->config->get('paywithamazon_marketplace'));

				if ($data['order_status_id'] == $this->config->get('paywithamazon_shipped_status_id')) {
					$cba->orderShipped($order);
				}

				if ($data['order_status_id'] == $this->config->get('paywithamazon_canceled_status_id')) {
					$cba->orderCanceled($order);
				}
			}
		}
	}

	public function addReportSubmission($order_id, $feed_submissionid) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "order_paywithamazon_report` (`order_id`, `submission_id`, `status`, `text`) VALUES (" . (int)$order_id . ", '" . $this->db->escape($feed_submissionid) . "', 'processing', '')");
	}

	public function getReportSubmissions($order_id) {
		return $this->db->query("SELECT `submission_id`, `status`, `text` FROM `" . DB_PREFIX . "order_paywithamazon_report` WHERE `order_id` = " . (int)$order_id)->rows;
	}

	public function getOrder($order_id) {
		$order = array();

		$result = $this->db->query("SELECT amazon_order_id FROM " . DB_PREFIX . "order_paywithamazon WHERE order_id = " . (int)$order_id);

		if ($result->num_rows) {
			$order['amazon_order_id'] = $result->row['amazon_order_id'];

			$order['products'] = array();

			$results = $this->db->query("SELECT oap.order_product_id, amazon_order_item_code, op.quantity FROM " . DB_PREFIX . "order_paywithamazon_product oap JOIN " . DB_PREFIX . "order_product op USING(order_product_id) WHERE order_id = " . (int)$order_id . "
			")->rows;

			foreach ($results as $result) {
				$order['products'][$result['order_product_id']] = array(
					'amazon_order_item_code' => $result['amazon_order_item_code'],
					'quantity' => $result['quantity'],
				);
			}
		}

		return $order;
	}
	
	public function getmarketplace(){
		$marketplace = $this->config->get('amazon_checkout_marketplace');
		return $marketplace;
	}
	
	public function getshipdetails($amazon_order_id=''){ 
		$result = $this->db->query("SELECT order_id FROM " . DB_PREFIX . "order_amazon WHERE amazon_order_id = '" .$amazon_order_id."'"); 
		$shipdetails = array();
		if ($result->num_rows) {	
			$order_id = $result->row['order_id'];
			$order =  $this->db->query("SELECT shipping_method,shipping_code FROM " . DB_PREFIX . "order WHERE order_id = '" . (int)$order_id . "'");
			$shippingcode = $order->row['shipping_code'];
			$shipdetails['shipping_code'] = $shippingcode;
			switch($shippingcode){
				case 'Standard':
					$shipdetails['shipping_method'] = 'Standard delivery';
					break;
				case 'Expedited':
					$shipdetails['shipping_method'] = 'Express delivery';
					break;
				default:
					$shipdetails['shipping_method'] = 'Not updated';
					break;
			}
		}
		return $shipdetails;
	}
	
	public function increaseinventory($amazon_order_id=''){
		$db=$this->db;
		$result = $db->query("SELECT order_id FROM " . DB_PREFIX . "order_amazon WHERE amazon_order_id = '" .$amazon_order_id."'");
		if ($result->num_rows) {
			$order_id = $result->row['order_id'];
			$amazonstatus = $this->config->get('amazon_checkout_order_ready_status'); 
			$resultorder = $db->query("SELECT `order_status_id` FROM `" . DB_PREFIX . "order_history` WHERE `order_id` = '" . $order_id . "' order by `order_history_id` desc LIMIT 1 , 1")->row;
			 if($resultorder['order_status_id']==$amazonstatus){
				$order_product_query = $db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");
					foreach ($order_product_query->rows as $order_product) {
					   $db->query("UPDATE " . DB_PREFIX . "product SET quantity = (quantity + " . (int)$order_product['quantity'] . ") WHERE product_id = '" . (int)$order_product['product_id'] . "' AND subtract = '1'");
					   $order_option_query = $db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$order_product['order_product_id'] . "'");
					   foreach ($order_option_query->rows as $option) {
							$db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity + " . (int)$order_product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
						}
					}
			 }
	    }
	}
	
	
	
	
}
